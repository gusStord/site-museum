// Musæum — Service Worker (PWA)
// Adaptado do modelo enviado pelo usuário (estrutura install/fetch/activate)
// para uma aplicação Next.js: pré-cache do shell, cache-first para assets
// estáticos (obras, panoramas, áudio, ícones) e network-first para
// navegação e API, com fallback offline para a rota principal.

// Nome do cache — mude se atualizar o site
const CACHE_NAME = 'museum-pwa-v1';

// Arquivos salvos para usar offline (shell mínimo do app)
const ARQUIVOS_CACHE = [
  '/',
  '/manifest.webmanifest',
  '/icons/icon-192.png',
  '/icons/icon-512.png'
];

// Prefixos servidos como arquivos estáticos (cache-first)
const CACHE_FIRST_PREFIXES = [
  '/artworks/',
  '/panoramas/',
  '/audio/',
  '/icons/',
  '/_next/static/'
];

// Instala o Service Worker e salva os arquivos
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => {
        console.log('[PWA] Arquivos em cache');
        return cache.addAll(ARQUIVOS_CACHE);
      })
      .then(() => self.skipWaiting())
  );
});

// Estratégia de busca:
// - estáticos (obras/panoramas/áudio/ícones/_next): cache primeiro
// - navegação e API: rede primeiro, com fallback para o cache
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;

  const isCacheFirst = CACHE_FIRST_PREFIXES.some((p) =>
    url.pathname.startsWith(p)
  );

  if (isCacheFirst) {
    // Cache-first com revalidação em segundo plano (stale-while-revalidate)
    event.respondWith(
      caches.match(request).then((cached) => {
        const network = fetch(request)
          .then((response) => {
            if (response && response.status === 200) {
              const clone = response.clone();
              caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
            }
            return response;
          })
          .catch(() => cached);
        return cached || network;
      })
    );
    return;
  }

  // Network-first (navegação e API)
  event.respondWith(
    fetch(request)
      .then((response) => {
        if (response && response.status === 200 && request.mode === 'navigate') {
          const clone = response.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
        }
        return response;
      })
      .catch(() =>
        caches.match(request).then((cached) => {
          if (cached) return cached;
          if (request.mode === 'navigate') return caches.match('/');
          return new Response('Offline', { status: 503, statusText: 'Offline' });
        })
      )
  );
});

// Atualiza o cache quando o Service Worker é atualizado
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) =>
      Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log('[PWA] Limpando cache antigo:', cache);
            return caches.delete(cache);
          }
        })
      )
    ).then(() => self.clients.claim())
  );
});
