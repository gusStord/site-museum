"use client";

import {
  useCallback,
  useRef,
  useState,
  useSyncExternalStore,
  type KeyboardEvent as ReactKeyboardEvent,
  type PointerEvent as ReactPointerEvent,
} from "react";
import { ZoomIn } from "lucide-react";
import { cn } from "@/lib/utils";

/** Lens magnification — exactly 4x. */
const ZOOM = 4;
/** Lens diameter in px (w-44 / h-44 = 176px). */
const LENS_SIZE = 176;
const LENS_RADIUS = LENS_SIZE / 2;
/** Keyboard inspection step, in display px. */
const KEY_STEP = 24;

/** Cursor position as fractions (0..1) of the rendered image box. */
type LensPos = { fx: number; fy: number };

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

/* --- pointer-capability detection (reacts to changes, SSR-safe) --- */
function subscribePointerChange(onChange: () => void) {
  const mq = window.matchMedia("(pointer: fine)");
  mq.addEventListener("change", onChange);
  return () => mq.removeEventListener("change", onChange);
}
function getFinePointerSnapshot() {
  return window.matchMedia("(pointer: fine)").matches;
}
function getFinePointerServerSnapshot() {
  // Optimistic default: desktop. Updated right after hydration.
  return true;
}

type MagnifierProps = {
  src: string;
  alt: string;
  className?: string;
  /**
   * Extra classes for the underlying <img> — used to constrain the image
   * inside the dialog (e.g. "max-h-[38vh] md:max-h-[72vh]").
   */
  imgClassName?: string;
  /** Classes for the built-in touch hint (e.g. "text-stone-400" on dark panes). */
  hintClassName?: string;
};

/**
 * Follow-cursor 4x magnifier for high-resolution artworks.
 *
 * The container wraps the image exactly (fit-content), so the lens
 * percentages always map onto the visible image — even when the image is
 * constrained by max-width / max-height (e.g. inside the artwork dialog).
 */
export function Magnifier(props: MagnifierProps) {
  // Remount when the artwork changes so the lens state resets cleanly.
  return <MagnifierInner key={props.src} {...props} />;
}

function MagnifierInner({
  src,
  alt,
  className,
  imgClassName,
  hintClassName,
}: MagnifierProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const imgRef = useRef<HTMLImageElement>(null);
  const [natural, setNatural] = useState<{ w: number; h: number } | null>(null);
  const [pos, setPos] = useState<LensPos | null>(null);
  const finePointer = useSyncExternalStore(
    subscribePointerChange,
    getFinePointerSnapshot,
    getFinePointerServerSnapshot
  );

  // Runs once when the <img> is attached; covers images that were already
  // decoded (browser cache) before the onLoad listener could fire.
  const attachImgRef = useCallback((el: HTMLImageElement | null) => {
    imgRef.current = el;
    if (el && el.complete && el.naturalWidth > 0) {
      setNatural({ w: el.naturalWidth, h: el.naturalHeight });
    }
  }, []);

  const updateFromPointer = (e: ReactPointerEvent<HTMLDivElement>) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return;
    setPos({
      fx: clamp((e.clientX - rect.left) / rect.width, 0, 1),
      fy: clamp((e.clientY - rect.top) / rect.height, 0, 1),
    });
  };

  const handlePointerEnter = (e: ReactPointerEvent<HTMLDivElement>) => {
    // Touch devices never show the lens (a hint is rendered instead).
    if (e.pointerType === "touch") return;
    updateFromPointer(e);
  };

  const handlePointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (e.pointerType === "touch") return;
    updateFromPointer(e);
  };

  const handleFocus = () => {
    setPos((p) => p ?? { fx: 0.5, fy: 0.5 });
  };

  const handleBlur = () => {
    setPos(null);
  };

  const handleKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0 || rect.height === 0) return;
    const stepX = KEY_STEP / rect.width;
    const stepY = KEY_STEP / rect.height;
    const current = pos ?? { fx: 0.5, fy: 0.5 };
    let { fx, fy } = current;
    switch (e.key) {
      case "ArrowLeft":
        fx = clamp(fx - stepX, 0, 1);
        break;
      case "ArrowRight":
        fx = clamp(fx + stepX, 0, 1);
        break;
      case "ArrowUp":
        fy = clamp(fy - stepY, 0, 1);
        break;
      case "ArrowDown":
        fy = clamp(fy + stepY, 0, 1);
        break;
      default:
        return;
    }
    e.preventDefault();
    setPos({ fx, fy });
  };

  const showLens = pos !== null && natural !== null && finePointer;
  const hidingCursor = pos !== null && finePointer;

  return (
    <>
      <div
        ref={containerRef}
        role="application"
        aria-label={`Ampliação 4 vezes da obra ${alt}`}
        tabIndex={0}
        onPointerEnter={handlePointerEnter}
        onPointerMove={handlePointerMove}
        onPointerLeave={() => setPos(null)}
        onFocus={handleFocus}
        onBlur={handleBlur}
        onKeyDown={handleKeyDown}
        className={cn(
          "relative mx-auto w-fit max-w-full select-none outline-none focus-visible:ring-2 focus-visible:ring-amber-500/60",
          hidingCursor ? "cursor-none" : "cursor-zoom-in",
          className
        )}
      >
        <img
          ref={attachImgRef}
          src={src}
          alt={alt}
          draggable={false}
          decoding="async"
          onLoad={(e) => {
            const img = e.currentTarget;
            if (img.naturalWidth > 0) {
              setNatural({ w: img.naturalWidth, h: img.naturalHeight });
            }
          }}
          className={cn(
            "block h-auto w-auto max-w-full select-none",
            imgClassName
          )}
        />

        {showLens && pos && natural ? (
          <div
            aria-hidden="true"
            className="pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-1/2"
            style={{ left: `${pos.fx * 100}%`, top: `${pos.fy * 100}%` }}
          >
            <div className="relative size-44 overflow-hidden rounded-full border-2 border-amber-500/80 shadow-2xl ring-4 ring-stone-950/20">
              {/* Full image scaled 4x, positioned so the point under the
                  cursor sits exactly at the lens center. */}
              <div
                className="absolute left-0 top-0"
                style={{
                  width: natural.w * ZOOM,
                  height: natural.h * ZOOM,
                  backgroundImage: `url("${src}")`,
                  backgroundSize: `${natural.w * ZOOM}px ${natural.h * ZOOM}px`,
                  backgroundPosition: `${LENS_RADIUS - pos.fx * natural.w * ZOOM}px ${
                    LENS_RADIUS - pos.fy * natural.h * ZOOM
                  }px`,
                  backgroundRepeat: "no-repeat",
                }}
              />
              {/* Crosshair */}
              <span className="absolute left-1/2 top-1/2 h-px w-5 -translate-x-1/2 -translate-y-1/2 bg-amber-500/70" />
              <span className="absolute left-1/2 top-1/2 h-5 w-px -translate-x-1/2 -translate-y-1/2 bg-amber-500/70" />
            </div>
            {/* Magnification badge pinned to the lens top edge */}
            <span className="absolute left-1/2 top-0 -translate-x-1/2 -translate-y-1/2 rounded-full bg-stone-950/80 px-2 py-0.5 text-[10px] font-medium text-amber-400">
              4×
            </span>
          </div>
        ) : null}
      </div>

      {/* Touch devices: no lens — show a small hint instead. */}
      {!finePointer ? (
        <MagnifierHint className={cn("mt-3", hintClassName)} />
      ) : null}
    </>
  );
}

export function MagnifierHint({ className }: { className?: string }) {
  return (
    <p
      className={cn(
        "inline-flex items-center gap-2 text-xs text-muted-foreground",
        className
      )}
    >
      <ZoomIn className="size-3.5 shrink-0" aria-hidden="true" />
      <span>
        Passe o cursor sobre a obra para examinar os detalhes · ampliação 4×
      </span>
    </p>
  );
}
