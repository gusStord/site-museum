"use client";

import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Eye, Headphones, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogTitle,
} from "@/components/ui/dialog";
import { Separator } from "@/components/ui/separator";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { qk, type ArtworkDTO } from "@/lib/museum";
import { useMuseumStore } from "@/store/museum";
import { cn } from "@/lib/utils";
import { Magnifier, MagnifierHint } from "@/components/museum/magnifier";

type AudioGuideSummary = {
  slug: string;
  title: string;
  transcriptPt: string;
};

type ArtworkDetail = ArtworkDTO & {
  audioGuide: AudioGuideSummary | null;
};

async function fetchArtworkDetail(slug: string): Promise<ArtworkDetail> {
  const res = await fetch(`/api/artworks/${slug}`);
  if (!res.ok) throw new Error(`Falha ao carregar a obra (${res.status})`);
  const data = (await res.json()) as { artwork: ArtworkDetail };
  return data.artwork;
}

/**
 * Artwork viewer — dark "museum at night" dialog with the 4x magnifier,
 * technical sheet and audio-guide hand-off. Rendered once at app level;
 * it reads the selected slug from the global museum store.
 */
export function ArtworkDialog() {
  const dialogSlug = useMuseumStore((s) => s.dialogSlug);
  const closeArtworkDialog = useMuseumStore((s) => s.closeArtworkDialog);
  const requestAudio = useMuseumStore((s) => s.requestAudio);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const infoRef = useRef<HTMLDivElement>(null);
  // Likes are session-local (the API only increments, there is no "unlike").
  const [likedSlugs, setLikedSlugs] = useState<readonly string[]>([]);

  const { data: artwork } = useQuery({
    queryKey: qk.artwork(dialogSlug ?? ""),
    queryFn: async () => {
      if (!dialogSlug) throw new Error("Nenhuma obra selecionada");
      return fetchArtworkDetail(dialogSlug);
    },
    enabled: Boolean(dialogSlug),
  });

  const guide = artwork?.audioGuide ?? null;
  const isLiked = artwork ? likedSlugs.includes(artwork.slug) : false;

  // Reset the info-pane scroll whenever the artwork changes.
  useEffect(() => {
    infoRef.current?.scrollTo({ top: 0 });
  }, [dialogSlug, artwork?.id]);

  const likeMutation = useMutation({
    mutationFn: async (slug: string) => {
      const res = await fetch(`/api/artworks/${slug}/like`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Falha ao curtir a obra");
      return (await res.json()) as { likes: number };
    },
    onMutate: async (slug) => {
      await queryClient.cancelQueries({ queryKey: qk.artworks });
      const previousList = queryClient.getQueryData<ArtworkDTO[]>(qk.artworks);
      const previousDetail = queryClient.getQueryData<ArtworkDetail>(
        qk.artwork(slug)
      );
      queryClient.setQueryData<ArtworkDTO[]>(qk.artworks, (old) =>
        (old ?? []).map((a) =>
          a.slug === slug ? { ...a, likes: a.likes + 1 } : a
        )
      );
      queryClient.setQueryData<ArtworkDetail>(qk.artwork(slug), (old) =>
        old ? { ...old, likes: old.likes + 1 } : old
      );
      setLikedSlugs((prev) => [...prev, slug]);
      return { previousList, previousDetail };
    },
    onError: (_error, slug, context) => {
      if (context?.previousList) {
        queryClient.setQueryData(qk.artworks, context.previousList);
      }
      if (context?.previousDetail) {
        queryClient.setQueryData(qk.artwork(slug), context.previousDetail);
      }
      setLikedSlugs((prev) => prev.filter((s) => s !== slug));
      toast({
        title: "Não foi possível curtir a obra",
        description: "Verifique sua conexão e tente novamente.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      // Only the list — refetching the detail would inflate the view count.
      void queryClient.invalidateQueries({ queryKey: qk.artworks });
    },
  });

  const handleListen = (audioGuide: AudioGuideSummary) => {
    requestAudio(audioGuide.slug);
    closeArtworkDialog();
    document
      .getElementById("audioguia")
      ?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <Dialog
      open={Boolean(dialogSlug)}
      onOpenChange={(open) => {
        if (!open) closeArtworkDialog();
      }}
    >
      <DialogContent className="museum-scroll grid max-h-[92vh] w-[95vw] max-w-6xl gap-0 overflow-y-auto rounded-xl border-stone-800 bg-stone-950 p-0 text-stone-50 sm:max-w-6xl md:grid-cols-[1.35fr_1fr] md:overflow-hidden">
        {/* Viewing room (left) */}
        <div className="relative flex flex-col items-center justify-center gap-3 bg-stone-950 p-4 md:p-6">
          {artwork ? (
            <Magnifier
              key={artwork.slug}
              src={artwork.imageUrl}
              alt={artwork.title}
              imgClassName="max-h-[38vh] md:max-h-[72vh]"
              hintClassName="text-stone-400"
            />
          ) : (
            <Skeleton className="aspect-[4/3] w-full bg-stone-900" />
          )}
          {/* Desktop hint — on touch the Magnifier renders its own hint. */}
          <MagnifierHint className="text-stone-400 pointer-coarse:hidden" />
        </div>

        {/* Info pane (right) */}
        <div
          ref={infoRef}
          className="museum-scroll p-6 md:max-h-[85vh] md:overflow-y-auto md:p-8"
        >
          {artwork ? (
            <>
              <span
                className="inline-flex items-center rounded-full px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-white"
                style={{ backgroundColor: `${artwork.movement.color}E6` }}
              >
                {artwork.movement.name}
              </span>

              <DialogTitle className="mt-4 font-display text-3xl leading-tight text-stone-50 md:text-4xl">
                {artwork.title}
              </DialogTitle>
              <DialogDescription className="sr-only">
                Ficha técnica e ampliação em 4 vezes da obra {artwork.title},
                de {artwork.artist}.
              </DialogDescription>

              <p className="mt-2 font-display text-lg italic text-amber-300/90">
                {artwork.artist} · {artwork.year}
              </p>

              <p className="mt-4 text-sm leading-relaxed text-stone-300">
                {artwork.description}
              </p>

              <Separator className="my-6 bg-stone-800" />

              <dl className="grid grid-cols-[auto_1fr] gap-x-4 gap-y-2 text-sm">
                <dt className="text-[10px] uppercase tracking-wider text-stone-500">
                  Técnica
                </dt>
                <dd className="text-stone-200">{artwork.technique}</dd>
                <dt className="text-[10px] uppercase tracking-wider text-stone-500">
                  Dimensões
                </dt>
                <dd className="text-stone-200">{artwork.dimensions}</dd>
                <dt className="text-[10px] uppercase tracking-wider text-stone-500">
                  Localização
                </dt>
                <dd className="text-stone-200">{artwork.location}</dd>
              </dl>

              <div className="mt-6 flex items-center gap-3 text-sm text-stone-400">
                <span className="inline-flex items-center gap-1.5">
                  <Eye className="size-4" aria-hidden="true" />
                  {artwork.views} visitas
                </span>
                <span aria-hidden="true" className="text-stone-600">
                  ·
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Heart className="size-4" aria-hidden="true" />
                  {artwork.likes} curtidas
                </span>
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                <Button
                  type="button"
                  variant="outline"
                  disabled={isLiked}
                  onClick={() => likeMutation.mutate(artwork.slug)}
                  aria-label={
                    isLiked
                      ? `Obra já curtida: ${artwork.title}`
                      : `Curtir ${artwork.title}`
                  }
                  className="h-11 border-stone-700 bg-transparent text-stone-200 hover:bg-stone-800 hover:text-stone-100"
                >
                  <Heart
                    className={cn(
                      "size-4",
                      isLiked && "fill-amber-400 text-amber-400"
                    )}
                    aria-hidden="true"
                  />
                  {isLiked ? "Curtida" : "Curtir"}
                </Button>

                {guide ? (
                  <Button
                    type="button"
                    onClick={() => handleListen(guide)}
                    className="h-11 bg-amber-500 text-stone-950 hover:bg-amber-400"
                  >
                    <Headphones className="size-4" aria-hidden="true" />
                    Ouvir audioguia
                  </Button>
                ) : null}
              </div>
            </>
          ) : (
            <>
              <DialogTitle className="sr-only">Carregando obra</DialogTitle>
              <DialogDescription className="sr-only">
                Carregando a ficha técnica da obra.
              </DialogDescription>
              <div className="space-y-4">
                <Skeleton className="h-6 w-28 rounded-full bg-stone-900" />
                <Skeleton className="h-10 w-3/4 bg-stone-900" />
                <Skeleton className="h-5 w-1/2 bg-stone-900" />
                <Skeleton className="h-28 w-full bg-stone-900" />
                <Skeleton className="h-20 w-full bg-stone-900" />
              </div>
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
