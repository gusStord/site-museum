"use client";

import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import Image from "next/image";
import { AnimatePresence, motion, type Variants } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import {
  AlertCircle,
  BookOpen,
  Check,
  ChevronDown,
  FastForward,
  Headphones,
  Landmark,
  Pause,
  Play,
  RotateCcw,
  Volume1,
  Volume2,
  VolumeX,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { Skeleton } from "@/components/ui/skeleton";
import { Slider } from "@/components/ui/slider";
import { useToast } from "@/hooks/use-toast";
import { fetchTracks, qk, type AudioTrackDTO } from "@/lib/museum";
import { useMuseumStore } from "@/store/museum";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Constants & helpers                                                 */
/* ------------------------------------------------------------------ */

/** Big ring: SVG 224x224, progress circle r = 96 (starts at 12h via rotate(-90)). */
const RING_SIZE = 224;
const RING_RADIUS = 96;
const RING_CIRCUMFERENCE = 2 * Math.PI * RING_RADIUS;

/** Mini ring inside track rows: SVG 56x56, artwork circle 44px, ring r = 26. */
const MINI_RING_CIRCUMFERENCE = 2 * Math.PI * 26;

const SPEEDS: readonly number[] = [1, 1.25, 1.5];
const SEEK_SECONDS = 10;
const COMPLETE_THRESHOLD = 0.999;

const fmt = (seconds: number | undefined): string => {
  if (seconds === undefined || !Number.isFinite(seconds) || seconds < 0) return "—";
  const total = Math.floor(seconds);
  const m = Math.floor(total / 60);
  const s = total % 60;
  return `${m}:${String(s).padStart(2, "0")}`;
};

/* ------------------------------------------------------------------ */
/* Tiny presentational helpers                                         */
/* ------------------------------------------------------------------ */

function LangChip({ children }: { children: ReactNode }) {
  return (
    <span className="inline-flex items-center rounded-full border border-amber-600/40 px-2 py-0.5 text-[10px] font-medium tracking-wider text-amber-700 dark:border-amber-500/40 dark:text-amber-400">
      {children}
    </span>
  );
}

/** Animated equalizer bars — shown only while a track is playing. */
function Equalizer() {
  return (
    <span className="flex h-3.5 items-end gap-[3px]" aria-hidden="true">
      {[0, 1, 2, 3].map((i) => (
        <motion.span
          key={i}
          className="h-full w-[3px] origin-bottom rounded-full bg-amber-600"
          animate={{ scaleY: [0.25, 1, 0.4, 0.85, 0.25] }}
          transition={{
            duration: 1.15 + i * 0.15,
            repeat: Infinity,
            ease: "easeInOut",
            delay: i * 0.14,
          }}
        />
      ))}
    </span>
  );
}

const listVariants: Variants = {
  hidden: {},
  show: { transition: { staggerChildren: 0.07 } },
};

const rowVariants: Variants = {
  hidden: { opacity: 0, y: 10 },
  show: { opacity: 1, y: 0, transition: { duration: 0.35, ease: "easeOut" } },
};

/* ------------------------------------------------------------------ */
/* Audio guide section                                                 */
/* ------------------------------------------------------------------ */

export function AudioGuideSection() {
  const { toast } = useToast();
  const { data, isLoading } = useQuery({
    queryKey: qk.tracks,
    queryFn: fetchTracks,
  });
  const sorted = useMemo(
    () => [...(data ?? [])].sort((a, b) => a.order - b.order),
    [data]
  );

  const audioRequestSlug = useMuseumStore((s) => s.audioRequestSlug);
  const clearAudioRequest = useMuseumStore((s) => s.clearAudioRequest);

  /* ------------------------------ state ------------------------------ */
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [hasStarted, setHasStarted] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [rate, setRate] = useState(1);
  const [volume, setVolume] = useState(1);
  const [muted, setMuted] = useState(false);
  const [transcriptOpen, setTranscriptOpen] = useState(false);

  /** slug -> 0..1 listened progress (remembered per track, drives every ring). */
  const [progressMap, setProgressMap] = useState<Record<string, number>>({});
  /** slug -> duration in seconds (probed sequentially via preload="metadata"). */
  const [durationMap, setDurationMap] = useState<Record<string, number>>({});
  /** slugs whose audio failed to load. */
  const [errorSlugs, setErrorSlugs] = useState<ReadonlySet<string>>(new Set());

  /* ------------------------------- refs ------------------------------ */
  const audioRef = useRef<HTMLAudioElement | null>(null);
  /** set when the next src change should start playing immediately. */
  const playIntentRef = useRef(false);
  /** remembered progress (0..1) to restore once metadata of the new src loads. */
  const pendingProgressRef = useRef(0);
  const rateRef = useRef(1);
  const probedRef = useRef<Set<string>>(new Set());
  const rowRefs = useRef<Map<string, HTMLDivElement>>(new Map());
  const prevActiveRef = useRef<string | null>(null);

  // Derived selection: the user-picked track, else the first track (no autoplay).
  const activeSlug = useMemo(() => {
    if (selectedSlug && sorted.some((t) => t.slug === selectedSlug)) return selectedSlug;
    return sorted[0]?.slug ?? null;
  }, [selectedSlug, sorted]);

  const activeIndex = activeSlug ? sorted.findIndex((t) => t.slug === activeSlug) : -1;
  const activeTrack: AudioTrackDTO | null = activeIndex >= 0 ? sorted[activeIndex] ?? null : null;

  const progress = duration > 0 ? Math.min(currentTime / duration, 1) : 0;
  const liveMessage = activeTrack
    ? isPlaying
      ? `Reproduzindo: ${activeTrack.title}`
      : `Pausado: ${activeTrack.title}`
    : "";

  /* --------------------------- core actions -------------------------- */

  const safePlay = useCallback(() => {
    const a = audioRef.current;
    if (!a) return;
    a.play().catch((err: unknown) => {
      // AbortError = interrupted by pause()/load(); only policy blocks deserve a toast.
      if (err instanceof DOMException && err.name === "NotAllowedError") {
        toast({
          title: "Toque no botão de reprodução para iniciar",
          variant: "destructive",
        });
      }
      setIsPlaying(false);
    });
  }, [toast]);

  const safePause = useCallback(() => {
    audioRef.current?.pause();
  }, []);

  const seekTo = useCallback(
    (time: number) => {
      const a = audioRef.current;
      if (!a || !activeTrack) return;
      const d = a.duration;
      if (!Number.isFinite(d) || d <= 0) return;
      const t = Math.max(0, Math.min(d, time));
      a.currentTime = t;
      setCurrentTime(t);
      setProgressMap((prev) => ({ ...prev, [activeTrack.slug]: t / d }));
    },
    [activeTrack]
  );

  const seekBy = useCallback(
    (delta: number) => {
      const a = audioRef.current;
      if (!a) return;
      seekTo(a.currentTime + delta);
    },
    [seekTo]
  );

  const goToTrack = useCallback(
    (delta: number) => {
      const idx = sorted.findIndex((t) => t.slug === activeSlug);
      if (idx < 0) return;
      const nextIdx = idx + delta;
      if (nextIdx < 0 || nextIdx >= sorted.length) return;
      const next = sorted[nextIdx];
      if (!next) return;
      if ((progressMap[next.slug] ?? 0) >= COMPLETE_THRESHOLD) {
        setProgressMap((prev) => ({ ...prev, [next.slug]: 0 }));
      }
      pendingProgressRef.current = 0;
      playIntentRef.current = true;
      setSelectedSlug(next.slug);
    },
    [sorted, activeSlug, progressMap]
  );

  const togglePlay = useCallback(() => {
    const a = audioRef.current;
    if (!a || !activeTrack) return;
    if (a.paused) {
      if (a.ended || (progressMap[activeTrack.slug] ?? 0) >= COMPLETE_THRESHOLD) {
        a.currentTime = 0;
        setProgressMap((prev) => ({ ...prev, [activeTrack.slug]: 0 }));
      }
      safePlay();
    } else {
      a.pause();
    }
  }, [activeTrack, progressMap, safePlay]);

  /** Row click: select + autoplay (user gesture); same track toggles play/pause. */
  const handleSelectTrack = useCallback(
    (slug: string) => {
      const track = sorted.find((t) => t.slug === slug);
      const a = audioRef.current;
      if (!track || !a) return;

      if (slug === activeSlug) {
        if (a.paused) {
          if (a.ended || (progressMap[slug] ?? 0) >= COMPLETE_THRESHOLD) {
            a.currentTime = 0;
            setProgressMap((prev) => ({ ...prev, [slug]: 0 }));
          }
          safePlay();
        } else {
          a.pause();
        }
        return;
      }

      const remembered = progressMap[slug] ?? 0;
      if (remembered >= COMPLETE_THRESHOLD) {
        setProgressMap((prev) => ({ ...prev, [slug]: 0 }));
        pendingProgressRef.current = 0;
      } else {
        pendingProgressRef.current = remembered;
      }
      playIntentRef.current = true;
      setSelectedSlug(slug);
    },
    [sorted, activeSlug, progressMap, safePlay]
  );

  /* ------------------------ <audio> event handlers -------------------- */

  const handlePlayEvent = () => {
    setIsPlaying(true);
    setHasStarted(true);
  };

  const handleTimeUpdate = () => {
    const a = audioRef.current;
    if (!a || !activeTrack) return;
    const d = a.duration;
    if (!Number.isFinite(d) || d <= 0) return;
    const t = a.currentTime;
    const p = t / d;
    setCurrentTime(t);
    setProgressMap((prev) =>
      Math.abs((prev[activeTrack.slug] ?? 0) - p) < 0.0005
        ? prev
        : { ...prev, [activeTrack.slug]: p }
    );
  };

  // Fresh load for the active track: reset the clock (and the ring) right away.
  const handleLoadStart = () => {
    if (!activeTrack) return;
    setCurrentTime(0);
    setDuration(durationMap[activeTrack.slug] ?? 0);
    if (pendingProgressRef.current <= 0) {
      setProgressMap((prev) =>
        prev[activeTrack.slug] ? { ...prev, [activeTrack.slug]: 0 } : prev
      );
    }
  };

  const handleLoadedMetadata = () => {
    const a = audioRef.current;
    if (!a || !activeTrack) return;
    a.playbackRate = rateRef.current;
    a.defaultPlaybackRate = rateRef.current;
    const d = a.duration;
    if (Number.isFinite(d) && d > 0) {
      setDuration(d);
      setDurationMap((prev) =>
        prev[activeTrack.slug] === d ? prev : { ...prev, [activeTrack.slug]: d }
      );
      // Restore remembered position for a track the visitor left mid-way.
      const pending = pendingProgressRef.current;
      if (pending > 0 && pending < COMPLETE_THRESHOLD) {
        a.currentTime = Math.min(pending * d, Math.max(0, d - 0.05));
        setCurrentTime(a.currentTime);
      }
    }
    pendingProgressRef.current = 0;
    setErrorSlugs((prev) => {
      if (!prev.has(activeTrack.slug)) return prev;
      const next = new Set(prev);
      next.delete(activeTrack.slug);
      return next;
    });
  };

  const handleEnded = () => {
    const a = audioRef.current;
    if (!a || !activeTrack) return;
    setProgressMap((prev) => ({ ...prev, [activeTrack.slug]: 1 }));
    setIsPlaying(false);
    goToTrack(1); // auto-advance; stops after the last track
  };

  const handleAudioError = () => {
    if (!activeTrack) return;
    setErrorSlugs((prev) => {
      if (prev.has(activeTrack.slug)) return prev;
      const next = new Set(prev);
      next.add(activeTrack.slug);
      return next;
    });
    setIsPlaying(false);
    toast({
      title: "Não foi possível carregar o áudio. Tente novamente.",
      variant: "destructive",
    });
  };

  /* ------------------------- ring seek (atan2) ----------------------- */

  const handleRingSeek = (e: React.MouseEvent<HTMLButtonElement>) => {
    if (e.detail === 0) return; // keyboard-synthesized click: ignore coordinates
    const a = audioRef.current;
    if (!a || !Number.isFinite(a.duration) || a.duration <= 0) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - (rect.left + rect.width / 2);
    const y = e.clientY - (rect.top + rect.height / 2);
    // atan2: 0 at 3h, clockwise (screen y grows down). Ring starts at 12h (-pi/2).
    const angle = Math.atan2(y, x);
    const normalized = (angle + Math.PI / 2 + 2 * Math.PI) % (2 * Math.PI);
    seekTo((normalized / (2 * Math.PI)) * a.duration);
  };

  const handleRingKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === "ArrowLeft") {
      e.preventDefault();
      seekBy(-SEEK_SECONDS);
    } else if (e.key === "ArrowRight") {
      e.preventDefault();
      seekBy(SEEK_SECONDS);
    } else if (e.key === "Home") {
      e.preventDefault();
      seekTo(0);
    } else if (e.key === "End") {
      e.preventDefault();
      const d = audioRef.current?.duration ?? 0;
      if (Number.isFinite(d)) seekTo(d);
    }
  };

  /* ----------------------------- controls ---------------------------- */

  const cycleRate = () => {
    const idx = SPEEDS.indexOf(rate);
    setRate(SPEEDS[(idx + 1) % SPEEDS.length] ?? 1);
  };

  const handleVolumeChange = (values: number[]) => {
    const v = (values[0] ?? 0) / 100;
    setVolume(v);
    setMuted(v === 0);
    const a = audioRef.current;
    if (a) {
      a.volume = v;
      a.muted = v === 0;
    }
  };

  const toggleMute = () => {
    const next = !muted;
    setMuted(next);
    const a = audioRef.current;
    if (a) a.muted = next;
  };

  const VolumeIcon = muted || volume === 0 ? VolumeX : volume < 0.5 ? Volume1 : Volume2;

  /* ------------------------------ effects ---------------------------- */

  // Playback rate (also re-applied after each src load, see loadedmetadata).
  useEffect(() => {
    rateRef.current = rate;
    const a = audioRef.current;
    if (a) {
      a.playbackRate = rate;
      a.defaultPlaybackRate = rate;
    }
  }, [rate]);

  // Single source of truth: swap the audio src when the active track changes,
  // then honour the play intent (row click / auto-advance / store request).
  // Clock/ring resets happen in the audio element's own onLoadStart event.
  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;
    if (!activeTrack) {
      if (a.src) {
        a.pause();
        a.removeAttribute("src");
      }
      return;
    }
    const absolute = new URL(activeTrack.audioUrl, window.location.href).href;
    if (a.src === absolute) return;
    a.pause();
    a.src = activeTrack.audioUrl;
    a.playbackRate = rateRef.current;
    a.defaultPlaybackRate = rateRef.current;
    if (playIntentRef.current) {
      playIntentRef.current = false;
      safePlay();
    }
  }, [activeTrack, safePlay]);

  // Lazily probe each track's duration (sequential, metadata-only) so rows can
  // show durations before they are ever played.
  useEffect(() => {
    if (!sorted.length) return;
    const queue = sorted.filter((t) => !probedRef.current.has(t.slug));
    if (!queue.length) return;
    let cancelled = false;
    const probeOne = (track: AudioTrackDTO) =>
      new Promise<void>((resolve) => {
        if (typeof window === "undefined" || typeof Audio === "undefined") {
          resolve();
          return;
        }
        const el = document.createElement("audio");
        el.preload = "metadata";
        let settled = false;
        const finish = () => {
          if (!settled) {
            settled = true;
            resolve();
          }
        };
        el.addEventListener("loadedmetadata", () => {
          if (Number.isFinite(el.duration) && el.duration > 0) {
            setDurationMap((prev) =>
              prev[track.slug] === el.duration ? prev : { ...prev, [track.slug]: el.duration }
            );
          }
          finish();
        });
        el.addEventListener("error", finish);
        window.setTimeout(finish, 15000);
        el.src = track.audioUrl;
      });
    void (async () => {
      for (const track of queue) {
        if (cancelled) return;
        await probeOne(track);
        probedRef.current.add(track.slug);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [sorted]);

  // Artwork dialog integration: "Ouvir audioguia" requests a track by slug.
  // Reuses the row-click selection path from an async callback so every state
  // update stays inside event-style handlers.
  // NOTE: clearAudioRequest() must run INSIDE the timer callback. Calling it
  // synchronously in the effect body flips audioRequestSlug back to null,
  // which changes this effect's deps and runs the cleanup — cancelling the
  // 0ms timer before handleSelectTrack ever fires (the requested track never
  // played). Clearing inside the callback keeps the timer alive.
  useEffect(() => {
    if (!audioRequestSlug) return;
    const slug = audioRequestSlug;
    if (!sorted.some((t) => t.slug === slug)) return;
    document
      .getElementById("audioguia")
      ?.scrollIntoView({ behavior: "smooth", block: "start" });
    const timer = window.setTimeout(() => {
      clearAudioRequest();
      handleSelectTrack(slug);
    }, 0);
    return () => window.clearTimeout(timer);
  }, [audioRequestSlug, sorted, handleSelectTrack]);

  // Keep the active row visible when the selection changes (skips the silent
  // initial selection, which arrives from `null`).
  useEffect(() => {
    const prev = prevActiveRef.current;
    prevActiveRef.current = activeSlug;
    if (!activeSlug || !prev || prev === activeSlug) return;
    rowRefs.current.get(activeSlug)?.scrollIntoView({ block: "nearest", behavior: "smooth" });
  }, [activeSlug]);

  // Media Session API (guarded) — lockscreen / hardware key metadata + controls.
  useEffect(() => {
    if (typeof navigator === "undefined" || !("mediaSession" in navigator) || !activeTrack) return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: activeTrack.title,
        artist: activeTrack.artwork
          ? `${activeTrack.artwork.artist} · ${activeTrack.artwork.year}`
          : activeTrack.narrator,
        album: "Musæum · Audioguia",
        artwork: activeTrack.artwork
          ? [{ src: activeTrack.artwork.imageUrl, sizes: "512x512" }]
          : [],
      });
    } catch {
      // MediaMetadata unavailable — ignore.
    }
  }, [activeTrack]);

  const mediaControlsRef = useRef<{
    play: () => void;
    pause: () => void;
    seekBackward: () => void;
    seekForward: () => void;
    previous: () => void;
    next: () => void;
    seekTo: (seconds: number) => void;
  }>({
    play: () => undefined,
    pause: () => undefined,
    seekBackward: () => undefined,
    seekForward: () => undefined,
    previous: () => undefined,
    next: () => undefined,
    seekTo: () => undefined,
  });

  // Mirror the latest handlers (fresh closures) for the Media Session actions.
  useEffect(() => {
    mediaControlsRef.current = {
      play: safePlay,
      pause: safePause,
      seekBackward: () => seekBy(-SEEK_SECONDS),
      seekForward: () => seekBy(SEEK_SECONDS),
      previous: () => goToTrack(-1),
      next: () => goToTrack(1),
      seekTo: (seconds: number) => seekTo(seconds),
    };
  });

  useEffect(() => {
    if (typeof navigator === "undefined" || !("mediaSession" in navigator)) return;
    const session = navigator.mediaSession;
    const register = (
      action: MediaSessionAction,
      handler: (details: MediaSessionActionDetails) => void
    ) => {
      try {
        session.setActionHandler(action, handler);
      } catch {
        // Action unsupported on this browser — ignore.
      }
    };
    register("play", () => mediaControlsRef.current.play());
    register("pause", () => mediaControlsRef.current.pause());
    register("seekbackward", () => mediaControlsRef.current.seekBackward());
    register("seekforward", () => mediaControlsRef.current.seekForward());
    register("previoustrack", () => mediaControlsRef.current.previous());
    register("nexttrack", () => mediaControlsRef.current.next());
    register("seekto", (details) => {
      if (typeof details.seekTime === "number") mediaControlsRef.current.seekTo(details.seekTime);
    });
  }, []);

  // Stop playback when the section unmounts.
  useEffect(() => {
    return () => {
      audioRef.current?.pause();
    };
  }, []);

  /* ------------------------------ render ----------------------------- */

  return (
    <section id="audioguia" className="bg-background py-20 md:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <p className="sr-only" aria-live="polite">
          {liveMessage}
        </p>

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5, ease: "easeOut" }}
        >
          <p className="text-xs font-medium tracking-[0.25em] text-amber-700/80">AUDIOTOUR</p>
          <div className="mt-3 flex flex-wrap items-end justify-between gap-x-6 gap-y-3">
            <h2 className="font-display text-4xl md:text-5xl">Audioguia</h2>
            <div className="flex items-center gap-2 pb-1.5">
              <LangChip>EN</LangChip>
              <span className="text-xs text-muted-foreground">
                Narração em inglês · leitura em português
              </span>
            </div>
          </div>
          <p className="mt-4 max-w-2xl text-muted-foreground">
            Sete faixas narradas para visitar o museu com os ouvidos — cada anel acompanha o
            progresso da audição em tempo real.
          </p>
        </motion.div>

        {isLoading ? (
          /* --------------------------- loading --------------------------- */
          <div className="mt-10 grid gap-8 md:mt-12 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-12">
            <Card className="gap-0 overflow-hidden border-border/80 py-0 shadow-lg">
              <Skeleton className="h-28 rounded-none md:h-32" />
              <div className="flex flex-col items-center gap-5 px-5 pb-6 pt-6">
                <Skeleton className="size-56 rounded-full" />
                <div className="flex w-full flex-col items-center gap-2">
                  <Skeleton className="h-5 w-44" />
                  <Skeleton className="h-4 w-28" />
                </div>
                <div className="flex items-center gap-2">
                  {[0, 1, 2, 3, 4].map((i) => (
                    <Skeleton key={i} className="size-11 rounded-full" />
                  ))}
                </div>
                <Skeleton className="h-9 w-full rounded-lg" />
              </div>
            </Card>
            <div>
              <div className="mb-4 flex items-center gap-3">
                <Skeleton className="h-6 w-24" />
                <Skeleton className="h-5 w-9 rounded-full" />
              </div>
              <div className="space-y-2">
                {Array.from({ length: 6 }).map((_, i) => (
                  <Skeleton key={i} className="h-20 w-full rounded-xl" />
                ))}
              </div>
            </div>
          </div>
        ) : !sorted.length ? (
          /* ---------------------------- empty ---------------------------- */
          <p className="mt-10 text-center text-sm text-muted-foreground">
            Nenhuma faixa disponível no momento.
          </p>
        ) : (
          /* ---------------------------- content -------------------------- */
          <div className="mt-10 grid gap-8 md:mt-12 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-12">
            {/* ----------------------- now playing ----------------------- */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, ease: "easeOut", delay: 0.05 }}
            >
              <Card className="gap-0 overflow-hidden border-border/80 py-0 shadow-lg">
                {/* header strip */}
                {activeTrack?.artwork ? (
                  <div className="relative h-28 md:h-32">
                    <Image
                      src={activeTrack.artwork.imageUrl}
                      alt={activeTrack.artwork.title}
                      fill
                      sizes="(min-width: 1024px) 40vw, 100vw"
                      className="object-cover"
                    />
                    <div
                      className="absolute inset-0 bg-gradient-to-t from-black/65 via-black/25 to-transparent"
                      aria-hidden="true"
                    />
                    <div className="absolute inset-x-4 bottom-3 flex items-end justify-between gap-3">
                      <p className="font-display line-clamp-1 text-lg leading-snug text-white drop-shadow-md">
                        {activeTrack.artwork.title}
                      </p>
                      <span className="shrink-0 rounded-full bg-white/85 px-2.5 py-0.5 text-[10px] font-medium tracking-wider text-amber-950 backdrop-blur-sm">
                        {activeTrack.artwork.movementName}
                      </span>
                    </div>
                  </div>
                ) : (
                  <div className="flex h-28 items-center gap-3 bg-gradient-to-br from-amber-200/60 via-amber-100/40 to-stone-100 px-5 md:h-32">
                    <Landmark className="size-7 shrink-0 text-amber-700" aria-hidden="true" />
                    <p className="font-display text-lg text-amber-950/80">Musæum · Boas-vindas</p>
                  </div>
                )}

                <div className="px-5 pb-6 sm:px-6">
                  {/* circular progress ring (seekable) */}
                  <div className="relative mx-auto my-6 w-fit pb-7">
                    <button
                      type="button"
                      onClick={handleRingSeek}
                      onKeyDown={handleRingKeyDown}
                      aria-label="Ajustar posição da audição"
                      className="relative block h-56 w-56 cursor-pointer rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 focus-visible:ring-offset-card"
                    >
                      <svg viewBox={`0 0 ${RING_SIZE} ${RING_SIZE}`} className="h-full w-full">
                        <circle
                          cx="112"
                          cy="112"
                          r="108"
                          fill="none"
                          strokeWidth="1"
                          className="stroke-border"
                        />
                        <circle
                          cx="112"
                          cy="112"
                          r={RING_RADIUS}
                          fill="none"
                          strokeWidth="6"
                          className="stroke-muted"
                        />
                        <circle
                          cx="112"
                          cy="112"
                          r={RING_RADIUS}
                          fill="none"
                          strokeWidth="6"
                          strokeLinecap="round"
                          className="stroke-amber-600"
                          strokeDasharray={RING_CIRCUMFERENCE}
                          strokeDashoffset={RING_CIRCUMFERENCE * (1 - progress)}
                          transform={`rotate(-90 112 112)`}
                          style={{ transition: "stroke-dashoffset 250ms linear" }}
                        />
                      </svg>

                      {/* rotating dashed halo while playing (decorative) */}
                      {isPlaying && (
                        <motion.span
                          className="absolute inset-0"
                          animate={{ rotate: 360 }}
                          transition={{ duration: 14, repeat: Infinity, ease: "linear" }}
                          aria-hidden="true"
                        >
                          <svg viewBox="0 0 224 224" className="h-full w-full">
                            <circle
                              cx="112"
                              cy="112"
                              r="72"
                              fill="none"
                              strokeWidth="2"
                              strokeDasharray="2 10"
                              strokeLinecap="round"
                              className="stroke-amber-500/40"
                            />
                          </svg>
                        </motion.span>
                      )}

                      {/* artwork thumbnail (or gold circle for the welcome track) */}
                      <span className="absolute inset-0 grid place-items-center">
                        {activeTrack?.artwork ? (
                          <Image
                            src={activeTrack.artwork.imageUrl}
                            alt={activeTrack.artwork.title}
                            width={112}
                            height={112}
                            className="h-28 w-28 rounded-full object-cover shadow-md ring-4 ring-card"
                          />
                        ) : (
                          <span className="grid h-28 w-28 place-items-center rounded-full bg-gradient-to-br from-amber-500 to-amber-600 text-white shadow-md ring-4 ring-card">
                            <Headphones className="size-10" aria-hidden="true" />
                          </span>
                        )}
                      </span>
                    </button>

                    {/* play/pause overlapping the ring bottom */}
                    <Button
                      type="button"
                      onClick={togglePlay}
                      aria-label={isPlaying ? "Pausar faixa" : "Reproduzir faixa"}
                      className="absolute bottom-0 left-1/2 size-14 -translate-x-1/2 translate-y-1/2 rounded-full bg-amber-600 text-white shadow-lg hover:bg-amber-500"
                    >
                      <AnimatePresence mode="wait" initial={false}>
                        <motion.span
                          key={isPlaying ? "pause" : "play"}
                          initial={{ scale: 0.6, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0.6, opacity: 0 }}
                          transition={{ duration: 0.18 }}
                          className="grid place-items-center"
                        >
                          {isPlaying ? (
                            <Pause className="size-6" aria-hidden="true" />
                          ) : (
                            <Play className="size-6 translate-x-0.5" aria-hidden="true" />
                          )}
                        </motion.span>
                      </AnimatePresence>
                    </Button>
                  </div>

                  {/* title, meta & time */}
                  <div className="text-center">
                    <h3 className="font-display text-xl leading-snug text-foreground">
                      {activeTrack?.title}
                    </h3>
                    <p className="mt-1 text-sm text-muted-foreground">
                      {activeTrack?.artwork
                        ? `${activeTrack.artwork.artist} · ${activeTrack.artwork.year}`
                        : activeTrack?.narrator}
                    </p>
                    <p className="mt-2 font-mono text-sm tabular-nums text-muted-foreground">
                      {fmt(currentTime)} / {duration > 0 ? fmt(duration) : "—"}
                    </p>
                    {!hasStarted && (
                      <p className="mt-1 text-xs tracking-wide text-amber-700/90">
                        Escolha uma faixa para começar
                      </p>
                    )}
                  </div>

                  {/* controls */}
                  <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => seekBy(-SEEK_SECONDS)}
                      aria-label="Voltar 10 segundos"
                      className="h-11 gap-1.5 rounded-full px-4"
                    >
                      <RotateCcw className="size-4" aria-hidden="true" />
                      <span className="font-mono text-xs">-10s</span>
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={togglePlay}
                      aria-label={isPlaying ? "Pausar faixa" : "Reproduzir faixa"}
                      className="size-11 rounded-full"
                    >
                      {isPlaying ? (
                        <Pause className="size-5" aria-hidden="true" />
                      ) : (
                        <Play className="size-5 translate-x-px" aria-hidden="true" />
                      )}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => seekBy(SEEK_SECONDS)}
                      aria-label="Avançar 10 segundos"
                      className="h-11 gap-1.5 rounded-full px-4"
                    >
                      <FastForward className="size-4" aria-hidden="true" />
                      <span className="font-mono text-xs">+10s</span>
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={cycleRate}
                      aria-label={`Velocidade de reprodução ${rate}×`}
                      className="h-11 min-w-11 rounded-full px-3 font-mono text-xs"
                    >
                      {rate}×
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={toggleMute}
                      aria-label={muted || volume === 0 ? "Ativar som" : "Silenciar"}
                      className="size-11 rounded-full"
                    >
                      <VolumeIcon className="size-5" aria-hidden="true" />
                    </Button>
                    <Slider
                      aria-label="Volume"
                      className="w-24 shrink-0"
                      min={0}
                      max={100}
                      step={1}
                      value={[Math.round(volume * 100)]}
                      onValueChange={handleVolumeChange}
                    />
                  </div>

                  {/* transcript */}
                  <div className="mt-6 border-t border-border/70 pt-3">
                    <Collapsible open={transcriptOpen} onOpenChange={setTranscriptOpen}>
                      <CollapsibleTrigger asChild>
                        <Button
                          type="button"
                          variant="ghost"
                          className="group w-full justify-between rounded-lg px-3 py-2 text-sm font-medium text-foreground"
                        >
                          <span className="flex items-center gap-2">
                            <BookOpen className="size-4 text-amber-700" aria-hidden="true" />
                            Transcrição · leia enquanto ouve
                          </span>
                          <ChevronDown
                            className="size-4 text-muted-foreground transition-transform duration-300 group-data-[state=open]:rotate-180"
                            aria-hidden="true"
                          />
                        </Button>
                      </CollapsibleTrigger>
                      <CollapsibleContent className="space-y-4 px-3 pb-2 pt-3">
                        <div className="space-y-2">
                          <LangChip>PT</LangChip>
                          <p className="text-sm leading-relaxed text-foreground">
                            {activeTrack?.transcriptPt}
                          </p>
                        </div>
                        <div className="space-y-2 border-l-2 border-amber-600/40 pl-4">
                          <LangChip>EN</LangChip>
                          <p className="text-sm italic leading-relaxed text-muted-foreground">
                            {activeTrack?.transcript}
                          </p>
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  </div>
                </div>
              </Card>
            </motion.div>

            {/* ------------------------- track list ------------------------ */}
            <motion.div
              variants={listVariants}
              initial="hidden"
              whileInView="show"
              viewport={{ once: true, margin: "-60px" }}
            >
              <div className="mb-4 flex items-center gap-3">
                <h3 className="font-display text-xl text-foreground">Faixas</h3>
                <Badge
                  variant="outline"
                  className="rounded-full border-amber-600/30 px-2.5 tabular-nums text-amber-800 dark:border-amber-500/40 dark:text-amber-400"
                >
                  {sorted.length}
                </Badge>
                {isPlaying && <Equalizer />}
              </div>

              <div role="list" className="museum-scroll max-h-[520px] space-y-2 overflow-y-auto pr-2">
                {sorted.map((track) => {
                  const isActive = track.slug === activeSlug;
                  const rowProgress = progressMap[track.slug] ?? 0;
                  const isCompleted = rowProgress >= COMPLETE_THRESHOLD;
                  const rowPlaying = isActive && isPlaying;
                  const hasError = errorSlugs.has(track.slug);
                  return (
                    <motion.div
                      key={track.slug}
                      role="listitem"
                      variants={rowVariants}
                      ref={(el) => {
                        if (el) rowRefs.current.set(track.slug, el);
                        else rowRefs.current.delete(track.slug);
                      }}
                    >
                      <button
                        type="button"
                        onClick={() => handleSelectTrack(track.slug)}
                        aria-current={isActive ? "true" : undefined}
                        className={cn(
                          "relative flex w-full items-center gap-4 rounded-xl border p-3 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60",
                          isActive
                            ? "border-amber-600/60 bg-amber-50/50 ring-1 ring-amber-600/25 dark:border-amber-500/50 dark:bg-amber-400/10 dark:ring-amber-500/20"
                            : "border-border hover:border-amber-600/30 hover:bg-muted/40"
                        )}
                      >
                        {isActive && (
                          <motion.span
                            layoutId="audio-active-row"
                            className="absolute left-1 top-1/2 h-9 w-1 -translate-y-1/2 rounded-full bg-amber-600"
                            transition={{ duration: 0.4, ease: "easeOut" }}
                            aria-hidden="true"
                          />
                        )}

                        {/* mini progress ring around the artwork */}
                        <span className="relative grid size-14 shrink-0 place-items-center">
                          <svg viewBox="0 0 56 56" className="absolute inset-0 size-14" aria-hidden="true">
                            <circle
                              cx="28"
                              cy="28"
                              r="26"
                              fill="none"
                              strokeWidth="3"
                              className="stroke-border"
                            />
                            <circle
                              cx="28"
                              cy="28"
                              r="26"
                              fill="none"
                              strokeWidth="3"
                              strokeLinecap="round"
                              className="stroke-amber-600"
                              strokeDasharray={MINI_RING_CIRCUMFERENCE}
                              strokeDashoffset={MINI_RING_CIRCUMFERENCE * (1 - rowProgress)}
                              transform="rotate(-90 28 28)"
                              style={{ transition: "stroke-dashoffset 250ms linear" }}
                            />
                          </svg>
                          {track.artwork ? (
                            <Image
                              src={track.artwork.imageUrl}
                              alt=""
                              width={44}
                              height={44}
                              className="size-11 rounded-full object-cover"
                            />
                          ) : (
                            <span className="grid size-11 place-items-center rounded-full bg-gradient-to-br from-amber-400 to-amber-600 text-white">
                              <Landmark className="size-4" aria-hidden="true" />
                            </span>
                          )}
                          {/* status icon */}
                          <span className="absolute inset-0 grid place-items-center">
                            <span
                              className={cn(
                                "grid place-items-center rounded-full",
                                rowPlaying
                                  ? "size-6 bg-foreground/50 text-white backdrop-blur-[1px]"
                                  : isCompleted
                                    ? "size-5 bg-amber-600 text-white"
                                    : "size-6 bg-foreground/40 text-white backdrop-blur-[1px]"
                              )}
                              aria-hidden="true"
                            >
                              {rowPlaying ? (
                                <Pause className="size-3" />
                              ) : isCompleted ? (
                                <Check className="size-3" />
                              ) : (
                                <Play className="size-3 translate-x-px" />
                              )}
                            </span>
                          </span>
                        </span>

                        {/* text column */}
                        <span className="min-w-0 flex-1">
                          <span className="block text-sm font-medium leading-snug text-foreground line-clamp-2">
                            {track.title}
                          </span>
                          <span className="mt-0.5 block truncate text-xs text-muted-foreground">
                            {track.artwork
                              ? `${track.artwork.artist} · ${track.artwork.movementName}`
                              : track.narrator}
                          </span>
                        </span>

                        {/* duration + language / error */}
                        <span className="flex shrink-0 flex-col items-end gap-1">
                          <span className="font-mono text-xs tabular-nums text-muted-foreground">
                            {hasError ? "—" : fmt(durationMap[track.slug])}
                          </span>
                          {hasError ? (
                            <AlertCircle
                              className="size-3.5 text-destructive"
                              aria-label="Erro ao carregar áudio"
                            />
                          ) : (
                            <LangChip>EN</LangChip>
                          )}
                        </span>
                      </button>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        )}
      </div>

      {/* single audio element — every control drives this one source */}
      <audio
        ref={audioRef}
        preload="metadata"
        className="hidden"
        onLoadStart={handleLoadStart}
        onPlay={handlePlayEvent}
        onPause={() => setIsPlaying(false)}
        onTimeUpdate={handleTimeUpdate}
        onLoadedMetadata={handleLoadedMetadata}
        onEnded={handleEnded}
        onError={handleAudioError}
      />
    </section>
  );
}

export default AudioGuideSection;
