"use client";

import { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Flashlight,
  FlashlightOff,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { fetchArtworks, fetchStats, qk } from "@/lib/museum";
import { cn } from "@/lib/utils";

/** Auto-advance cadence (ms). */
const SLIDE_INTERVAL = 6500;

export function HeroSpotlight() {
  const { data: artworks } = useQuery({
    queryKey: qk.artworks,
    queryFn: fetchArtworks,
  });
  const { data: stats } = useQuery({
    queryKey: qk.stats,
    queryFn: fetchStats,
  });
  const reducedMotion = useReducedMotion();

  const slides = (artworks ?? [])
    .filter((a) => a.featured)
    .slice(0, 6);

  const [index, setIndex] = useState(0);
  /** Wrapped index — always valid even if the slide list changes. */
  const safeIndex = slides.length > 0 ? index % slides.length : 0;

  /** Lantern mode ON = dark room + flashlight beam (default aesthetic). */
  const [lanternOn, setLanternOn] = useState(true);

  const sectionRef = useRef<HTMLElement>(null);
  const rafRef = useRef<number | null>(null);
  const pointerSeenRef = useRef(false);

  // Auto-advance: pauses while the tab is hidden; the interval is recreated
  // whenever the index changes, so manual navigation resets the timer.
  useEffect(() => {
    if (slides.length <= 1) return;
    const id = window.setInterval(() => {
      if (document.hidden) return;
      setIndex((i) => (i + 1) % slides.length);
    }, SLIDE_INTERVAL);
    return () => window.clearInterval(id);
  }, [index, slides.length]);

  // Ambient spotlight sweep (Lissajous) until the visitor takes over with a
  // real pointer (mouse/pen). Touch devices keep the ambient sweep forever.
  useEffect(() => {
    if (reducedMotion) return;
    const el = sectionRef.current;
    if (!el) return;
    const tick = (t: number) => {
      const x = 50 + 32 * Math.sin(t * 0.00035);
      const y = 42 + 18 * Math.sin(t * 0.00021);
      el.style.setProperty("--mx", `${x}%`);
      el.style.setProperty("--my", `${y}%`);
      rafRef.current = requestAnimationFrame(tick);
    };
    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current !== null) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
  }, [reducedMotion]);

  const handlePointerMove = (e: React.PointerEvent<HTMLElement>) => {
    // Only a real pointer (mouse/pen) takes over the spotlight.
    if (e.pointerType === "touch") return;
    if (!pointerSeenRef.current) {
      pointerSeenRef.current = true;
      if (rafRef.current !== null) {
        cancelAnimationFrame(rafRef.current);
        rafRef.current = null;
      }
    }
    const el = sectionRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    el.style.setProperty("--mx", `${x}%`);
    el.style.setProperty("--my", `${y}%`);
  };

  const goPrev = () =>
    setIndex((i) => (i - 1 + slides.length) % slides.length);
  const goNext = () => setIndex((i) => (i + 1) % slides.length);

  const current = slides.length > 0 ? slides[safeIndex] : undefined;

  return (
    <section
      id="inicio"
      ref={sectionRef}
      onPointerMove={handlePointerMove}
      aria-label="Destaques da coleção"
      className="relative h-[92svh] min-h-[560px] overflow-hidden bg-stone-950 text-stone-50"
    >
      {/* Cross-fade slide layers with a subtle Ken-Burns drift */}
      {slides.length > 0 ? (
        slides.map((slide, i) => {
          const isActive = i === safeIndex;
          return (
            <motion.img
              key={slide.slug}
              src={slide.imageUrl}
              alt={`${slide.title} — ${slide.artist}, ${slide.year}`}
              draggable={false}
              loading={i === 0 ? "eager" : "lazy"}
              decoding="async"
              className="absolute inset-0 h-full w-full object-cover"
              initial={{ opacity: 0, scale: 1.06 }}
              animate={{
                opacity: isActive ? 1 : 0,
                scale: reducedMotion
                  ? 1.06
                  : isActive
                    ? 1.12
                    : 1.06,
              }}
              transition={{
                opacity: {
                  duration: reducedMotion ? 0.3 : 1.6,
                  ease: "easeInOut",
                },
                scale: {
                  duration: reducedMotion ? 0 : isActive ? 9 : 1.6,
                  ease: "linear",
                },
              }}
            />
          );
        })
      ) : (
        <Skeleton className="absolute inset-0 h-full w-full rounded-none bg-stone-900" />
      )}

      {/* Spotlight — warm beam of the lantern */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 z-[1]"
        style={{
          background:
            "radial-gradient(circle 340px at var(--mx,50%) var(--my,45%), rgba(255,236,197,0.12), transparent 60%)",
        }}
      />
      {/* Spotlight — darkening (the room at night); can be disabled for accessibility */}
      <div
        aria-hidden="true"
        className={cn(
          "pointer-events-none absolute inset-0 z-[2] transition-opacity duration-500",
          !lanternOn && "opacity-0"
        )}
        style={{
          background:
            "radial-gradient(circle 340px at var(--mx,50%) var(--my,45%), transparent 0%, rgba(12,10,9,0.62) 72%)",
        }}
      />

      {/* Bottom gradient for legibility */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 bottom-0 z-[3] h-40 bg-gradient-to-t from-stone-950/90 via-stone-950/20 to-transparent"
      />

      {/* Lantern toggle */}
      <button
        type="button"
        onClick={() => setLanternOn((v) => !v)}
        aria-pressed={lanternOn}
        aria-label="Alternar modo lanterna"
        title="Alternar modo lanterna"
        className={cn(
          "absolute right-6 top-6 z-20 flex size-11 items-center justify-center rounded-full border backdrop-blur transition-colors",
          lanternOn
            ? "border-amber-500/40 bg-stone-950/50 text-amber-400 hover:bg-stone-900/70"
            : "border-stone-700 bg-stone-950/50 text-stone-300 hover:bg-stone-900/70"
        )}
      >
        {lanternOn ? (
          <Flashlight className="size-5" aria-hidden="true" />
        ) : (
          <FlashlightOff className="size-5" aria-hidden="true" />
        )}
      </button>

      {/* Copy */}
      <div className="relative z-10 mx-auto flex h-full max-w-6xl flex-col justify-center px-6 pb-32 sm:pb-28">
        <p className="text-xs tracking-[0.3em] text-amber-400/90">
          COLEÇÃO PERMANENTE · 1400–1955
        </p>
        <h1 className="mt-4 font-display text-6xl font-medium tracking-tight text-stone-50 md:text-8xl">
          Musæum
        </h1>
        <p className="mt-6 max-w-xl text-base leading-relaxed text-stone-300 md:text-lg">
          Seis séculos de arte em um só lugar — obras-primas em alta resolução,
          linha do tempo dos movimentos, tour virtual 3D e audioguia narrado.
        </p>

        <div className="mt-8 flex flex-wrap items-center gap-4">
          <Button
            asChild
            size="lg"
            className="h-11 bg-amber-500 px-7 text-stone-950 hover:bg-amber-400"
          >
            <a href="#colecao">Explorar a coleção</a>
          </Button>
          <Button
            asChild
            size="lg"
            variant="outline"
            className="h-11 border-stone-600 bg-transparent px-7 text-stone-200 hover:bg-stone-800/60 hover:text-stone-100"
          >
            <a href="#tour">Tour virtual 3D</a>
          </Button>
        </div>

        {stats ? (
          <p className="mt-8 flex flex-wrap items-center gap-x-3 gap-y-2 text-sm text-stone-400">
            <span>{stats.artworks} obras-primas</span>
            <span aria-hidden="true" className="size-1 rounded-full bg-amber-400/70" />
            <span>{stats.movements} movimentos</span>
            <span aria-hidden="true" className="size-1 rounded-full bg-amber-400/70" />
            <span>{stats.rooms} salas 3D</span>
            <span aria-hidden="true" className="size-1 rounded-full bg-amber-400/70" />
            <span>{stats.tracks} faixas de audioguia</span>
          </p>
        ) : null}
      </div>

      {/* Caption + controls */}
      <div className="absolute inset-x-0 bottom-0 z-10">
        <div className="mx-auto flex max-w-6xl items-end justify-between gap-4 px-6 pb-5">
          <div className="min-w-0 max-w-md">
            <AnimatePresence mode="wait">
              {current ? (
                <motion.div
                  key={current.slug}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.4, ease: "easeOut" }}
                >
                  <p className="font-display text-xl text-stone-50 md:text-2xl">
                    {current.title}
                  </p>
                  <p className="mt-1 text-sm text-stone-400">
                    {current.artist} · {current.year}
                  </p>
                </motion.div>
              ) : null}
            </AnimatePresence>
          </div>

          {slides.length > 0 ? (
            <div className="flex shrink-0 items-center gap-2">
              <button
                type="button"
                onClick={goPrev}
                aria-label="Obra anterior"
                className="flex size-11 items-center justify-center rounded-full border border-stone-700 bg-stone-900/60 text-stone-200 backdrop-blur transition-colors hover:bg-stone-800"
              >
                <ChevronLeft className="size-5" aria-hidden="true" />
              </button>
              <div className="flex items-center gap-1.5 px-1">
                {slides.map((slide, i) => (
                  <button
                    key={slide.slug}
                    type="button"
                    onClick={() => setIndex(i)}
                    aria-label={`Ver obra ${i + 1} de ${slides.length}: ${slide.title}`}
                    aria-current={i === safeIndex}
                    className={cn(
                      "h-2 rounded-full transition-all duration-300",
                      i === safeIndex
                        ? "w-6 bg-amber-400"
                        : "w-2 bg-stone-600 hover:bg-stone-400"
                    )}
                  />
                ))}
              </div>
              <button
                type="button"
                onClick={goNext}
                aria-label="Próxima obra"
                className="flex size-11 items-center justify-center rounded-full border border-stone-700 bg-stone-900/60 text-stone-200 backdrop-blur transition-colors hover:bg-stone-800"
              >
                <ChevronRight className="size-5" aria-hidden="true" />
              </button>
            </div>
          ) : null}
        </div>

        {/* Scroll hint */}
        <div className="flex justify-center pb-4">
          <a
            href="#colecao"
            className="flex size-11 items-center justify-center rounded-full text-stone-400 transition-colors hover:bg-stone-800/60 hover:text-stone-100"
          >
            <ChevronDown className="size-5 animate-bounce" aria-hidden="true" />
            <span className="sr-only">Rolar para a coleção</span>
          </a>
        </div>
      </div>
    </section>
  );
}
