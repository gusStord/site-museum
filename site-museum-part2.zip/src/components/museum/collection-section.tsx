"use client";

import { useMemo, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Heart, ImageOff } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { fetchArtworks, qk, type ArtworkDTO } from "@/lib/museum";
import { useMuseumStore } from "@/store/museum";
import { cn } from "@/lib/utils";

const FILTER_ALL = "todos";

export function CollectionSection() {
  const { data: artworks, isLoading } = useQuery({
    queryKey: qk.artworks,
    queryFn: fetchArtworks,
  });
  const openArtworkDialog = useMuseumStore((s) => s.openArtworkDialog);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [activeMovement, setActiveMovement] = useState<string>(FILTER_ALL);
  // Likes are session-local (the API only increments, there is no "unlike").
  const [likedSlugs, setLikedSlugs] = useState<readonly string[]>([]);

  const movements = useMemo(() => {
    const seen = new Map<string, ArtworkDTO["movement"]>();
    for (const a of artworks ?? []) {
      if (!seen.has(a.movement.slug)) seen.set(a.movement.slug, a.movement);
    }
    return [...seen.values()];
  }, [artworks]);

  const filtered = useMemo(() => {
    if (!artworks) return [];
    if (activeMovement === FILTER_ALL) return artworks;
    return artworks.filter((a) => a.movement.slug === activeMovement);
  }, [artworks, activeMovement]);

  const likeMutation = useMutation({
    mutationFn: async (slug: string) => {
      const res = await fetch(`/api/artworks/${slug}/like`, {
        method: "POST",
      });
      if (!res.ok) throw new Error("Falha ao curtir a obra");
      return (await res.json()) as { likes: number };
    },
    onMutate: async (slug) => {
      await queryClient.cancelQueries({ queryKey: qk.artworks });
      const previous = queryClient.getQueryData<ArtworkDTO[]>(qk.artworks);
      queryClient.setQueryData<ArtworkDTO[]>(qk.artworks, (old) =>
        (old ?? []).map((a) =>
          a.slug === slug ? { ...a, likes: a.likes + 1 } : a
        )
      );
      setLikedSlugs((prev) => [...prev, slug]);
      return { previous };
    },
    onError: (_error, slug, context) => {
      if (context?.previous) {
        queryClient.setQueryData(qk.artworks, context.previous);
      }
      setLikedSlugs((prev) => prev.filter((s) => s !== slug));
      toast({
        title: "Não foi possível curtir a obra",
        description: "Verifique sua conexão e tente novamente.",
        variant: "destructive",
      });
    },
    onSettled: () => {
      void queryClient.invalidateQueries({ queryKey: qk.artworks });
    },
  });

  const handleLike = (artwork: ArtworkDTO) => {
    // One like per artwork per session — the API only increments.
    if (likedSlugs.includes(artwork.slug)) return;
    likeMutation.mutate(artwork.slug);
  };

  return (
    <section id="colecao" className="bg-background py-20 md:py-24">
      <div className="mx-auto max-w-6xl px-6">
        <header className="max-w-2xl">
          <p className="text-xs tracking-[0.25em] text-amber-700/80">
            O ACERVO
          </p>
          <h2 className="mt-3 font-display text-4xl leading-tight text-foreground md:text-5xl">
            A Coleção
          </h2>
          <p className="mt-4 text-muted-foreground">
            Obras-primas de domínio público em alta resolução. Clique em uma
            obra para examiná-la com a lupa de 4×, ler a ficha técnica e ouvir
            o audioguia.
          </p>
        </header>

        {/* Movement filter chips */}
        {artworks && movements.length > 0 ? (
          <div
            role="group"
            aria-label="Filtrar por movimento artístico"
            className="no-scrollbar mt-10 flex gap-2 overflow-x-auto py-1"
          >
            <button
              type="button"
              onClick={() => setActiveMovement(FILTER_ALL)}
              aria-pressed={activeMovement === FILTER_ALL}
              className={cn(
                "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border px-4 text-sm transition-colors",
                activeMovement === FILTER_ALL
                  ? "border-transparent bg-foreground text-background"
                  : "border-border bg-card text-foreground hover:border-foreground/30 hover:bg-accent"
              )}
            >
              <span
                aria-hidden="true"
                className="size-2 rounded-full bg-amber-500"
              />
              Todos
            </button>
            {movements.map((m) => {
              const isActive = activeMovement === m.slug;
              return (
                <button
                  key={m.slug}
                  type="button"
                  onClick={() => setActiveMovement(m.slug)}
                  aria-pressed={isActive}
                  className={cn(
                    "inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border px-4 text-sm transition-colors",
                    isActive
                      ? "border-transparent text-white"
                      : "border-border bg-card text-foreground hover:border-foreground/30 hover:bg-accent"
                  )}
                  style={isActive ? { backgroundColor: m.color } : undefined}
                >
                  <span
                    aria-hidden="true"
                    className="size-2 rounded-full"
                    style={{ backgroundColor: m.color }}
                  />
                  {m.name}
                </button>
              );
            })}
          </div>
        ) : null}

        {/* Result count */}
        {artworks ? (
          <p
            aria-live="polite"
            className="mt-6 text-sm text-muted-foreground md:text-right"
          >
            {filtered.length} de {artworks.length} obras
          </p>
        ) : null}

        {/* Grid */}
        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2 md:gap-8 lg:grid-cols-3">
          {isLoading
            ? Array.from({ length: 6 }, (_, i) => (
                <div key={`skeleton-${i}`} aria-hidden="true">
                  <Skeleton className="aspect-[4/5] w-full rounded-xl" />
                  <Skeleton className="mt-3 h-5 w-3/4" />
                  <Skeleton className="mt-2 h-4 w-1/2" />
                </div>
              ))
            : filtered.map((artwork, index) => {
                const isLiked = likedSlugs.includes(artwork.slug);
                return (
                  <motion.article
                    key={artwork.slug}
                    role="button"
                    tabIndex={0}
                    aria-label={`Ver obra ${artwork.title}`}
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true, margin: "-48px" }}
                    transition={{
                      duration: 0.5,
                      delay: index * 0.05,
                      ease: "easeOut",
                    }}
                    onClick={() => openArtworkDialog(artwork.slug)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        openArtworkDialog(artwork.slug);
                      }
                    }}
                    className="group cursor-pointer rounded-xl focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-700/50"
                  >
                    <figure className="relative aspect-[4/5] overflow-hidden rounded-xl bg-stone-100 shadow-sm ring-1 ring-black/5">
                      <img
                        src={artwork.imageUrl}
                        alt={`${artwork.title} — ${artwork.artist}, ${artwork.year}`}
                        loading="lazy"
                        decoding="async"
                        draggable={false}
                        className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-[1.04]"
                      />
                      <span
                        className="absolute left-3 top-3 rounded-full px-3 py-1 text-[11px] font-medium uppercase tracking-wider text-white backdrop-blur"
                        style={{ backgroundColor: `${artwork.movement.color}E6` }}
                      >
                        {artwork.movement.name}
                      </span>
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleLike(artwork);
                        }}
                        disabled={isLiked}
                        aria-label={
                          isLiked
                            ? `Obra já curtida: ${artwork.title}`
                            : `Curtir ${artwork.title}`
                        }
                        className="absolute right-2 top-2 flex h-11 items-center gap-1.5 rounded-full bg-stone-950/45 px-3 text-stone-100 backdrop-blur transition-colors hover:bg-stone-950/70 disabled:cursor-default disabled:opacity-90"
                      >
                        <Heart
                          className={cn(
                            "size-4 shrink-0",
                            isLiked && "fill-amber-400 text-amber-400"
                          )}
                          aria-hidden="true"
                        />
                        <span className="text-xs font-medium tabular-nums">
                          {artwork.likes}
                        </span>
                      </button>
                    </figure>
                    <div className="mt-3 px-0.5">
                      <h3 className="font-display text-lg leading-snug transition-colors group-hover:text-amber-800">
                        {artwork.title}
                      </h3>
                      <p className="mt-0.5 text-sm text-muted-foreground">
                        {artwork.artist} · {artwork.year}
                      </p>
                    </div>
                  </motion.article>
                );
              })}

          {!isLoading && artworks && filtered.length === 0 ? (
            <div className="col-span-full flex flex-col items-center gap-3 py-16 text-center">
              <ImageOff
                className="size-6 text-stone-300"
                aria-hidden="true"
              />
              <p className="font-display text-xl italic text-muted-foreground">
                Nenhuma obra neste movimento.
              </p>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}
