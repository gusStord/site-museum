"use client";

import {
  memo,
  useCallback,
  useEffect,
  useRef,
  useState,
  type KeyboardEvent as ReactKeyboardEvent,
  type PointerEvent as ReactPointerEvent,
  type ReactNode,
} from "react";
import { useQuery } from "@tanstack/react-query";
import { AnimatePresence, motion } from "framer-motion";
import {
  Compass,
  DoorOpen,
  Footprints,
  Hand,
  Info,
  LoaderCircle,
  Maximize,
  Minimize,
  Minus,
  MonitorOff,
  Plus,
  TriangleAlert,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { fetchRooms, qk, type HotspotDTO, type TourRoomDTO } from "@/lib/museum";
import { useMuseumStore } from "@/store/museum";

/* ------------------------------------------------------------------ */
/* Types                                                               */
/* ------------------------------------------------------------------ */

/** Hotspot projected to viewer coordinates (recomputed each frame by the engine). */
type ScreenHotspot = {
  hs: HotspotDTO;
  /** px, relative to the viewer wrapper */
  x: number;
  /** px, relative to the viewer wrapper */
  y: number;
  /** subtle depth cue derived from NDC z */
  scale: number;
};

/** Structural event accepted by the engine pan handler (native & React synthetic). */
type PanStartEvent = {
  clientX: number;
  clientY: number;
  pointerId: number;
  currentTarget: EventTarget | null;
};

/** Short eased tween used by "Recentralizar visão". */
type ViewTween = {
  t0: number;
  dur: number;
  fromLon: number;
  toLon: number;
  fromLat: number;
  toLat: number;
  fromFov: number;
  toFov: number;
};

/** Imperative API exposed by the three.js engine (created once on mount). */
type EngineAPI = {
  loadRoom: (room: TourRoomDTO) => Promise<void>;
  resetView: () => void;
  zoomBy: (delta: number) => void;
  nudge: (dLon: number, dLat: number) => void;
  panStart: (e: PanStartEvent) => void;
  isClickSuppressed: () => boolean;
};

/** Hotspots sit slightly inside the 500-unit panorama sphere. */
const HOTSPOT_RADIUS = 460;

/* ------------------------------------------------------------------ */
/* Small building blocks                                               */
/* ------------------------------------------------------------------ */

function ControlButton({
  label,
  onClick,
  children,
}: {
  label: string;
  onClick: () => void;
  children: ReactNode;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      title={label}
      onClick={onClick}
      className="grid size-11 cursor-pointer place-items-center rounded-full border border-stone-700 bg-stone-950/70 text-stone-200 backdrop-blur transition-colors hover:border-amber-500/60 hover:text-amber-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-400/70"
    >
      {children}
    </button>
  );
}

type HotspotLayerProps = {
  hotspots: ScreenHotspot[];
  pressedId: string | null;
  onTeleport: (hs: HotspotDTO) => void;
  onInfo: (hs: HotspotDTO) => void;
  onPanStart: (e: ReactPointerEvent<HTMLElement>) => void;
};

/**
 * HTML overlay with the projected hotspots. Memoized so the 60fps position
 * updates coming from the engine only re-render this tiny subtree.
 */
const HotspotLayer = memo(function HotspotLayer({
  hotspots,
  pressedId,
  onTeleport,
  onInfo,
  onPanStart,
}: HotspotLayerProps) {
  return (
    <div className="pointer-events-none absolute inset-0 z-10">
      {hotspots.map(({ hs, x, y, scale }) => {
        const pressed = pressedId === hs.id;
        if (hs.type === "teleport") {
          return (
            <button
              key={hs.id}
              type="button"
              aria-label={hs.label}
              onPointerDown={onPanStart}
              onClick={() => onTeleport(hs)}
              className="pointer-events-auto absolute grid size-12 cursor-pointer touch-none place-items-center rounded-full border-2 border-amber-400 bg-amber-500/15 backdrop-blur-sm transition-transform duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-amber-300"
              style={{
                left: x,
                top: y,
                transform: `translate(-50%, -50%) scale(${pressed ? scale * 0.82 : scale})`,
              }}
            >
              <motion.span
                aria-hidden
                className="absolute inset-0 rounded-full border-2 border-amber-400/40"
                animate={{ scale: [1, 1.9], opacity: [0.55, 0] }}
                transition={{ duration: 2.2, repeat: Infinity, ease: "easeOut" }}
              />
              <Footprints className="relative size-5 text-amber-300" aria-hidden />
              <span className="pointer-events-none absolute left-1/2 top-full mt-2 -translate-x-1/2 whitespace-nowrap rounded-full border border-amber-500/30 bg-stone-950/80 px-2.5 py-1 text-[11px] text-amber-200">
                {hs.label}
              </span>
            </button>
          );
        }
        return (
          <button
            key={hs.id}
            type="button"
            aria-label={hs.label}
            onPointerDown={onPanStart}
            onClick={() => onInfo(hs)}
            className="pointer-events-auto absolute grid size-11 cursor-pointer touch-none place-items-center rounded-full border border-stone-100/70 bg-stone-950/60 backdrop-blur-sm transition-transform duration-150 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-stone-100/80"
            style={{
              left: x,
              top: y,
              transform: `translate(-50%, -50%) scale(${pressed ? scale * 0.82 : scale})`,
            }}
          >
            <Info className="size-5 text-stone-100" aria-hidden />
            <span className="pointer-events-none absolute left-1/2 top-full mt-2 -translate-x-1/2 whitespace-nowrap rounded-full border border-stone-100/30 bg-stone-950/80 px-2.5 py-1 text-[11px] text-stone-100">
              {hs.label}
            </span>
          </button>
        );
      })}
    </div>
  );
});

/* ------------------------------------------------------------------ */
/* Viewer                                                              */
/* ------------------------------------------------------------------ */

function TourViewer({ rooms }: { rooms: TourRoomDTO[] }) {
  const wrapperRef = useRef<HTMLDivElement>(null);
  const canvasHostRef = useRef<HTMLDivElement>(null);
  const engineRef = useRef<EngineAPI | null>(null);
  /** Room waiting to be loaded by the engine (bridges React -> engine race on mount). */
  const pendingRoomRef = useRef<TourRoomDTO | null>(rooms[0] ?? null);
  const pressedTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const noticeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [activeSlug, setActiveSlug] = useState(rooms[0]?.slug ?? "");
  const [screenHotspots, setScreenHotspots] = useState<ScreenHotspot[]>([]);
  const [loading, setLoading] = useState(true);
  const [faded, setFaded] = useState(true);
  const [webglFailed, setWebglFailed] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [hasInteracted, setHasInteracted] = useState(false);
  const [notice, setNotice] = useState<{ key: number; title: string } | null>(null);
  const [pressedId, setPressedId] = useState<string | null>(null);

  const openArtworkDialog = useMuseumStore((s) => s.openArtworkDialog);
  const activeRoom = rooms.find((r) => r.slug === activeSlug) ?? rooms[0];

  /** Brief centered toast (room intro / errors), auto-dismissed. */
  const pushNotice = useCallback((title: string) => {
    setNotice({ key: Date.now(), title });
    if (noticeTimerRef.current) clearTimeout(noticeTimerRef.current);
    noticeTimerRef.current = setTimeout(() => setNotice(null), 1700);
  }, []);

  /* ---------------------------------------------------------------- */
  /* three.js engine — created exactly once, never on re-renders.     */
  /* All mutable viewer state lives in the closure below.             */
  /* ---------------------------------------------------------------- */
  useEffect(() => {
    const host = canvasHostRef.current;
    const wrapper = wrapperRef.current;
    if (!host || !wrapper) return;

    let disposed = false;
    const cleanups: Array<() => void> = [];

    const run = async () => {
      let threeModule: typeof import("three") | null = null;
      try {
        threeModule = await import("three");
      } catch {
        /* dynamic import failed */
      }
      if (!threeModule) {
        if (!disposed) setWebglFailed(true);
        return;
      }
      const THREE = threeModule;
      if (disposed) return;

      /* Engine-owned canvas: survives React re-renders untouched and
         guarantees a fresh WebGL context on every (re)init. */
      const canvas = document.createElement("canvas");
      canvas.className =
        "absolute inset-0 block h-full w-full cursor-grab select-none active:cursor-grabbing";
      canvas.style.touchAction = "none";
      canvas.setAttribute("role", "img");
      canvas.setAttribute("aria-label", "Visão panorâmica 360 graus do museu");

      let rendererObj: import("three").WebGLRenderer | null = null;
      try {
        rendererObj = new THREE.WebGLRenderer({ canvas, antialias: true });
      } catch {
        rendererObj = null;
      }
      if (!rendererObj) {
        if (!disposed) setWebglFailed(true);
        return;
      }
      const renderer = rendererObj;
      host.appendChild(canvas);

      renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;

      const scene = new THREE.Scene();
      let sizeW = Math.max(wrapper.clientWidth, 1);
      let sizeH = Math.max(wrapper.clientHeight, 1);
      const camera = new THREE.PerspectiveCamera(75, sizeW / sizeH, 1, 1100);

      const geometry = new THREE.SphereGeometry(500, 64, 40);
      geometry.scale(-1, 1, 1);
      /* Dark until the first panorama arrives (color is reset to white on load). */
      const material = new THREE.MeshBasicMaterial({ color: 0x1c1917 });
      scene.add(new THREE.Mesh(geometry, material));

      const loader = new THREE.TextureLoader();
      const lookTarget = new THREE.Vector3();
      const ndc = new THREE.Vector3();
      renderer.setSize(sizeW, sizeH, false);

      /* --- mutable viewer state --- */
      let lon = 0;
      let lat = 0;
      let fov = 75;
      let velLon = 0;
      let velLat = 0;
      let dragging = false;
      let activePointerId = -1;
      let lastX = 0;
      let lastY = 0;
      let lastT = 0;
      let totalMove = 0;
      let suppressClickUntil = 0;
      let tween: ViewTween | null = null;
      let currentRoom: TourRoomDTO | null = null;
      let activeHotspots: HotspotDTO[] = [];
      let loadToken = 0;
      let prevSig = "\u0000";
      let rafId = 0;

      const sleep = (ms: number) =>
        new Promise<void>((resolve) => {
          setTimeout(resolve, ms);
        });

      /* --- hotspot projection (HTML overlay, no raycast) --- */
      const projectHotspots = () => {
        if (activeHotspots.length === 0) {
          if (prevSig !== "") {
            prevSig = "";
            setScreenHotspots([]);
          }
          return;
        }
        const list: ScreenHotspot[] = [];
        for (const hs of activeHotspots) {
          const phi = THREE.MathUtils.degToRad(90 - hs.lat);
          const theta = THREE.MathUtils.degToRad(hs.lon);
          ndc.set(
            HOTSPOT_RADIUS * Math.sin(phi) * Math.cos(theta),
            HOTSPOT_RADIUS * Math.cos(phi),
            HOTSPOT_RADIUS * Math.sin(phi) * Math.sin(theta)
          );
          ndc.project(camera);
          if (
            ndc.z < 1 &&
            ndc.x > -1.05 &&
            ndc.x < 1.05 &&
            ndc.y > -1.05 &&
            ndc.y < 1.05
          ) {
            list.push({
              hs,
              x: ((ndc.x + 1) / 2) * sizeW,
              y: ((1 - ndc.y) / 2) * sizeH,
              scale: THREE.MathUtils.clamp(1.6 - ndc.z * 0.5, 0.8, 1.15),
            });
          }
        }
        /* Skip no-op React updates when the camera is stationary. */
        const sig = list
          .map(
            (s) =>
              `${s.hs.id}:${Math.round(s.x)}:${Math.round(s.y)}:${Math.round(s.scale * 20)}`
          )
          .join("|");
        if (sig !== prevSig) {
          prevSig = sig;
          setScreenHotspots(list);
        }
      };

      /* --- render loop --- */
      const tick = (now: number) => {
        if (disposed) return;
        rafId = requestAnimationFrame(tick);

        if (tween) {
          const p = Math.min(1, (now - tween.t0) / tween.dur);
          const e = 1 - Math.pow(1 - p, 3);
          lon = tween.fromLon + (tween.toLon - tween.fromLon) * e;
          lat = tween.fromLat + (tween.toLat - tween.fromLat) * e;
          fov = tween.fromFov + (tween.toFov - tween.fromFov) * e;
          camera.fov = fov;
          camera.updateProjectionMatrix();
          if (p >= 1) tween = null;
        } else if (!dragging && (velLon !== 0 || velLat !== 0)) {
          /* inertia after drag release */
          lon += velLon;
          lat = THREE.MathUtils.clamp(lat + velLat, -85, 85);
          velLon *= 0.93;
          velLat *= 0.93;
          if (Math.abs(velLon) < 0.01) velLon = 0;
          if (Math.abs(velLat) < 0.01) velLat = 0;
        }

        lat = THREE.MathUtils.clamp(lat, -85, 85);
        const phi = THREE.MathUtils.degToRad(90 - lat);
        const theta = THREE.MathUtils.degToRad(lon);
        lookTarget.set(
          Math.sin(phi) * Math.cos(theta),
          Math.cos(phi),
          Math.sin(phi) * Math.sin(theta)
        );
        camera.lookAt(lookTarget);
        renderer.render(scene, camera);
        projectHotspots();
      };

      /* --- room switching (fade out -> swap texture -> fade in) --- */
      const loadRoom = async (room: TourRoomDTO) => {
        if (disposed) return;
        if (currentRoom?.slug === room.slug && material.map) return;
        const token = ++loadToken;

        activeHotspots = [];
        if (prevSig !== "") {
          prevSig = "";
          setScreenHotspots([]);
        }
        setLoading(true);
        setFaded(true);
        await sleep(300); /* let the ~280ms fade finish */
        if (disposed || token !== loadToken) return;

        let tex: import("three").Texture | null = null;
        try {
          tex = await loader.loadAsync(room.panoramaUrl);
        } catch {
          tex = null;
        }
        if (disposed) {
          tex?.dispose();
          return;
        }
        if (token !== loadToken) {
          /* a newer teleport superseded this one */
          tex?.dispose();
          return;
        }
        if (!tex) {
          activeHotspots = currentRoom?.hotspots ?? [];
          setLoading(false);
          setFaded(false);
          pushNotice(`Não foi possível carregar a sala ${room.name}.`);
          return;
        }

        const oldTexture = material.map;
        tex.colorSpace = THREE.SRGBColorSpace;
        material.map = tex;
        material.color.setRGB(1, 1, 1);
        material.needsUpdate = true;
        if (oldTexture) oldTexture.dispose();

        currentRoom = room;
        activeHotspots = room.hotspots;
        lon = 0;
        lat = 0;
        velLon = 0;
        velLat = 0;
        tween = null;
        fov = 75;
        camera.fov = 75;
        camera.updateProjectionMatrix();
        canvas.setAttribute(
          "aria-label",
          `Visão panorâmica 360 graus da sala ${room.name}`
        );
        setLoading(false);
        setFaded(false);
        setActiveSlug(room.slug);
        pushNotice(room.name);
      };

      /* --- imperative controls --- */
      const resetView = () => {
        /* nearest multiple of 360 ≡ 0, so we never spin more than 180° */
        const toLon = Math.round(lon / 360) * 360;
        tween = {
          t0: performance.now(),
          dur: 600,
          fromLon: lon,
          toLon,
          fromLat: lat,
          toLat: 0,
          fromFov: fov,
          toFov: 75,
        };
        velLon = 0;
        velLat = 0;
      };

      const zoomBy = (delta: number) => {
        tween = null;
        fov = THREE.MathUtils.clamp(fov + delta, 35, 95);
        camera.fov = fov;
        camera.updateProjectionMatrix();
      };

      const nudge = (dLon: number, dLat: number) => {
        tween = null;
        velLon = 0;
        velLat = 0;
        lon += dLon;
        lat = THREE.MathUtils.clamp(lat + dLat, -85, 85);
      };

      /* --- pointer handling (works for canvas AND hotspot buttons) --- */
      const panStart = (e: PanStartEvent) => {
        const el = e.currentTarget;
        if (el && typeof (el as HTMLElement).setPointerCapture === "function") {
          try {
            (el as HTMLElement).setPointerCapture(e.pointerId);
          } catch {
            /* capture is best-effort */
          }
        }
        activePointerId = e.pointerId;
        dragging = true;
        totalMove = 0;
        suppressClickUntil = 0;
        velLon = 0;
        velLat = 0;
        tween = null;
        lastX = e.clientX;
        lastY = e.clientY;
        lastT = performance.now();
        setHasInteracted(true);
      };

      const onPointerMove = (e: PointerEvent) => {
        if (!dragging || e.pointerId !== activePointerId) return;
        const dx = e.clientX - lastX;
        const dy = e.clientY - lastY;
        if (dx === 0 && dy === 0) return;
        const now = performance.now();
        const dt = Math.max(4, now - lastT);
        lastX = e.clientX;
        lastY = e.clientY;
        lastT = now;
        totalMove += Math.abs(dx) + Math.abs(dy);

        /* drag right -> lon decreases: the panorama follows the cursor */
        const k = 0.18 * (fov / 75);
        const dLon = -dx * k;
        const dLat = dy * k;
        lon += dLon;
        lat = THREE.MathUtils.clamp(lat + dLat, -85, 85);

        /* smoothed velocity (per ~16ms frame) for inertia on release */
        const frameFactor = Math.min(4, 16 / dt);
        velLon = velLon * 0.55 + dLon * frameFactor * 0.45;
        velLat = velLat * 0.55 + dLat * frameFactor * 0.45;
      };

      const endPointer = (e: PointerEvent, cancelled: boolean) => {
        if (e.pointerId !== activePointerId) return;
        dragging = false;
        activePointerId = -1;
        if (cancelled) {
          velLon = 0;
          velLat = 0;
          return;
        }
        if (totalMove > 4) {
          /* suppress the click that fires right after a real drag */
          suppressClickUntil = performance.now() + 150;
        }
      };

      const onPointerUp = (e: PointerEvent) => endPointer(e, false);
      const onPointerCancel = (e: PointerEvent) => endPointer(e, true);

      const onWheel = (e: WheelEvent) => {
        e.preventDefault();
        tween = null;
        fov = THREE.MathUtils.clamp(fov + e.deltaY * 0.05, 35, 95);
        camera.fov = fov;
        camera.updateProjectionMatrix();
      };

      const onFullscreenChange = () => {
        setIsFullscreen(Boolean(document.fullscreenElement));
      };

      /* --- wiring --- */
      canvas.addEventListener("pointerdown", panStart);
      window.addEventListener("pointermove", onPointerMove);
      window.addEventListener("pointerup", onPointerUp);
      window.addEventListener("pointercancel", onPointerCancel);
      canvas.addEventListener("wheel", onWheel, { passive: false });
      document.addEventListener("fullscreenchange", onFullscreenChange);

      const ro = new ResizeObserver(() => {
        const w = Math.max(wrapper.clientWidth, 1);
        const h = Math.max(wrapper.clientHeight, 1);
        sizeW = w;
        sizeH = h;
        renderer.setSize(w, h, false);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
      });
      ro.observe(wrapper);

      rafId = requestAnimationFrame(tick);

      engineRef.current = {
        loadRoom,
        resetView,
        zoomBy,
        nudge,
        panStart,
        isClickSuppressed: () => performance.now() < suppressClickUntil,
      };

      const pending = pendingRoomRef.current;
      if (pending) void loadRoom(pending);

      /* --- full teardown --- */
      cleanups.push(() => {
        cancelAnimationFrame(rafId);
        ro.disconnect();
        canvas.removeEventListener("pointerdown", panStart);
        window.removeEventListener("pointermove", onPointerMove);
        window.removeEventListener("pointerup", onPointerUp);
        window.removeEventListener("pointercancel", onPointerCancel);
        canvas.removeEventListener("wheel", onWheel);
        document.removeEventListener("fullscreenchange", onFullscreenChange);
        if (noticeTimerRef.current) clearTimeout(noticeTimerRef.current);
        if (material.map) material.map.dispose();
        material.dispose();
        geometry.dispose();
        renderer.dispose();
        try {
          renderer.forceContextLoss();
        } catch {
          /* context already gone */
        }
        canvas.remove();
      });
    };

    void run();

    return () => {
      disposed = true;
      engineRef.current = null;
      for (const fn of cleanups) {
        try {
          fn();
        } catch {
          /* teardown is best-effort */
        }
      }
    };
  }, [pushNotice]);

  /* Clear the teleport "pressed" feedback timer on unmount. */
  useEffect(
    () => () => {
      if (pressedTimerRef.current) clearTimeout(pressedTimerRef.current);
    },
    []
  );

  /* ---------------------------------------------------------------- */
  /* React-side interactions                                           */
  /* ---------------------------------------------------------------- */

  const goToRoom = useCallback((room: TourRoomDTO) => {
    pendingRoomRef.current = room;
    void engineRef.current?.loadRoom(room);
  }, []);

  const handleTeleport = useCallback(
    (hs: HotspotDTO) => {
      if (engineRef.current?.isClickSuppressed()) return;
      const target = rooms.find((r) => r.slug === hs.targetRoomSlug);
      if (!target) return;
      setPressedId(hs.id);
      if (pressedTimerRef.current) clearTimeout(pressedTimerRef.current);
      pressedTimerRef.current = setTimeout(() => setPressedId(null), 300);
      goToRoom(target);
    },
    [rooms, goToRoom]
  );

  const handleInfo = useCallback(
    (hs: HotspotDTO) => {
      if (engineRef.current?.isClickSuppressed()) return;
      if (hs.artworkSlug) openArtworkDialog(hs.artworkSlug);
    },
    [openArtworkDialog]
  );

  const handlePanStart = useCallback((e: ReactPointerEvent<HTMLElement>) => {
    engineRef.current?.panStart(e);
  }, []);

  const handleKeyDown = useCallback((e: ReactKeyboardEvent<HTMLDivElement>) => {
    const eng = engineRef.current;
    if (!eng) return;
    switch (e.key) {
      case "ArrowLeft":
        eng.nudge(12, 0);
        e.preventDefault();
        break;
      case "ArrowRight":
        eng.nudge(-12, 0);
        e.preventDefault();
        break;
      case "ArrowUp":
        eng.nudge(0, 8);
        e.preventDefault();
        break;
      case "ArrowDown":
        eng.nudge(0, -8);
        e.preventDefault();
        break;
      case "+":
      case "=":
        eng.zoomBy(-10);
        e.preventDefault();
        break;
      case "-":
      case "_":
        eng.zoomBy(10);
        e.preventDefault();
        break;
      default:
        break;
    }
  }, []);

  const toggleFullscreen = useCallback(() => {
    const el = wrapperRef.current;
    if (!el) return;
    if (document.fullscreenElement) {
      void document.exitFullscreen().catch(() => {});
      return;
    }
    if (typeof el.requestFullscreen !== "function") {
      pushNotice("Tela cheia não está disponível neste navegador.");
      return;
    }
    el.requestFullscreen().catch(() => {
      pushNotice("Não foi possível entrar em tela cheia.");
    });
  }, [pushNotice]);

  const enterRoomFromCard = useCallback(
    (room: TourRoomDTO) => {
      goToRoom(room);
      wrapperRef.current?.scrollIntoView({ behavior: "smooth", block: "center" });
    },
    [goToRoom]
  );

  /* ---------------------------------------------------------------- */
  /* Markup                                                            */
  /* ---------------------------------------------------------------- */

  return (
    <div>
      <div
        ref={wrapperRef}
        role="region"
        aria-label="Tour virtual pelo museu"
        tabIndex={webglFailed ? -1 : 0}
        onKeyDown={handleKeyDown}
        className={cn(
          "relative overflow-hidden bg-stone-900 shadow-2xl ring-1 ring-stone-800 outline-none",
          "focus-visible:ring-2 focus-visible:ring-amber-400/70",
          isFullscreen
            ? "h-screen w-screen rounded-none ring-0"
            : "aspect-[16/10] rounded-2xl md:aspect-[21/9]"
        )}
      >
        {!webglFailed ? (
          <div ref={canvasHostRef} className="absolute inset-0" />
        ) : (
          <div className="absolute inset-0 grid place-items-center p-6">
            <div className="flex max-w-md flex-col items-center gap-3 text-center">
              <MonitorOff className="size-10 text-stone-500" aria-hidden />
              <p className="text-sm text-stone-300">
                Seu navegador não suporta WebGL — o tour virtual 3D precisa dele
                para exibir os panoramas.
              </p>
            </div>
          </div>
        )}

        {/* Hotspot overlay (projected each frame by the engine) */}
        {!webglFailed && (
          <HotspotLayer
            hotspots={screenHotspots}
            pressedId={pressedId}
            onTeleport={handleTeleport}
            onInfo={handleInfo}
            onPanStart={handlePanStart}
          />
        )}

        {/* Fade overlay for room transitions */}
        <div
          aria-hidden
          className={cn(
            "pointer-events-none absolute inset-0 z-[15] bg-stone-950 transition-opacity duration-[280ms]",
            faded ? "opacity-100" : "opacity-0"
          )}
        />

        {/* Loading overlay */}
        {loading && !webglFailed && (
          <div
            role="status"
            aria-live="polite"
            className="absolute inset-0 z-50 grid place-items-center bg-stone-950/70 backdrop-blur-[2px]"
          >
            <div className="flex flex-col items-center gap-3">
              <LoaderCircle
                className="size-8 animate-spin text-amber-400"
                aria-hidden
              />
              <p className="text-sm text-stone-300">Carregando sala…</p>
            </div>
          </div>
        )}

        {/* Room selector pills */}
        <div className="absolute left-3 top-3 z-20 flex max-w-[calc(100%-8.5rem)] flex-wrap gap-2 md:left-4 md:top-4">
          {rooms.map((room) => {
            const isActive = room.slug === activeSlug;
            return (
              <button
                key={room.slug}
                type="button"
                aria-pressed={isActive}
                disabled={webglFailed}
                onClick={() => goToRoom(room)}
                className={cn(
                  "rounded-full border px-3 py-2 text-xs transition-colors md:text-sm",
                  isActive
                    ? "border-amber-500 bg-amber-500 font-medium text-stone-950"
                    : "border-stone-700 bg-stone-950/70 text-stone-300 hover:border-amber-500/60 hover:text-stone-100",
                  webglFailed && "cursor-not-allowed opacity-50"
                )}
              >
                {room.name}
              </button>
            );
          })}
        </div>

        {/* Controls cluster (reset view + fullscreen) */}
        <div className="absolute right-3 top-3 z-20 flex gap-2 md:right-4 md:top-4">
          <ControlButton label="Recentralizar visão" onClick={() => engineRef.current?.resetView()}>
            <Compass className="size-5" aria-hidden />
          </ControlButton>
          <ControlButton
            label={isFullscreen ? "Sair da tela cheia" : "Tela cheia"}
            onClick={toggleFullscreen}
          >
            {isFullscreen ? (
              <Minimize className="size-5" aria-hidden />
            ) : (
              <Maximize className="size-5" aria-hidden />
            )}
          </ControlButton>
        </div>

        {/* Zoom buttons */}
        <div className="absolute bottom-3 right-3 z-20 flex flex-col gap-2 md:bottom-4 md:right-4">
          <ControlButton label="Aproximar" onClick={() => engineRef.current?.zoomBy(-10)}>
            <Plus className="size-5" aria-hidden />
          </ControlButton>
          <ControlButton label="Afastar" onClick={() => engineRef.current?.zoomBy(10)}>
            <Minus className="size-5" aria-hidden />
          </ControlButton>
        </div>

        {/* Current room chip */}
        {activeRoom && (
          <div className="absolute bottom-3 left-3 z-20 max-w-[65%] rounded-xl border border-stone-700/80 bg-stone-950/70 px-3 py-2 backdrop-blur md:bottom-4 md:left-4">
            <p className="text-xs font-medium text-stone-100 md:text-sm">{activeRoom.name}</p>
            <p className="mt-0.5 hidden text-[11px] leading-snug text-stone-400 sm:block">
              {activeRoom.description}
            </p>
          </div>
        )}

        {/* First-visit hint */}
        <div
          aria-hidden
          className={cn(
            "pointer-events-none absolute inset-0 z-20 grid place-items-center transition-opacity duration-500",
            hasInteracted && "opacity-0"
          )}
        >
          <div className="flex items-center gap-2.5 rounded-full border border-stone-700 bg-stone-950/70 px-4 py-2 text-sm text-stone-200 backdrop-blur">
            <Hand className="size-4 shrink-0 text-amber-300" aria-hidden />
            <span>Arraste para olhar em volta · role para dar zoom</span>
          </div>
        </div>

        {/* Room intro toast */}
        <div
          aria-live="polite"
          className="pointer-events-none absolute inset-0 z-30 grid place-items-center px-6"
        >
          <AnimatePresence>
            {notice && (
              <motion.div
                key={notice.key}
                initial={{ opacity: 0, y: 10, scale: 0.98 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.35, ease: "easeOut" }}
                className="text-center"
              >
                <p className="text-[10px] font-medium tracking-[0.35em] text-amber-400/90">
                  VOCÊ ESTÁ EM
                </p>
                <p className="mt-2 font-display text-2xl text-stone-50 drop-shadow-[0_2px_12px_rgba(0,0,0,0.85)] md:text-4xl">
                  {notice.title}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>

      {/* Room cards (SEO / no-JS-friendly fallback) */}
      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3 md:mt-8">
        {rooms.map((room) => (
          <article
            key={room.slug}
            className="flex flex-col rounded-xl border border-stone-800 bg-stone-900/50 p-4 transition-colors hover:border-amber-500/40"
          >
            <img
              src={room.panoramaUrl}
              alt={`Panorama de ${room.name}`}
              loading="lazy"
              draggable={false}
              className="h-24 w-full rounded-lg object-cover ring-1 ring-stone-800"
            />
            <h3 className="mt-3 font-display text-lg leading-snug text-stone-100">
              {room.name}
            </h3>
            <p className="mt-1 flex-1 text-sm leading-relaxed text-stone-400">
              {room.description}
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={webglFailed}
              onClick={() => enterRoomFromCard(room)}
              className="mt-4 w-full border-stone-700 bg-transparent text-stone-200 hover:border-amber-500/60 hover:bg-stone-800 hover:text-amber-200"
            >
              <DoorOpen aria-hidden />
              Entrar na sala
            </Button>
          </article>
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Section                                                             */
/* ------------------------------------------------------------------ */

export function VirtualTour() {
  const roomsQuery = useQuery({ queryKey: qk.rooms, queryFn: fetchRooms });
  const rooms = roomsQuery.data;

  return (
    <section id="tour" className="relative bg-stone-950 py-20 text-stone-50 md:py-24">
      <div className="mx-auto max-w-7xl px-4 md:px-6">
        <header className="mb-8 md:mb-12">
          <p className="text-xs font-medium tracking-[0.25em] text-amber-400/90">
            VISITA IMERSIVA
          </p>
          <h2 className="mt-3 font-display text-4xl md:text-5xl">Tour Virtual 3D</h2>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-stone-400 md:text-base">
            Arraste para olhar em volta, aproxime-se com a rolagem e use os
            pontos dourados para teletransportar-se entre as salas do museu.
          </p>
        </header>

        {roomsQuery.isPending ? (
          <Skeleton className="aspect-[16/10] w-full rounded-2xl bg-stone-800/70 md:aspect-[21/9]" />
        ) : roomsQuery.isError || !rooms ? (
          <div className="flex aspect-[16/10] w-full flex-col items-center justify-center gap-4 rounded-2xl border border-stone-800 bg-stone-900/60 px-6 text-center md:aspect-[21/9]">
            <TriangleAlert className="size-10 text-amber-400/80" aria-hidden />
            <p className="text-sm text-stone-300">
              Não foi possível carregar as salas do museu.
            </p>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => void roomsQuery.refetch()}
              className="border-stone-700 bg-transparent text-stone-200 hover:border-amber-500/60 hover:bg-stone-800 hover:text-amber-200"
            >
              Tentar novamente
            </Button>
          </div>
        ) : rooms.length === 0 ? (
          <div className="flex aspect-[16/10] w-full items-center justify-center rounded-2xl border border-stone-800 bg-stone-900/60 md:aspect-[21/9]">
            <p className="text-sm text-stone-400">
              Nenhuma sala disponível no momento.
            </p>
          </div>
        ) : (
          <TourViewer rooms={rooms} />
        )}
      </div>
    </section>
  );
}

export default VirtualTour;
