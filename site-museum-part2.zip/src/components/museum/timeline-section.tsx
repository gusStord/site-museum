"use client";

/**
 * Musæum — Linha do Tempo dos Movimentos
 * Seção `#linha-do-tempo`: trilho horizontal arrastável com 12 movimentos
 * (Renascimento → Surrealismo), trilho cronológico 1400–2000, drag-to-scroll,
 * wheel-to-horizontal, teclado, barra de progresso e navegação por setas.
 */

import {
  useCallback,
  useEffect,
  useId,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent as ReactKeyboardEvent,
  type MouseEvent as ReactMouseEvent,
  type PointerEvent as ReactPointerEvent,
} from "react";
import Image from "next/image";
import { useQuery } from "@tanstack/react-query";
import { motion, useReducedMotion } from "framer-motion";
import { ChevronLeft, ChevronRight, MoveHorizontal, Palette } from "lucide-react";
import { fetchMovements, qk, type MovementDTO } from "@/lib/museum";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

/* ------------------------------------------------------------------ */
/* Constantes                                                          */
/* ------------------------------------------------------------------ */

/** Folga horizontal do trilho de cards (equivale ao px-6 da fileira). */
const EDGE_PAD = 24;
/** Passo de navegação por seta / botões (≈ 1 card + gap). */
const SCROLL_STEP = 360;
/** Deslocamento mínimo (px) antes de considerar um arraste real. */
const DRAG_THRESHOLD = 6;
/** Pausa (ms) na roda antes de assentar no card mais próximo. */
const WHEEL_IDLE_MS = 160;
/** Largura do indicador da barra de progresso (w-16). */
const PROGRESS_THUMB_W = 64;

const CARD_WIDTH_CLASS = "w-[300px] md:w-[340px] shrink-0 snap-start";

/** Máscara de esmaecimento nas bordas do scroller. */
const EDGE_FADE_MASK = {
  maskImage:
    "linear-gradient(to right, transparent 0, black 24px, black calc(100% - 24px), transparent 100%)",
  WebkitMaskImage:
    "linear-gradient(to right, transparent 0, black 24px, black calc(100% - 24px), transparent 100%)",
} as const;

/** Ano-limite superior de exibição do trilho cronológico. */
const MAX_DISPLAY_YEAR = 2000;
const FALLBACK_RANGE = { start: 1400, end: 2000 };

/* ------------------------------------------------------------------ */
/* Utilitários                                                         */
/* ------------------------------------------------------------------ */

function clamp(v: number, min: number, max: number): number {
  return Math.min(Math.max(v, min), max);
}

/** Faixa global: mínimo dos dados; máximo arredondado para cima, limitado a 2000. */
function deriveRange(movements: MovementDTO[]): { start: number; end: number } {
  if (movements.length === 0) return FALLBACK_RANGE;
  const start = Math.min(...movements.map((m) => m.startYear));
  const rawEnd = Math.max(...movements.map((m) => m.endYear));
  const end = Math.min(Math.ceil(rawEnd / 50) * 50, MAX_DISPLAY_YEAR);
  return { start, end: Math.max(end, start + 50) };
}

/** Posição horizontal (0–1) de um ano dentro da faixa global. */
function yearRatio(range: { start: number; end: number }, year: number): number {
  return clamp((year - range.start) / Math.max(1, range.end - range.start), 0, 1);
}

/** Pontos de encaixe (snap) dos cards, em coordenadas de scrollLeft. */
function cardSnapPositions(el: HTMLElement): number[] {
  const max = Math.max(0, el.scrollWidth - el.clientWidth);
  const scrollerLeft = el.getBoundingClientRect().left;
  const cards = Array.from(el.querySelectorAll<HTMLElement>("article"));
  const positions = cards.map((card) =>
    clamp(
      el.scrollLeft + card.getBoundingClientRect().left - scrollerLeft - EDGE_PAD,
      0,
      max,
    ),
  );
  if (max > 0) positions.push(max);
  return positions;
}

function nearestSnapPosition(el: HTMLElement): number {
  const candidates = cardSnapPositions(el);
  if (candidates.length === 0) return el.scrollLeft;
  return candidates.reduce((best, c) =>
    Math.abs(c - el.scrollLeft) < Math.abs(best - el.scrollLeft) ? c : best,
  );
}

function stepTarget(el: HTMLElement, dir: 1 | -1): number {
  const candidates = cardSnapPositions(el).sort((a, b) => a - b);
  if (candidates.length === 0) {
    const max = Math.max(0, el.scrollWidth - el.clientWidth);
    return clamp(el.scrollLeft + dir * SCROLL_STEP, 0, max);
  }
  const cur = el.scrollLeft;
  if (dir === 1) {
    return candidates.find((c) => c > cur + 4) ?? candidates[candidates.length - 1];
  }
  const previous = candidates.filter((c) => c < cur - 4);
  return previous.length > 0 ? previous[previous.length - 1] : candidates[0];
}

/** Estado do motor de animação (inércia + assentamento suave). */
type MotionState = {
  raf: number;
  phase: "glide" | "settle";
  velocity: number; // px/ms; positivo = dedo para a direita (scrollLeft diminui)
  target: number;
  lastT: number;
};

/* ------------------------------------------------------------------ */
/* Componente                                                          */
/* ------------------------------------------------------------------ */

export function TimelineSection() {
  const scrollerId = useId();
  const scrollerRef = useRef<HTMLDivElement | null>(null);
  const trackRef = useRef<HTMLDivElement | null>(null);
  const dragRef = useRef({
    pointerId: -1,
    startX: 0,
    lastX: 0,
    lastT: 0,
    velocity: 0,
    moved: false,
  });
  const motionRef = useRef<MotionState | null>(null);
  const wheelTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const trackPointerRef = useRef(-1);
  const suppressClickRef = useRef(false);

  const [dragging, setDragging] = useState(false);
  const [snapSuspended, setSnapSuspended] = useState(false);
  const [progress, setProgress] = useState(0);
  const [atStart, setAtStart] = useState(true);
  const [atEnd, setAtEnd] = useState(false);

  const prefersReducedMotion = useReducedMotion();

  const { data, isPending, isError, refetch } = useQuery({
    queryKey: qk.movements,
    queryFn: fetchMovements,
  });
  const movements = useMemo(() => data ?? [], [data]);

  const range = useMemo(() => deriveRange(movements), [movements]);
  const ratio = useCallback((year: number) => yearRatio(range, year), [range]);
  const ticks = useMemo(() => {
    const years: number[] = [];
    for (let y = range.start; y <= range.end; y += 50) years.push(y);
    if (years[years.length - 1] !== range.end) years.push(range.end);
    return years;
  }, [range]);

  /* ---------------- progresso / extremos ---------------- */

  const updateScrollState = useCallback(() => {
    const el = scrollerRef.current;
    if (!el) return;
    const max = el.scrollWidth - el.clientWidth;
    setProgress(max > 0 ? clamp(el.scrollLeft / max, 0, 1) : 0);
    setAtStart(el.scrollLeft <= 2);
    setAtEnd(max <= 2 || el.scrollLeft >= max - 2);
  }, []);

  // Mede o progresso após o commit (e quando os dados chegam), adiando para
  // o próximo frame — evita setState síncrono dentro do efeito.
  useEffect(() => {
    const raf = requestAnimationFrame(updateScrollState);
    return () => cancelAnimationFrame(raf);
  }, [updateScrollState, isPending, data]);

  useEffect(() => {
    window.addEventListener("resize", updateScrollState);
    return () => window.removeEventListener("resize", updateScrollState);
  }, [updateScrollState]);

  /* ---------------- motor de animação (glide + settle) ---------------- */

  const cancelMotion = useCallback(() => {
    if (wheelTimerRef.current !== null) {
      clearTimeout(wheelTimerRef.current);
      wheelTimerRef.current = null;
    }
    if (motionRef.current !== null) {
      cancelAnimationFrame(motionRef.current.raf);
      motionRef.current = null;
    }
  }, []);

  useEffect(() => cancelMotion, [cancelMotion]);

  /** Suspende o snap imediatamente (classList) e via estado (React). */
  const suspendSnapNow = useCallback((el: HTMLElement) => {
    el.classList.add("snap-none");
    el.classList.remove("snap-x", "snap-proximity");
    setSnapSuspended(true);
  }, []);

  /**
   * Anima o scrollLeft via requestAnimationFrame:
   * "glide" (inércia pós-arraste) → "settle" (assentamento exponencial
   * no snap mais próximo). Devolve o snap CSS apenas ao terminar exatamente
   * sobre um ponto de encaixe, evitando saltos do re-snap do navegador.
   */
  const runMotion = useCallback(
    (el: HTMLElement, init: { phase: "glide" | "settle"; velocity: number; target?: number }) => {
      cancelMotion();
      suspendSnapNow(el);
      const state: MotionState = {
        raf: 0,
        phase: init.phase,
        velocity: init.velocity,
        target: init.target ?? nearestSnapPosition(el),
        lastT: performance.now(),
      };
      const step = (now: number) => {
        const dt = now - state.lastT;
        state.lastT = now;
        const max = Math.max(0, el.scrollWidth - el.clientWidth);
        if (state.phase === "glide") {
          state.velocity *= Math.pow(0.94, dt / 16.7);
          el.scrollLeft -= state.velocity * dt;
          if (
            Math.abs(state.velocity) <= 0.02 ||
            el.scrollLeft <= 0 ||
            el.scrollLeft >= max
          ) {
            state.phase = "settle";
            state.target = nearestSnapPosition(el);
          }
        } else {
          const diff = state.target - el.scrollLeft;
          if (Math.abs(diff) < 0.6) {
            el.scrollLeft = clamp(state.target, 0, max);
            motionRef.current = null;
            setSnapSuspended(false);
            return;
          }
          el.scrollLeft += diff * 0.16;
        }
        state.raf = requestAnimationFrame(step);
      };
      motionRef.current = state;
      state.raf = requestAnimationFrame(step);
    },
    [cancelMotion, suspendSnapNow],
  );

  const settleToNearest = useCallback(() => {
    const el = scrollerRef.current;
    if (!el) return;
    runMotion(el, { phase: "settle", velocity: 0 });
  }, [runMotion]);

  const animateTo = useCallback(
    (target: number) => {
      const el = scrollerRef.current;
      if (!el) return;
      const max = Math.max(0, el.scrollWidth - el.clientWidth);
      runMotion(el, { phase: "settle", velocity: 0, target: clamp(target, 0, max) });
    },
    [runMotion],
  );

  const scrollCards = useCallback(
    (dir: 1 | -1) => {
      const el = scrollerRef.current;
      if (!el) return;
      animateTo(stepTarget(el, dir));
    },
    [animateTo],
  );

  /* ---------------- roda vertical → horizontal ---------------- */

  useEffect(() => {
    const el = scrollerRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      // deltaMode "line" (Firefox) → converte para px aproximados.
      const scale = e.deltaMode === WheelEvent.DOM_DELTA_LINE ? 16 : 1;
      const dx = e.deltaX * scale;
      const dy = e.deltaY * scale;
      // Intenção horizontal (trackpad) → mantém o comportamento nativo.
      if (Math.abs(dy) <= Math.abs(dx)) return;
      const max = el.scrollWidth - el.clientWidth;
      const canScroll = dy < 0 ? el.scrollLeft > 0 : el.scrollLeft < max - 1;
      if (!canScroll) return; // no limite: deixa a página rolar normalmente
      e.preventDefault();
      cancelMotion();
      suspendSnapNow(el);
      el.scrollLeft += dy;
      if (wheelTimerRef.current !== null) clearTimeout(wheelTimerRef.current);
      wheelTimerRef.current = setTimeout(() => {
        wheelTimerRef.current = null;
        if (dragRef.current.pointerId === -1 && trackPointerRef.current === -1) {
          settleToNearest();
        }
      }, WHEEL_IDLE_MS);
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => {
      el.removeEventListener("wheel", onWheel);
      cancelMotion();
    };
  }, [cancelMotion, suspendSnapNow, settleToNearest]);

  /* ---------------- arraste (pointer events) ---------------- */

  const handlePointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    const el = scrollerRef.current;
    if (!el) return;
    if (e.pointerType === "mouse" && e.button !== 0) return;
    cancelMotion();
    dragRef.current = {
      pointerId: e.pointerId,
      startX: e.clientX,
      lastX: e.clientX,
      lastT: performance.now(),
      velocity: 0,
      moved: false,
    };
    suppressClickRef.current = false;
    suspendSnapNow(el);
    try {
      el.setPointerCapture(e.pointerId);
    } catch {
      /* pointer inativo — segue sem captura */
    }
  };

  const handlePointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    const el = scrollerRef.current;
    const drag = dragRef.current;
    if (!el || drag.pointerId !== e.pointerId) return;
    const dx = e.clientX - drag.lastX;
    drag.lastX = e.clientX;
    const now = performance.now();
    const dt = now - drag.lastT;
    if (dt > 0) {
      drag.velocity = drag.velocity * 0.5 + (dx / dt) * 0.5;
      drag.lastT = now;
    }
    if (!drag.moved && Math.abs(e.clientX - drag.startX) > DRAG_THRESHOLD) {
      drag.moved = true;
      setDragging(true);
    }
    if (drag.moved) {
      if (e.pointerType === "mouse" && e.cancelable) e.preventDefault();
      el.scrollLeft -= dx;
    }
  };

  const handlePointerEnd = (e: ReactPointerEvent<HTMLDivElement>, allowGlide: boolean) => {
    const el = scrollerRef.current;
    const drag = dragRef.current;
    if (!el || drag.pointerId !== e.pointerId) return;
    drag.pointerId = -1;
    const wasMoved = drag.moved;
    const velocity = drag.velocity;
    const lastMoveAt = drag.lastT;
    drag.moved = false;
    drag.velocity = 0;
    setDragging(false);
    if (wasMoved) suppressClickRef.current = true;
    // Ignora a velocidade se o dedo/mouse parou antes de soltar.
    const stale = performance.now() - lastMoveAt > 80;
    if (allowGlide && !stale && Math.abs(velocity) >= 0.25) {
      runMotion(el, { phase: "glide", velocity: clamp(velocity, -2.5, 2.5) });
    } else {
      runMotion(el, { phase: "settle", velocity: 0 });
    }
  };

  /** Suprime o clique que o navegador dispara logo após um arraste. */
  const handleClickCapture = (e: ReactMouseEvent<HTMLDivElement>) => {
    if (suppressClickRef.current) {
      e.preventDefault();
      e.stopPropagation();
      suppressClickRef.current = false;
    }
  };

  /* ---------------- teclado ---------------- */

  const handleKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    const el = scrollerRef.current;
    if (!el) return;
    const max = Math.max(0, el.scrollWidth - el.clientWidth);
    switch (e.key) {
      case "ArrowLeft":
      case "ArrowUp":
        e.preventDefault();
        scrollCards(-1);
        break;
      case "ArrowRight":
      case "ArrowDown":
        e.preventDefault();
        scrollCards(1);
        break;
      case "Home":
        e.preventDefault();
        animateTo(0);
        break;
      case "End":
        e.preventDefault();
        animateTo(max);
        break;
      default:
        break;
    }
  };

  /* ---------------- barra de progresso (seek) ---------------- */

  const seekToPointer = useCallback((clientX: number) => {
    const track = trackRef.current;
    const el = scrollerRef.current;
    if (!track || !el) return;
    const rect = track.getBoundingClientRect();
    const usable = rect.width - PROGRESS_THUMB_W;
    if (usable <= 0) return;
    const p = clamp((clientX - rect.left - PROGRESS_THUMB_W / 2) / usable, 0, 1);
    const max = el.scrollWidth - el.clientWidth;
    el.scrollLeft = p * max;
  }, []);

  const handleTrackPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    const track = trackRef.current;
    const el = scrollerRef.current;
    if (!track || !el) return;
    e.preventDefault();
    cancelMotion();
    suspendSnapNow(el);
    trackPointerRef.current = e.pointerId;
    try {
      track.setPointerCapture(e.pointerId);
    } catch {
      /* pointer inativo — segue sem captura */
    }
    seekToPointer(e.clientX);
  };

  const handleTrackPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (trackPointerRef.current !== e.pointerId) return;
    seekToPointer(e.clientX);
  };

  const handleTrackPointerEnd = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (trackPointerRef.current !== e.pointerId) return;
    trackPointerRef.current = -1;
    settleToNearest();
  };

  /* ---------------- render ---------------- */

  const percent = Math.round(progress * 100);

  return (
    <section
      id="linha-do-tempo"
      aria-labelledby="linha-do-tempo-titulo"
      className="border-y border-border/60 bg-muted/40 py-20 md:py-24"
    >
      {/* Cabeçalho da seção */}
      <div className="mx-auto max-w-6xl px-6">
        <motion.div
          initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="flex flex-col gap-8 md:flex-row md:items-end md:justify-between"
        >
          <div className="max-w-2xl">
            <p className="text-xs font-medium tracking-[0.25em] text-amber-700/80">
              CRONOLOGIA
            </p>
            <h2
              id="linha-do-tempo-titulo"
              className="mt-3 font-display text-4xl leading-tight md:text-5xl"
            >
              Cinco Séculos em Uma Parede
            </h2>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Arraste, role ou use as setas para percorrer a linha do tempo dos
              movimentos que redefiniram a arte ocidental — do Renascimento ao
              Surrealismo.
            </p>
          </div>
          <div className="flex flex-col items-start gap-4 md:items-end">
            <span className="hidden items-center gap-1.5 rounded-full border border-border/70 bg-card px-3 py-1.5 text-xs text-muted-foreground md:inline-flex">
              <MoveHorizontal className="size-4" aria-hidden="true" />
              Arraste ou role para explorar
            </span>
            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="size-11 rounded-full bg-card shadow-sm"
                aria-label="Movimentos anteriores"
                disabled={atStart}
                onClick={() => scrollCards(-1)}
              >
                <ChevronLeft className="size-5" aria-hidden="true" />
              </Button>
              <Button
                type="button"
                variant="outline"
                size="icon"
                className="size-11 rounded-full bg-card shadow-sm"
                aria-label="Movimentos seguintes"
                disabled={atEnd}
                onClick={() => scrollCards(1)}
              >
                <ChevronRight className="size-5" aria-hidden="true" />
              </Button>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Trilho horizontal arrastável */}
      <div
        ref={scrollerRef}
        id={scrollerId}
        role="region"
        aria-label="Linha do tempo dos movimentos artísticos"
        tabIndex={0}
        data-dragging={dragging ? "true" : undefined}
        onScroll={updateScrollState}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={(e) => handlePointerEnd(e, true)}
        onPointerCancel={(e) => handlePointerEnd(e, false)}
        onClickCapture={handleClickCapture}
        onKeyDown={handleKeyDown}
        style={EDGE_FADE_MASK}
        className={cn(
          "no-scrollbar overscroll-x-contain scroll-px-6 touch-pan-y mt-10 cursor-grab select-none overflow-x-auto rounded-xl outline-none active:cursor-grabbing focus-visible:ring-2 focus-visible:ring-ring/50 md:mt-12",
          snapSuspended ? "snap-none" : "snap-x snap-proximity",
        )}
      >
        {isPending ? (
          /* Estado de carregamento: 5 cards esqueleto */
          <div className="flex w-max min-w-full gap-6 px-6 pt-11">
            {Array.from({ length: 5 }, (_, i) => (
              <Skeleton key={i} className={cn(CARD_WIDTH_CLASS, "h-64 rounded-xl")} />
            ))}
          </div>
        ) : isError ? (
          <div className="mx-auto flex w-full max-w-6xl flex-col items-center gap-3 px-6 py-16 text-center">
            <Palette className="size-6 text-muted-foreground" aria-hidden="true" />
            <p className="text-sm text-muted-foreground">
              Não foi possível carregar a linha do tempo dos movimentos.
            </p>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                void refetch();
              }}
            >
              Tentar novamente
            </Button>
          </div>
        ) : (
          <div className="relative flex w-max min-w-full items-stretch gap-6 px-6 pt-11">
            {/* Trilho cronológico contínuo (1400 → 2000) */}
            {movements.length > 0 && (
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-x-6 top-0 h-8 select-none"
              >
                {ticks.map((year) => (
                  <div
                    key={year}
                    className="absolute top-0 -translate-x-1/2"
                    style={{ left: `${(ratio(year) * 100).toFixed(3)}%` }}
                  >
                    <span className="block font-mono text-[10px] leading-none text-muted-foreground">
                      {year}
                    </span>
                    <span className="mx-auto mt-1 block h-1.5 w-px bg-border" />
                  </div>
                ))}
                <div className="absolute inset-x-0 top-[26px] h-0.5 rounded-full bg-border" />
                {movements.map((m) => (
                  <div
                    key={`seg-${m.id}`}
                    className="absolute top-[26px] h-0.5 rounded-full"
                    style={{
                      left: `${(ratio(m.startYear) * 100).toFixed(3)}%`,
                      width: `${((ratio(m.endYear) - ratio(m.startYear)) * 100).toFixed(3)}%`,
                      backgroundColor: m.color,
                    }}
                  />
                ))}
                {movements.map((m) => (
                  <span
                    key={`dot-${m.id}`}
                    className="absolute top-[24px] size-1.5 -translate-x-1/2 rounded-full border border-card"
                    style={{
                      left: `${(ratio(m.startYear) * 100).toFixed(3)}%`,
                      backgroundColor: m.color,
                    }}
                  />
                ))}
              </div>
            )}

            {/* Cards dos movimentos */}
            {movements.map((movement, index) => (
              <motion.article
                key={movement.id}
                aria-label={movement.name}
                initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "0px 0px -40px 0px" }}
                transition={{
                  duration: 0.45,
                  delay: (index % 4) * 0.06,
                  ease: "easeOut",
                }}
                className={cn(
                  CARD_WIDTH_CLASS,
                  "flex flex-col rounded-xl border bg-card p-4 shadow-sm",
                )}
              >
                {/* Imagem representativa com lavagem da cor do movimento */}
                <div className="relative h-36 w-full overflow-hidden rounded-lg">
                  {movement.imageUrl ? (
                    <Image
                      src={movement.imageUrl}
                      alt={movement.name}
                      fill
                      sizes="(min-width: 768px) 340px, 300px"
                      className="object-cover"
                      draggable={false}
                    />
                  ) : (
                    <div
                      className="flex h-full w-full items-center justify-center"
                      style={{ backgroundColor: `${movement.color}1a` }}
                    >
                      <Palette
                        className="size-8"
                        style={{ color: movement.color }}
                        aria-hidden="true"
                      />
                    </div>
                  )}
                  <div
                    aria-hidden="true"
                    className="pointer-events-none absolute inset-0 mix-blend-multiply"
                    style={{ backgroundColor: `${movement.color}26` }}
                  />
                </div>

                <div className="mt-3">
                  <span
                    className="inline-flex items-center rounded-full border px-2.5 py-0.5 font-mono text-xs leading-4"
                    style={{
                      color: movement.color,
                      borderColor: `${movement.color}66`,
                    }}
                  >
                    {movement.startYear}–{movement.endYear}
                  </span>
                </div>

                <h3 className="mt-2.5 flex items-center gap-2 font-display text-xl leading-snug md:text-2xl">
                  <span
                    aria-hidden="true"
                    className="size-2.5 shrink-0 rounded-full"
                    style={{ backgroundColor: movement.color }}
                  />
                  {movement.name}
                </h3>

                <p className="mt-1.5 line-clamp-4 text-sm leading-relaxed text-muted-foreground">
                  {movement.description}
                </p>

                {/* Mini barra de vigência (1400 → 2000) */}
                <div className="mt-auto pt-4">
                  <div
                    aria-hidden="true"
                    className="relative h-1.5 rounded-full bg-border/70"
                  >
                    <span
                      className="absolute inset-y-0 min-w-2 rounded-full"
                      style={{
                        left: `${(ratio(movement.startYear) * 100).toFixed(2)}%`,
                        width: `${(
                          (ratio(movement.endYear) - ratio(movement.startYear)) *
                          100
                        ).toFixed(2)}%`,
                        backgroundColor: movement.color,
                      }}
                    />
                  </div>
                  <p className="mt-1.5 text-[10px] text-muted-foreground">
                    ≈ {movement.endYear - movement.startYear} anos de vigência
                  </p>
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </div>

      {/* Barra de progresso + porcentagem */}
      <div className="mx-auto mt-8 flex max-w-6xl items-center gap-4 px-6">
        <div
          ref={trackRef}
          role="scrollbar"
          aria-controls={scrollerId}
          aria-orientation="horizontal"
          aria-label="Progresso da linha do tempo"
          aria-valuemin={0}
          aria-valuemax={100}
          aria-valuenow={percent}
          className="relative h-1.5 min-w-0 flex-1 cursor-pointer touch-none select-none rounded-full bg-border"
          onPointerDown={handleTrackPointerDown}
          onPointerMove={handleTrackPointerMove}
          onPointerUp={handleTrackPointerEnd}
          onPointerCancel={handleTrackPointerEnd}
        >
          <div
            aria-hidden="true"
            className="absolute top-0 h-full w-16 rounded-full bg-gradient-to-r from-amber-700 to-amber-500"
            style={{ left: `calc(${progress.toFixed(4)} * (100% - 4rem))` }}
          />
        </div>
        <span className="w-10 shrink-0 text-right text-xs tabular-nums text-muted-foreground">
          {percent}%
        </span>
      </div>
    </section>
  );
}

export default TimelineSection;
