/**
 * Musæum — shared types & API contract (used by client components).
 * All client components fetch these via TanStack Query.
 */

export type MovementDTO = {
  id: number;
  slug: string;
  name: string;
  startYear: number;
  endYear: number;
  description: string;
  color: string;
  imageUrl: string | null;
  order: number;
};

export type ArtworkDTO = {
  id: number;
  slug: string;
  title: string;
  artist: string;
  year: string;
  description: string;
  technique: string;
  dimensions: string;
  location: string;
  imageUrl: string;
  views: number;
  likes: number;
  featured: boolean;
  movement: { slug: string; name: string; color: string };
  hasAudio: boolean;
};

export type AudioTrackDTO = {
  id: number;
  slug: string;
  title: string;
  narrator: string;
  lang: string;
  transcript: string;
  transcriptPt: string;
  audioUrl: string;
  order: number;
  artwork: {
    slug: string;
    title: string;
    artist: string;
    imageUrl: string;
    year: string;
    movementName: string;
  } | null;
};

export type HotspotDTO = {
  id: string;
  type: "teleport" | "info";
  lat: number; // -90..90 (vertical angle in degrees)
  lon: number; // 0..360 (horizontal angle in degrees)
  label: string;
  targetRoomSlug?: string;
  artworkSlug?: string;
};

export type TourRoomDTO = {
  id: number;
  slug: string;
  name: string;
  description: string;
  panoramaUrl: string;
  order: number;
  hotspots: HotspotDTO[];
};

export type StatsDTO = {
  artworks: number;
  movements: number;
  tracks: number;
  rooms: number;
  totalViews: number;
  totalLikes: number;
};

/* ---------------- Query keys ---------------- */

export const qk = {
  artworks: ["artworks"] as const,
  artwork: (slug: string) => ["artwork", slug] as const,
  movements: ["movements"] as const,
  rooms: ["rooms"] as const,
  tracks: ["audio-guides"] as const,
  stats: ["stats"] as const,
};

/* ---------------- Fetchers ---------------- */

async function jsonOrThrow<T>(url: string): Promise<T> {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Falha ao carregar ${url} (${res.status})`);
  return res.json() as Promise<T>;
}

export const fetchArtworks = () =>
  jsonOrThrow<{ artworks: ArtworkDTO[] }>("/api/artworks").then((r) => r.artworks);
export const fetchMovements = () =>
  jsonOrThrow<{ movements: MovementDTO[] }>("/api/movements").then((r) => r.movements);
export const fetchRooms = () =>
  jsonOrThrow<{ rooms: TourRoomDTO[] }>("/api/rooms").then((r) => r.rooms);
export const fetchTracks = () =>
  jsonOrThrow<{ tracks: AudioTrackDTO[] }>("/api/audio-guides").then((r) => r.tracks);
export const fetchStats = () => jsonOrThrow<StatsDTO>("/api/stats");
