import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;
  const a = await db.artwork.findUnique({
    where: { slug },
    include: {
      movement: true,
      audioGuide: {
        select: { slug: true, title: true, transcriptPt: true },
      },
    },
  });

  if (!a) {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 });
  }

  // count a visit
  await db.artwork.update({
    where: { id: a.id },
    data: { views: { increment: 1 } },
  });

  return NextResponse.json({
    artwork: {
      id: a.id,
      slug: a.slug,
      title: a.title,
      artist: a.artist,
      year: a.year,
      description: a.description,
      technique: a.technique,
      dimensions: a.dimensions,
      location: a.location,
      imageUrl: a.imageUrl,
      views: a.views + 1,
      likes: a.likes,
      featured: a.featured,
      movement: {
        slug: a.movement.slug,
        name: a.movement.name,
        color: a.movement.color,
      },
      audioGuide: a.audioGuide
        ? {
            slug: a.audioGuide.slug,
            title: a.audioGuide.title,
            transcriptPt: a.audioGuide.transcriptPt,
          }
        : null,
    },
  });
}
