import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function POST(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> }
) {
  const { slug } = await params;

  try {
    const updated = await db.artwork.update({
      where: { slug },
      data: { likes: { increment: 1 } },
      select: { likes: true },
    });
    return NextResponse.json({ likes: updated.likes });
  } catch {
    return NextResponse.json({ error: "Obra não encontrada" }, { status: 404 });
  }
}
