import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const movementSlug = searchParams.get("movement");

  const artworks = await db.artwork.findMany({
    where: movementSlug && movementSlug !== "todos"
      ? { movement: { slug: movementSlug } }
      : undefined,
    include: { movement: true, audioGuide: { select: { id: true } } },
    orderBy: { id: "asc" },
  });

  return NextResponse.json({
    artworks: artworks.map((a) => ({
      id: a.id,
      slug: a.slug,
      title: a.title,
      artist: a.artist,
      year: a.year,
      description: a.description,
      technique: a.technique,
      dimensions: a.dimensions,
      location: a.location,
      imageUrl: a.imageUrl,
      views: a.views,
      likes: a.likes,
      featured: a.featured,
      movement: {
        slug: a.movement.slug,
        name: a.movement.name,
        color: a.movement.color,
      },
      hasAudio: !!a.audioGuide,
    })),
  });
}
