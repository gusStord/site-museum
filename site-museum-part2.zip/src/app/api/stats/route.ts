import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const [artworks, movements, tracks, rooms, agg] = await Promise.all([
    db.artwork.count(),
    db.movement.count(),
    db.audioGuide.count(),
    db.tourRoom.count(),
    db.artwork.aggregate({ _sum: { views: true, likes: true } }),
  ]);

  return NextResponse.json({
    artworks,
    movements,
    tracks,
    rooms,
    totalViews: agg._sum.views ?? 0,
    totalLikes: agg._sum.likes ?? 0,
  });
}
