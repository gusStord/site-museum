import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const tracks = await db.audioGuide.findMany({
    orderBy: { order: "asc" },
    include: {
      artwork: {
        include: { movement: { select: { name: true } } },
      },
    },
  });

  return NextResponse.json({
    tracks: tracks.map((t) => ({
      id: t.id,
      slug: t.slug,
      title: t.title,
      narrator: t.narrator,
      lang: t.lang,
      transcript: t.transcript,
      transcriptPt: t.transcriptPt,
      audioUrl: t.audioUrl,
      order: t.order,
      artwork: t.artwork
        ? {
            slug: t.artwork.slug,
            title: t.artwork.title,
            artist: t.artwork.artist,
            imageUrl: t.artwork.imageUrl,
            year: t.artwork.year,
            movementName: t.artwork.movement.name,
          }
        : null,
    })),
  });
}
