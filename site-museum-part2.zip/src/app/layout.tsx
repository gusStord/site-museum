import type { Metadata, Viewport } from "next";
import { Geist, Geist_Mono, Playfair_Display } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "Musæum — Museu Virtual de História da Arte",
  description:
    "Uma jornada imersiva por seis séculos de arte: obras-primas em alta resolução com lupa 4×, linha do tempo dos movimentos, tour virtual 3D e audioguia narrado.",
  keywords: [
    "história da arte",
    "museu virtual",
    "tour 3D",
    "audioguia",
    "renascimento",
    "impressionismo",
  ],
  authors: [{ name: "Musæum" }],
  manifest: "/manifest.webmanifest",
  icons: {
    icon: [{ url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" }],
    apple: [{ url: "/icons/icon-192.png" }],
  },
  openGraph: {
    title: "Musæum — Museu Virtual de História da Arte",
    description:
      "Obras-primas em alta resolução, linha do tempo dos movimentos, tour virtual 3D e audioguia narrado.",
    type: "website",
    siteName: "Musæum",
  },
};

export const viewport: Viewport = {
  themeColor: "#171310",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} ${playfair.variable} antialiased bg-background text-foreground font-sans`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
