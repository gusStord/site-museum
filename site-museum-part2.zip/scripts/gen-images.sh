#!/bin/bash
# Generate 360° panoramas + museum icon with z-ai (sequential, with retry).
# NOTE 2024 pipeline fix: the z-ai CLI hardcodes a size whitelist that rejects
# 2048x1024 (panoramas) and the backend also rejects 1440x720 (720 is not a
# multiple of 32). Panoramas are therefore generated via the SDK directly
# (scripts/gen-panorama.mjs, 2048x1024 equirectangular, PNG->JPEG via sharp);
# the square icon uses the CLI at 1024x1024 (valid everywhere).
set -u
PUB=/home/z/my-project/public

gen() {
  prompt="$1"; out="$2"; size="${3:-1024x1024}"
  for attempt in 1 2 3 4; do
    if [ -s "$out" ]; then echo "= $out exists"; return 0; fi
    echo "+ attempt $attempt: $out ($size)"
    z-ai image -p "$prompt" -o "$out" -s "$size" && [ -s "$out" ] && return 0
    echo "  failed (attempt $attempt), waiting 25s..."
    sleep 25
  done
  echo "X giving up on $out"
  return 1
}

pano() {
  prompt="$1"; out="$2"
  if [ -s "$out" ]; then echo "= $out exists"; return 0; fi
  bun /home/z/my-project/scripts/gen-panorama.mjs "$prompt" "$out" "2048x1024"
}

pano "Seamless 360 degree equirectangular panorama of a grand classical art museum hall, Renaissance oil paintings in ornate gilded frames hanging on dark green walls, black and white marble checkerboard floor, warm brass picture lights above each frame, coffered ceiling, tall arched doorway, photorealistic, even museum lighting, no people, no text" "$PUB/panoramas/renascimento-hall.jpg"

pano "Seamless 360 degree equirectangular panorama of a bright elegant art gallery, impressionist landscape paintings in gold frames on soft sage green walls, glass skylight ceiling with soft daylight, wooden parquet floor, museum bench in the center, photorealistic, no people, no text" "$PUB/panoramas/impressionismo-gallery.jpg"

pano "Seamless 360 degree equirectangular panorama of a contemporary art museum room, large colorful abstract expressionist canvases on crisp white walls, polished grey concrete floor, black track lighting on ceiling, minimalist architecture, photorealistic, no people, no text" "$PUB/panoramas/moderna-wing.jpg"

gen "Minimal elegant museum emblem logo, classical greek temple facade with three ionic columns and triangular pediment, gold line art on deep charcoal background, luxury flat vector style, perfectly centered, no text, no border" "$PUB/icons/icon-master.png" "1024x1024"

echo "ALL IMAGE GENERATION DONE"
ls -la "$PUB/panoramas" "$PUB/icons"
