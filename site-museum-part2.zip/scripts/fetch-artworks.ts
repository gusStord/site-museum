/**
 * Download public-domain artwork images from Wikimedia Commons.
 * Uses the Commons API (imageinfo with iiurlwidth) to resolve ~1920px thumbs,
 * with a search fallback for uncertain filenames.
 * Run: bun scripts/fetch-artworks.ts
 */
import fs from "node:fs";
import path from "node:path";

const UA =
  "MusaeumBuilder/1.0 (educational art-history project; contact: dev@example.org)";

type ArtworkSpec = {
  slug: string;
  candidates: string[]; // exact File: titles to try, in order
  search: string; // fallback search query
};

const ARTWORKS: ArtworkSpec[] = [
  {
    slug: "o-nascimento-de-venus",
    candidates: [
      "Sandro_Botticelli_-_La_nascita_di_Venere_-_Google_Art_Project_-_edited.jpg",
    ],
    search: "Botticelli Birth of Venus Google Art Project",
  },
  {
    slug: "mona-lisa",
    candidates: [
      "Mona_Lisa,_by_Leonardo_da_Vinci,_from_C2RMF_retouched.jpg",
    ],
    search: "Mona Lisa Leonardo da Vinci retouched",
  },
  {
    slug: "a-ronda-noturna",
    candidates: [
      "The_Nightwatch_by_Rembrandt.jpg",
      "The_Night_Watch_-_Rijksmuseum_-_Google_Art_Project.jpg",
    ],
    search: "Rembrandt Night Watch Rijksmuseum",
  },
  {
    slug: "moca-com-brinco-de-perola",
    candidates: ["1665_Girl_with_a_Pearl_Earring.jpg"],
    search: "Girl with a Pearl Earring Vermeer 1665",
  },
  {
    slug: "o-andarilho-sobre-o-mar-de-nevoa",
    candidates: [
      "Caspar_David_Friedrich_-_Wanderer_above_the_sea_of_fog.jpg",
    ],
    search: "Caspar David Friedrich Wanderer above the Sea of Fog",
  },
  {
    slug: "a-liberdade-guiando-o-povo",
    candidates: [
      "Eug\u00e8ne_Delacroix_-_Le_28_Juillet._La_Libert\u00e9_guidant_le_peuple.jpg",
      "Eug\u00e8ne_Delacroix_-_Le_28_Juillet._La_Libert\u00e9_guidant_le_peuple_(septembre_1830).jpg",
    ],
    search: "Delacroix Liberty Leading the People 1830",
  },
  {
    slug: "a-grande-onda-de-kanagawa",
    candidates: ["Great_Wave_off_Kanagawa2.jpg"],
    search: "Great Wave off Kanagawa Hokusai",
  },
  {
    slug: "impressao-nascer-do-sol",
    candidates: ["Monet_-_Impression,_Sunrise.jpg"],
    search: "Monet Impression Sunrise 1872",
  },
  {
    slug: "a-noite-estrelada",
    candidates: ["Van_Gogh_-_Starry_Night_-_Google_Art_Project.jpg"],
    search: "Van Gogh Starry Night Google Art Project",
  },
  {
    slug: "o-grito",
    candidates: [
      "Edvard_Munch,_1893,_The_Scream,_oil,_tempera_and_pastel_on_cardboard,_91_x_73_cm,_National_Gallery_of_Norway.jpg",
    ],
    search: "Edvard Munch The Scream 1893 National Gallery",
  },
  {
    slug: "o-beijo",
    candidates: [
      "The_Kiss_-_Gustav_Klimt_-_Google_Cultural_Institute.jpg",
    ],
    search: "Gustav Klimt The Kiss Google Cultural Institute",
  },
  {
    slug: "o-juramento-dos-horacios",
    candidates: [
      "Jacques-Louis_David_-_The_Oath_of_the_Horatii_-_Google_Art_Project.jpg",
    ],
    search: "Jacques-Louis David Oath of the Horatii Google Art Project",
  },
  {
    slug: "os-quebra-pedras",
    candidates: [
      "Gustave_Courbet_-_The_Stone_Breakers_-_Google_Art_Project.jpg",
      "Gustave_Courbet_-_The_Stonebreakers_-_Google_Art_Project.jpg",
    ],
    search: "Courbet Stone Breakers painting",
  },
  {
    slug: "as-senhoretas-de-avignon",
    candidates: ["Les_Demoiselles_d'Avignon.jpg"],
    search: "Picasso Les Demoiselles d'Avignon 1907",
  },
  {
    slug: "a-persistencia-da-memoria",
    candidates: [
      "Salvador_Dal\u00ed_-_The_Persistence_of_Memory_-_Google_Art_Project.jpg",
      "The_Persistence_of_Memory.jpg",
    ],
    search: "Salvador Dali Persistence of Memory melting clocks",
  },
];

const API = "https://commons.wikimedia.org/w/api.php";

async function apiGet(params: Record<string, string>) {
  const url = new URL(API);
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v);
  const res = await fetch(url, { headers: { "User-Agent": UA } });
  if (!res.ok) throw new Error(`API ${res.status}`);
  return res.json();
}

type ImageInfo = {
  thumburl?: string;
  thumbwidth?: number;
  thumbheight?: number;
  url?: string;
  mime?: string;
};

async function resolveThumb(title: string): Promise<ImageInfo | null> {
  const data = await apiGet({
    action: "query",
    prop: "imageinfo",
    iiprop: "url|size|mime",
    iiurlwidth: "1920",
    titles: `File:${title}`,
    format: "json",
    formatversion: "2",
  });
  const pages = data?.query?.pages ?? [];
  for (const p of pages) {
    if (p.missing) continue;
    const ii = p.imageinfo?.[0];
    if (ii?.thumburl && (ii.mime ?? "").startsWith("image/")) return ii;
  }
  return null;
}

async function searchFallback(query: string): Promise<string | null> {
  const data = await apiGet({
    action: "query",
    list: "search",
    srnamespace: "6",
    srsearch: `${query} filetype:bitmap`,
    srlimit: "8",
    format: "json",
    formatversion: "2",
  });
  const hits = data?.query?.search ?? [];
  for (const h of hits) {
    const title = String(h.title).replace(/^File:/, "");
    if (/\.(svg|gif)$/i.test(title)) continue;
    return title;
  }
  return null;
}

async function download(url: string, dest: string): Promise<number> {
  const res = await fetch(url, { headers: { "User-Agent": UA } });
  if (!res.ok) throw new Error(`download ${res.status} for ${url}`);
  const buf = Buffer.from(await res.arrayBuffer());
  if (buf.length < 30_000) throw new Error(`file too small (${buf.length}B)`);
  fs.writeFileSync(dest, buf);
  return buf.length;
}

async function main() {
  const outDir = path.join(process.cwd(), "public", "artworks");
  fs.mkdirSync(outDir, { recursive: true });
  const manifest: Record<
    string,
    { file: string; bytes: number; width?: number; height?: number; source: string }
  > = {};

  for (const art of ARTWORKS) {
    const dest = path.join(outDir, `${art.slug}.jpg`);
    if (fs.existsSync(dest) && fs.statSync(dest).size > 30_000) {
      console.log(`= ${art.slug} already exists, skip`);
      continue;
    }
    let info: ImageInfo | null = null;
    let usedTitle = "";
    for (const c of art.candidates) {
      info = await resolveThumb(c);
      if (info) {
        usedTitle = c;
        break;
      }
    }
    if (!info) {
      const found = await searchFallback(art.search);
      if (found) {
        info = await resolveThumb(found);
        usedTitle = found;
      }
    }
    if (!info?.thumburl) {
      console.error(`X ${art.slug}: NOT FOUND`);
      continue;
    }
    try {
      const bytes = await download(info.thumburl, dest);
      manifest[art.slug] = {
        file: `/artworks/${art.slug}.jpg`,
        bytes,
        width: info.thumbwidth,
        height: info.thumbheight,
        source: usedTitle,
      };
      console.log(
        `+ ${art.slug} <- ${usedTitle} (${info.thumbwidth}x${info.thumbheight}, ${(bytes / 1024).toFixed(0)}KB)`
      );
    } catch (e) {
      console.error(`X ${art.slug}: ${(e as Error).message}`);
    }
  }

  fs.writeFileSync(
    "/tmp/artworks-manifest.json",
    JSON.stringify(manifest, null, 2)
  );
  console.log("DONE. Manifest at /tmp/artworks-manifest.json");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
