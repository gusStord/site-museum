#!/bin/bash
# Generate the 7 audio-guide narration tracks (English, "jam" docent voice, mp3).
# Sequential with retry/backoff to respect rate limits.
# NOTE pipeline fix: the TTS backend now rejects response_format "mp3"
# (400 code 1214 不支持当前response_format值), so we generate WAV (default,
# supported) and transcode to MP3 locally with ffmpeg.
set -u
OUT=/home/z/my-project/public/audio
TMP=/tmp/museum-tts
mkdir -p "$OUT" "$TMP"

tts() {
  slug="$1"; text="$2"
  TMPWAV="$TMP/$slug.wav"
  for attempt in 1 2 3 4; do
    if [ -s "$OUT/$slug.mp3" ]; then echo "= $slug exists"; return 0; fi
    echo "+ attempt $attempt: $slug"
    if z-ai tts -i "$text" -o "$TMPWAV" --voice jam --speed 0.9 && [ -s "$TMPWAV" ] \
       && ffmpeg -y -v error -i "$TMPWAV" -codec:a libmp3lame -q:a 3 "$OUT/$slug.mp3" \
       && [ -s "$OUT/$slug.mp3" ]; then
      rm -f "$TMPWAV"
      return 0
    fi
    echo "  failed (attempt $attempt), waiting 20s..."
    sleep 20
  done
  echo "X giving up on $slug"
  return 1
}

tts "boas-vindas" "Welcome to Musaeum, your virtual museum of art history. Over the next few rooms, you will travel through six centuries of human creativity, from the blossoming of the Renaissance to the bold experiments of the modern age. Take your time. Let each room speak to you. And when a painting calls to you, come closer."

tts "a-noite-estrelada" "Painted from the window of an asylum in Saint Remy in June 1889, The Starry Night is Vincent van Gogh's turbulent hymn to the night sky. Look how the cypress tree rises like a dark flame, connecting earth and heaven, while eleven stars swirl in cosmic rhythm. Van Gogh painted this scene from memory and imagination, rather than direct observation, and that is what gives it its dreamlike, emotional power."

tts "mona-lisa" "Leonardo da Vinci began the Mona Lisa around 1503, and carried it with him until the end of his life. Her smile seems to change before our eyes, thanks to Leonardo's sfumato technique, in which delicate layers of glaze soften every edge. She gazes at us with calm confidence, and behind her lies an imaginary landscape of winding rivers and dissolving mountains."

tts "o-beijo" "Gustav Klimt's The Kiss, painted between 1907 and 1908, is the golden icon of Viennese art nouveau. Two lovers melt into a single shimmering form, wrapped in gold leaf, suspended on the edge of a flowering cliff. The geometric patterns on their garments hint at the coming abstraction, while the gold itself recalls the Byzantine mosaics that Klimt so admired."

tts "a-grande-onda-de-kanagawa" "The Great Wave off Kanagawa, created around 1831 by Katsushika Hokusai, is perhaps the most reproduced image in the history of art. A monstrous wave rears like a claw over fragile fishing boats, while sacred Mount Fuji sits serene in the distance. This woodblock print, part of the series Thirty-six Views of Mount Fuji, travelled to Europe and transformed artists from Monet to Van Gogh."

tts "o-grito" "I felt a great scream pass through nature, wrote Edvard Munch in his diary. In 1893 he painted The Scream, the founding image of modern anxiety. The figure on the bridge is not screaming. It is hearing the scream of the universe, and covering its ears in despair. The blood-red sky swirls with lines of force that echo Van Gogh's night, painted only a few years before."

tts "moca-com-brinco-de-perola" "She is called the Mona Lisa of the North. Vermeer's Girl with a Pearl Earring, painted around 1665, looks over her shoulder as if you had just called her name. The pearl itself is an illusion, just two strokes of lead white. Yet in that moment of turning, in that soft light and that questioning glance, Vermeer captured something forever alive."

echo "ALL AUDIO DONE"
ls -la "$OUT"
