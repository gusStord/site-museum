/**
 * Musæum seed — movements, artworks, audio guides, tour rooms.
 * Run: bun prisma/seed.ts
 */
import { PrismaClient } from "@prisma/client";

const db = new PrismaClient();

async function main() {
  // ---------- Movements ----------
  const movements = [
    {
      slug: "renascimento",
      name: "Renascimento",
      startYear: 1400,
      endYear: 1600,
      description:
        "O redescobrir da Antiguidade clássica. A perspectiva linear, o humanismo e o retrato nascentes transformam a Europa: a arte deixa de ser apenas símbolo sagrado e passa a celebrar o homem, a natureza e a ciência do olhar.",
      color: "#9a7b2e",
      order: 1,
    },
    {
      slug: "barroco",
      name: "Barroco",
      startYear: 1590,
      endYear: 1750,
      description:
        "Drama, luz e movimento. Contrarreforma em cena: claroscuros violentos, gestos teatrais e a emoção elevada à escala do divino. De Caravaggio a Rembrandt, a pintura aprende a comandar a luz como uma personagem.",
      color: "#8a5a2b",
      order: 2,
    },
    {
      slug: "neoclassicismo",
      name: "Neoclassicismo",
      startYear: 1760,
      endYear: 1830,
      description:
        "Ordem, virtude e Roma resgatada. Em resposta aos excessos do Rococó, a geração de David volta às linhas puras, aos heróis cívicos e à moral estoica — a arte como escola do caráter.",
      color: "#6b7a52",
      order: 3,
    },
    {
      slug: "romantismo",
      name: "Romantismo",
      startYear: 1780,
      endYear: 1850,
      description:
        "O sublime contra a razão. Montanhas infinitas, tempestades, revoluções e o eu lírico em primeiro plano: o Romantismo faz da emoção, da natureza e da liberdade o novo altar da pintura.",
      color: "#963a4a",
      order: 4,
    },
    {
      slug: "realismo",
      name: "Realismo",
      startYear: 1840,
      endYear: 1870,
      description:
        "Pintar o mundo como ele é. Courbet e Millet tiram os olhos dos deuses e dos heróis para olhar camponeses, operários e pedreiros — a vida comum elevada à dignidade da grande pintura.",
      color: "#75604a",
      order: 5,
    },
    {
      slug: "ukiyo-e",
      name: "Ukiyo-e",
      startYear: 1670,
      endYear: 1900,
      description:
        "O 'mundo flutuante' do Japão Edo. Xilogravuras de atores, paisagens e ondas legendárias que, ao cruzar o Pacífico, incendiam o Ocidente: nasce o Japonismo que revoluciona Monet, Van Gogh e Toulouse-Lautrec.",
      color: "#b0653a",
      order: 6,
    },
    {
      slug: "impressionismo",
      name: "Impressionismo",
      startYear: 1860,
      endYear: 1890,
      description:
        "A luz ao ar livre, capturada em pinceladas rápidas. Ridicularizados em 1874, os impressionistas dissolvem a forma em cor vibrante e instantâneo — a pintura descobre que o importante não é o que se vê, mas como se vê.",
      color: "#c79a3f",
      order: 7,
    },
    {
      slug: "pos-impressionismo",
      name: "Pós-Impressionismo",
      startYear: 1886,
      endYear: 1905,
      description:
        "Além da impressão: a cor como emoção e a forma como sintaxe. Van Gogh, Cézanne e Gauguin abrem três estradas distintas que, juntas, conduzem à arte moderna do século XX.",
      color: "#a85a2a",
      order: 8,
    },
    {
      slug: "simbolismo",
      name: "Simbolismo",
      startYear: 1880,
      endYear: 1910,
      description:
        "Sugerir em vez de descrever. Contra o positivismo, o Simbolismo mergulha em sonhos, mitos e ornamento — de Moreau a Klimt, a pintura vira poema esotérico banhado a ouro.",
      color: "#8a7a3f",
      order: 9,
    },
    {
      slug: "expressionismo",
      name: "Expressionismo",
      startYear: 1905,
      endYear: 1930,
      description:
        "A realidade distorcida pela intensidade do sentimento. Cores gritadas, corpos tortos, ansiedade moderna: do grito de Munch aos cavaleiros do Die Brücke, a pintura como grito existencial.",
      color: "#a03d35",
      order: 10,
    },
    {
      slug: "cubismo",
      name: "Cubismo",
      startYear: 1907,
      endYear: 1920,
      description:
        "Picasso e Braque quebram a janela renascentista. Um objeto visto de todos os lados ao mesmo tempo, reduzido a planos geométricos: a maior revolução formal da arte ocidental desde a perspectiva.",
      color: "#7a6f5f",
      order: 11,
    },
    {
      slug: "surrealismo",
      name: "Surrealismo",
      startYear: 1924,
      endYear: 1955,
      description:
        "O inconsciente posto à tela. Guiado por Freud, o Surrealismo de Dalí e Magritte fabrica relógios derretidos e mundos impossíveis — a pintura como sonho lúcido, verdade mais profunda que a vigília.",
      color: "#537a6a",
      order: 12,
    },
  ];

  const movementMap = new Map<string, number>();
  for (const m of movements) {
    const rec = await db.movement.upsert({
      where: { slug: m.slug },
      update: m,
      create: m,
    });
    movementMap.set(m.slug, rec.id);
  }

  // ---------- Artworks ----------
  const artworks = [
    {
      slug: "o-nascimento-de-venus",
      title: "O Nascimento de Vênus",
      artist: "Sandro Botticelli",
      year: "c. 1484–1486",
      movement: "renascimento",
      technique: "Têmpera sobre tela",
      dimensions: "172,5 × 278,5 cm",
      location: "Galleria degli Uffizi, Florença",
      featured: false,
      description:
        "A deusa do amor chega à praia sobre uma concha, empurrada pelos ventos Zéfiro e Aura, enquanto a Primavera a cobre com um manto florido. Encomendada pelos Médici, a tela celebra a beleza clássica redescoberta pelo Renascimento florentino — e o gesto recatado de Vênus funde a pudicidade cristã com a graça pagã da Antiguidade.",
    },
    {
      slug: "mona-lisa",
      title: "Mona Lisa (La Gioconda)",
      artist: "Leonardo da Vinci",
      year: "c. 1503–1506",
      movement: "renascimento",
      technique: "Óleo sobre painel de choupo",
      dimensions: "77 × 53 cm",
      location: "Musée du Louvre, Paris",
      featured: true,
      description:
        "O retrato mais famoso do mundo. O sorriso enigmático nasce do sfumato — véus de tinta quase transparentes que dissolvem os contornos — e do jogo entre o olhar e o observador. Atrás dela, uma paisagem imaginária de rios serpenteantes antecipa a geologia científica de Leonardo.",
    },
    {
      slug: "a-ronda-noturna",
      title: "A Ronda Noturna",
      artist: "Rembrandt van Rijn",
      year: "1642",
      movement: "barroco",
      technique: "Óleo sobre tela",
      dimensions: "363 × 437 cm",
      location: "Rijksmuseum, Amsterdã",
      featured: false,
      description:
        "A milícia do capitão Cocq sai das sombras: Rembrandt transforma o retrato de grupo formal em teatro de luz, com a lança cortando o ar e a menina misteriosa banhada em ouro. O claroscuro mais audacioso do Barroco holandês.",
    },
    {
      slug: "moca-com-brinco-de-perola",
      title: "Moça com Brinco de Pérola",
      artist: "Johannes Vermeer",
      year: "c. 1665",
      movement: "barroco",
      technique: "Óleo sobre tela",
      dimensions: "44,5 × 39 cm",
      location: "Mauritshuis, Haia",
      featured: true,
      description:
        "Ela se vira como se você tivesse acabado de chamar seu nome. A 'Mona Lisa do Norte' é um tronie — estudo de expressão — onde a pérola é pura ilusão: duas pinceladas de branco de chumbo. A luz suave de Delft faz do silêncio o tema da pintura.",
    },
    {
      slug: "o-andarilho-sobre-o-mar-de-nevoa",
      title: "O Andarilho sobre o Mar de Névoa",
      artist: "Caspar David Friedrich",
      year: "c. 1818",
      movement: "romantismo",
      technique: "Óleo sobre tela",
      dimensions: "94,8 × 74,8 cm",
      location: "Kunsthalle, Hamburgo",
      featured: true,
      description:
        "Um homem de costas contempla o abismo de névoa — o ícone do sublime romântico. Friedrich inverte o retrato: não vemos o rosto, vemos o que ele sente. A natureza imensa e o eu solitário diante dela.",
    },
    {
      slug: "a-liberdade-guiando-o-povo",
      title: "A Liberdade Guiando o Povo",
      artist: "Eugène Delacroix",
      year: "1830",
      movement: "romantismo",
      technique: "Óleo sobre tela",
      dimensions: "260 × 325 cm",
      location: "Musée do Louvre, Paris",
      featured: false,
      description:
        "A Revolução de Julho em carne e símbolo: a Liberdade de gorro frígio avança sobre barricadas com a tricolor, conduzindo operário, burguês e garoto. Delacroix faz da pintura histórica um manifesto político da liberdade.",
    },
    {
      slug: "a-grande-onda-de-kanagawa",
      title: "A Grande Onda de Kanagawa",
      artist: "Katsushika Hokusai",
      year: "c. 1830–1832",
      movement: "ukiyo-e",
      technique: "Xilogravura (nishiki-e)",
      dimensions: "25,7 × 37,9 cm",
      location: "Diversas coleções (série 36 Vistas do Fuji)",
      featured: true,
      description:
        "A onda-garra ameaça três barcos de pescadores enquanto o sagrado Monte Fuji repousa sereno ao fundo. A imagem mais reproduzida da história da arte pertence à série '36 Vistas do Monte Fuji' e, ao chegar à Europa, transformou para sempre Monet, Van Gogh e Debussy.",
    },
    {
      slug: "impressao-nascer-do-sol",
      title: "Impressão, Nascer do Sol",
      artist: "Claude Monet",
      year: "1872",
      movement: "impressionismo",
      technique: "Óleo sobre tela",
      dimensions: "48 × 63 cm",
      location: "Musée Marmottan Monet, Paris",
      featured: false,
      description:
        "O porto de Le Havre na bruma laranja da manhã, pintado em pinceladas de uma sessão só. Um crítico zombou do título — 'impressionismo!' — e batizou sem querer o movimento que libertou a pintura do ateliê para a luz do ar livre.",
    },
    {
      slug: "a-noite-estrelada",
      title: "A Noite Estrelada",
      artist: "Vincent van Gogh",
      year: "1889",
      movement: "pos-impressionismo",
      technique: "Óleo sobre tela",
      dimensions: "73,7 × 92,1 cm",
      location: "MoMA, Nova York",
      featured: true,
      description:
        "Pintada da janela do asilo de Saint-Rémy, mas refeita da memória e da imaginação: o cipreste sobe como chama negra ligando a terra ao céu, onze estrelas giram em espirais cósmicas e a aldeia dorme sob o turbilhão. O hino noturno mais luminoso da arte.",
    },
    {
      slug: "o-grito",
      title: "O Grito",
      artist: "Edvard Munch",
      year: "1893",
      movement: "expressionismo",
      technique: "Óleo, têmpera e pastel sobre papelão",
      dimensions: "91 × 73,5 cm",
      location: "Nasjonalmuseet, Oslo",
      featured: true,
      description:
        "'Senti um grande grito passar pela natureza', escreveu Munch no diário. A figura na ponte não grita — ela ouve o grito do universo e tapa os ouvidos. O céu vermelho-sangue em ondas de força funda a imagem-matriz da angústia moderna.",
    },
    {
      slug: "o-beijo",
      title: "O Beijo",
      artist: "Gustav Klimt",
      year: "1907–1908",
      movement: "simbolismo",
      technique: "Óleo e folha de ouro sobre tela",
      dimensions: "180 × 180 cm",
      location: "Belvedere, Viena",
      featured: true,
      description:
        "Dois amantes fundem-se numa única forma cintilante, envoltos em ouro, à beira de um penhasco florido. Ícone da Secessão Vienense, o quadro funde o ornamento bizantino ao erotismo moderno — e os retângulos e círculos que separam os corpos anunciam a abstração que viria.",
    },
    {
      slug: "o-juramento-dos-horacios",
      title: "O Juramento dos Horácios",
      artist: "Jacques-Louis David",
      year: "1784",
      movement: "neoclassicismo",
      technique: "Óleo sobre tela",
      dimensions: "330 × 425 cm",
      location: "Musée do Louvre, Paris",
      featured: false,
      description:
        "Três irmãos juram lutar até a morte enquanto as mulheres choram: David funda o Neoclassicismo com geometria severa, luz dura e virtude romana. A tela torna-se manifesto estético — e prenúncio da revolução que viria.",
    },
    {
      slug: "os-quebra-pedras",
      title: "Os Quebra-Pedras",
      artist: "Gustave Courbet",
      year: "1849",
      movement: "realismo",
      technique: "Óleo sobre tela",
      dimensions: "160 × 259 cm",
      location: "Destruído (Dresden, 1945)",
      featured: false,
      description:
        "Dois camponeses quebram pedras à beira da estrada, sem heroísmo nem pity: 'Pintei o que vi', disse Courbet. O manifesto do Realismo eleva o trabalho braçal à escala da grande pintura histórica. A tela ardeu no bombardeio de Dresden em 1945 — só nos resta a fotografia.",
    },
    {
      slug: "as-senhoretas-de-avignon",
      title: "As Senhoritas de Avignon",
      artist: "Pablo Picasso",
      year: "1907",
      movement: "cubismo",
      technique: "Óleo sobre tela",
      dimensions: "243,9 × 233,7 cm",
      location: "MoMA, Nova York",
      featured: false,
      description:
        "Cinco mulheres com rostos-máscara encaram quem olha: influenciado pelas esculturas africanas e ibéricas, Picasso explode a perspectiva única em facas geométricas. O quadro que abriu a porta do século XX e do Cubismo.",
    },
    {
      slug: "a-persistencia-da-memoria",
      title: "A Persistência da Memória",
      artist: "Salvador Dalí",
      year: "1931",
      movement: "surrealismo",
      technique: "Óleo sobre tela",
      dimensions: "24,1 × 33 cm",
      location: "MoMA, Nova York",
      featured: false,
      description:
        "Relógios derretendo sobre uma praia de Cadaqués enquanto o tempo escorre: Dalí pinta seus sonhos 'fotograficamente' — método paranoico-crítico — e cria o ícone do Surrealismo e da memória fluida. Caberiam todos os relógios do mundo nesse horizonte.",
    },
  ];

  for (const a of artworks) {
    const { movement, ...rest } = a;
    await db.artwork.upsert({
      where: { slug: a.slug },
      update: {
        ...rest,
        movementId: movementMap.get(movement)!,
        imageUrl: `/artworks/${a.slug}.jpg`,
      },
      create: {
        ...rest,
        movementId: movementMap.get(movement)!,
        imageUrl: `/artworks/${a.slug}.jpg`,
      },
    });
  }

  // representative image per movement (for timeline thumbs)
  const repByMovement: Record<string, string> = {
    renascimento: "o-nascimento-de-venus",
    barroco: "a-ronda-noturna",
    neoclassicismo: "o-juramento-dos-horacios",
    romantismo: "o-andarilho-sobre-o-mar-de-nevoa",
    realismo: "os-quebra-pedras",
    "ukiyo-e": "a-grande-onda-de-kanagawa",
    impressionismo: "impressao-nascer-do-sol",
    "pos-impressionismo": "a-noite-estrelada",
    simbolismo: "o-beijo",
    expressionismo: "o-grito",
    cubismo: "as-senhoretas-de-avignon",
    surrealismo: "a-persistencia-da-memoria",
  };
  for (const [mSlug, aSlug] of Object.entries(repByMovement)) {
    const art = await db.artwork.findUnique({ where: { slug: aSlug } });
    await db.movement.update({
      where: { slug: mSlug },
      data: { imageUrl: art?.imageUrl ?? null },
    });
  }

  // ---------- Audio guides ----------
  const tracks = [
    {
      slug: "boas-vindas",
      title: "Boas-vindas ao Musæum",
      order: 1,
      artworkSlug: null as string | null,
      transcriptPt:
        "Boas-vindas ao Musæum, seu museu virtual de história da arte. Pelas próximas salas você viajará por seis séculos de criatividade humana, do florescer do Renascimento aos experimentos ousados da era moderna. Com calma. Deixe cada sala falar com você. E quando um quadro chamar, aproxime-se.",
    },
    {
      slug: "a-noite-estrelada",
      title: "A Noite Estrelada · Van Gogh",
      order: 2,
      artworkSlug: "a-noite-estrelada",
      transcriptPt:
        "Pintada da janela do asilo de Saint-Rémy em junho de 1889, A Noite Estrelada é o hino turbulento de Vincent van Gogh ao céu noturno. Veja como o cipreste sobe como uma chama escura, ligando a terra ao céu, enquanto onze estrelas giram em ritmo cósmico. Van Gogh pintou a cena da memória e da imaginação, e não da observação direta — e é isso que lhe dá seu poder onírico e emocional.",
    },
    {
      slug: "mona-lisa",
      title: "Mona Lisa · Leonardo",
      order: 3,
      artworkSlug: "mona-lisa",
      transcriptPt:
        "Leonardo da Vinci começou a Mona Lisa por volta de 1503 e a levou consigo até o fim da vida. Seu sorriso parece mudar diante de nossos olhos, graças ao sfumato — camadas delicadas de veladura que suavizam cada borda. Ela nos encara com serena confiança, e atrás dela estende-se uma paisagem imaginária de rios serpenteantes e montanhas que se dissolvem.",
    },
    {
      slug: "o-beijo",
      title: "O Beijo · Klimt",
      order: 4,
      artworkSlug: "o-beijo",
      transcriptPt:
        "O Beijo de Gustav Klimt, pintado entre 1907 e 1908, é o ícone dourado da Art Nouveau vienense. Dois amantes fundem-se numa forma única e cintilante, envoltos em folha de ouro, suspensos à beira de um penhasco florido. Os padrões geométricos de suas vestes anunciam a abstração que viria, enquanto o ouro evoca os mosaicos bizantinos que Klimt tanto admirava.",
    },
    {
      slug: "a-grande-onda-de-kanagawa",
      title: "A Grande Onda · Hokusai",
      order: 5,
      artworkSlug: "a-grande-onda-de-kanagawa",
      transcriptPt:
        "A Grande Onda de Kanagawa, criada por volta de 1831 por Katsushika Hokusai, é talvez a imagem mais reproduzida da história da arte. Uma onda monstruosa ergue-se como uma garra sobre frágeis barcos de pesca, enquanto o sagrado Monte Fuji repousa sereno ao longe. Esta xilogravura, da série '36 Vistas do Monte Fuji', viajou até a Europa e transformou artistas de Monet a Van Gogh.",
    },
    {
      slug: "o-grito",
      title: "O Grito · Munch",
      order: 6,
      artworkSlug: "o-grito",
      transcriptPt:
        "'Senti um grande grito passar pela natureza', escreveu Edvard Munch em seu diário. Em 1893 ele pintou O Grito, a imagem-matriz da ansiedade moderna. A figura na ponte não está gritando: ela ouve o grito do universo e tapa os ouvidos em desespero. O céu vermelho-sangue gira com as mesmas linhas de força que inflamam a noite de Van Gogh, pintada poucos anos antes.",
    },
    {
      slug: "moca-com-brinco-de-perola",
      title: "Moça com Brinco de Pérola · Vermeer",
      order: 7,
      artworkSlug: "moca-com-brinco-de-perola",
      transcriptPt:
        "Chamam-na de Mona Lisa do Norte. A Moça com Brinco de Pérola de Vermeer, pintada por volta de 1665, olha por sobre o ombro como se você tivesse acabado de chamar seu nome. A própria pérola é uma ilusão — apenas duas pinceladas de branco de chumbo. Mas nesse instante de giro, nessa luz suave e nesse olhar inquiridor, Vermeer capturou algo para sempre vivo.",
    },
  ];

  for (const t of tracks) {
    const artwork = t.artworkSlug
      ? await db.artwork.findUnique({ where: { slug: t.artworkSlug } })
      : null;
    await db.audioGuide.upsert({
      where: { slug: t.slug },
      update: {},
      create: {
        slug: t.slug,
        title: t.title,
        narrator: "Docente do Musæum · voz jam (EN)",
        lang: "en",
        transcript: "", // filled below from scripts (kept in sync manually)
        transcriptPt: t.transcriptPt,
        audioUrl: `/audio/${t.slug}.mp3`,
        order: t.order,
        artworkId: artwork?.id ?? null,
      },
    });
  }

  // English transcripts (must match scripts/gen-audio.sh narration)
  const enTranscripts: Record<string, string> = {
    "boas-vindas":
      "Welcome to Musaeum, your virtual museum of art history. Over the next few rooms, you will travel through six centuries of human creativity, from the blossoming of the Renaissance to the bold experiments of the modern age. Take your time. Let each room speak to you. And when a painting calls to you, come closer.",
    "a-noite-estrelada":
      "Painted from the window of an asylum in Saint Remy in June 1889, The Starry Night is Vincent van Gogh's turbulent hymn to the night sky. Look how the cypress tree rises like a dark flame, connecting earth and heaven, while eleven stars swirl in cosmic rhythm. Van Gogh painted this scene from memory and imagination, rather than direct observation, and that is what gives it its dreamlike, emotional power.",
    "mona-lisa":
      "Leonardo da Vinci began the Mona Lisa around 1503, and carried it with him until the end of his life. Her smile seems to change before our eyes, thanks to Leonardo's sfumato technique, in which delicate layers of glaze soften every edge. She gazes at us with calm confidence, and behind her lies an imaginary landscape of winding rivers and dissolving mountains.",
    "o-beijo":
      "Gustav Klimt's The Kiss, painted between 1907 and 1908, is the golden icon of Viennese art nouveau. Two lovers melt into a single shimmering form, wrapped in gold leaf, suspended on the edge of a flowering cliff. The geometric patterns on their garments hint at the coming abstraction, while the gold itself recalls the Byzantine mosaics that Klimt so admired.",
    "a-grande-onda-de-kanagawa":
      "The Great Wave off Kanagawa, created around 1831 by Katsushika Hokusai, is perhaps the most reproduced image in the history of art. A monstrous wave rears like a claw over fragile fishing boats, while sacred Mount Fuji sits serene in the distance. This woodblock print, part of the series Thirty-six Views of Mount Fuji, travelled to Europe and transformed artists from Monet to Van Gogh.",
    "o-grito":
      "I felt a great scream pass through nature, wrote Edvard Munch in his diary. In 1893 he painted The Scream, the founding image of modern anxiety. The figure on the bridge is not screaming. It is hearing the scream of the universe, and covering its ears in despair. The blood-red sky swirls with lines of force that echo Van Gogh's night, painted only a few years before.",
    "moca-com-brinco-de-perola":
      "She is called the Mona Lisa of the North. Vermeer's Girl with a Pearl Earring, painted around 1665, looks over her shoulder as if you had just called her name. The pearl itself is an illusion, just two strokes of lead white. Yet in that moment of turning, in that soft light and that questioning glance, Vermeer captured something forever alive.",
  };
  for (const [slug, transcript] of Object.entries(enTranscripts)) {
    await db.audioGuide.update({ where: { slug }, data: { transcript } });
  }

  // ---------- Tour rooms ----------
  const rooms = [
    {
      slug: "salao-renascentista",
      name: "Salão Renascentista",
      description:
        "Paredes verde-claro, mármores e molduras douradas: o berço da perspectiva e do humanismo.",
      panoramaUrl: "/panoramas/renascimento-hall.jpg",
      order: 1,
      hotspots: [
        {
          id: "venus-info",
          type: "info",
          lat: 0,
          lon: -35,
          label: "O Nascimento de Vênus · Botticelli",
          artworkSlug: "o-nascimento-de-venus",
        },
        {
          id: "mona-info",
          type: "info",
          lat: 0,
          lon: 30,
          label: "Mona Lisa · Leonardo",
          artworkSlug: "mona-lisa",
        },
        {
          id: "to-impressionismo",
          type: "teleport",
          lat: -18,
          lon: 130,
          label: "Ir para a Galeria Impressionista",
          targetRoomSlug: "galeria-impressionista",
        },
        {
          id: "to-moderna",
          type: "teleport",
          lat: -18,
          lon: -140,
          label: "Ir para a Ala Contemporânea",
          targetRoomSlug: "ala-contemporanea",
        },
      ],
    },
    {
      slug: "galeria-impressionista",
      name: "Galeria Impressionista",
      description:
        "Luz difusa de vitrais e paredes sálvia: o instante capturado em pinceladas de cor pura.",
      panoramaUrl: "/panoramas/impressionismo-gallery.jpg",
      order: 2,
      hotspots: [
        {
          id: "impressao-info",
          type: "info",
          lat: 0,
          lon: 18,
          label: "Impressão, Nascer do Sol · Monet",
          artworkSlug: "impressao-nascer-do-sol",
        },
        {
          id: "onda-info",
          type: "info",
          lat: 0,
          lon: -28,
          label: "A Grande Onda · Hokusai",
          artworkSlug: "a-grande-onda-de-kanagawa",
        },
        {
          id: "noite-info",
          type: "info",
          lat: 0,
          lon: 72,
          label: "A Noite Estrelada · Van Gogh",
          artworkSlug: "a-noite-estrelada",
        },
        {
          id: "to-renascentista",
          type: "teleport",
          lat: -18,
          lon: -140,
          label: "Voltar ao Salão Renascentista",
          targetRoomSlug: "salao-renascentista",
        },
        {
          id: "to-moderna-2",
          type: "teleport",
          lat: -18,
          lon: 140,
          label: "Ir para a Ala Contemporânea",
          targetRoomSlug: "ala-contemporanea",
        },
      ],
    },
    {
      slug: "ala-contemporanea",
      name: "Ala Contemporânea",
      description:
        "Paredes brancas e concreto polido: o século XX em tela aberta, do grito ao sonho.",
      panoramaUrl: "/panoramas/moderna-wing.jpg",
      order: 3,
      hotspots: [
        {
          id: "beijo-info",
          type: "info",
          lat: 0,
          lon: -32,
          label: "O Beijo · Klimt",
          artworkSlug: "o-beijo",
        },
        {
          id: "grito-info",
          type: "info",
          lat: 0,
          lon: 35,
          label: "O Grito · Munch",
          artworkSlug: "o-grito",
        },
        {
          id: "memoria-info",
          type: "info",
          lat: 0,
          lon: 100,
          label: "A Persistência da Memória · Dalí",
          artworkSlug: "a-persistencia-da-memoria",
        },
        {
          id: "to-renascentista-2",
          type: "teleport",
          lat: -18,
          lon: -140,
          label: "Voltar ao Salão Renascentista",
          targetRoomSlug: "salao-renascentista",
        },
        {
          id: "to-impressionista-2",
          type: "teleport",
          lat: -18,
          lon: 140,
          label: "Ir para a Galeria Impressionista",
          targetRoomSlug: "galeria-impressionista",
        },
      ],
    },
  ];

  for (const r of rooms) {
    await db.tourRoom.upsert({
      where: { slug: r.slug },
      update: {},
      create: {
        slug: r.slug,
        name: r.name,
        description: r.description,
        panoramaUrl: r.panoramaUrl,
        hotspots: JSON.stringify(r.hotspots),
        order: r.order,
      },
    });
  }

  const counts = {
    movements: await db.movement.count(),
    artworks: await db.artwork.count(),
    audioGuides: await db.audioGuide.count(),
    rooms: await db.tourRoom.count(),
  };
  console.log("Seed complete:", counts);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
