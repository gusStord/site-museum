# Project Worklog — Musæum: Art History Museum Platform

Project: Plataforma de museu de história da arte (Next.js 16, TypeScript, Tailwind 4, shadcn/ui, Prisma/SQLite).

Core features:
1. Cross-fade spotlight hero (cross-fade de obras + spotlight seguindo o cursor)
2. Follow-cursor 4x magnifier (lupa 4x que segue o cursor sobre as obras)
3. Horizontal scroll genre timeline (linha do tempo horizontal de movimentos artísticos)
4. Drag-to-look 3D virtual tour with teleport hotspots (tour 3D panorâmico com hotspots de teletransporte — three.js)
5. Audio-guide circular progress rings (audioguia com anéis de progresso circulares — TTS real)

Plus: PWA (manifest + service worker adaptados dos arquivos enviados pelo usuário em /upload), pt-BR UI, tema museu (ivory/charcoal/gold — SEM azul/índigo), fontes Playfair Display + Geist.

Decisões importantes:
- TTS testado em pt-BR (vozes kazi/tongtong) → áudio ilegível. Voz "jam" em inglês → perfeito (verificado via ASR). Audioguia: narração EN (voz de docente) + transcrição PT+EN na UI. UI toda em pt-BR.
- Imagens: obras de domínio público baixadas do Wikimedia Commons em alta resolução (para a lupa 4x). Panoramas 360: gerados com z-ai image (1440x720, proporção equiretangular 2:1).
- Dev server já rodando na porta 3000 (não reiniciar; hot reload cuida das mudanças).
- Idioma da UI: português (usuário em America/Sao_Paulo).
- three.js será instalado para o tour 3D.
- API routes: /api/artworks, /api/artworks/[slug], /api/artworks/[slug]/like (POST), /api/movements, /api/rooms, /api/audio-guides.
- Contrato de tipos compartilhado em src/lib/museum.ts (cliente usa TanStack Query).

---
Task ID: 1
Agent: main (Z.ai Code)
Task: Init worklog, tool checks, asset dirs

Work Log:
- Verificado: z-ai CLI em /usr/local/bin/z-ai; bun 1.3.14; node 24; dev server Next 16.1.3 rodando (GET / 200).
- Criados dirs: public/artworks, public/panoramas, public/audio, public/icons, scripts/.
- Testes TTS: kazi/tongtong pt-BR → ilegível (ASR confirmou); jam EN → perfeito.
- Plano de tasks registrado no TodoWrite (IDs: 1, 2-a, 2-b, 2-c, 3, 4-0, 4-a..4-d, 5, 6).

Stage Summary:
- Worklog criado; ferramentas validadas; decisão de idioma do audioguia tomada (EN narração + PT transcrição).

---
Task ID: 4-c
Agent: full-stack-developer
Task: Drag-to-look 360° panorama viewer with teleport hotspots (src/components/museum/virtual-tour.tsx — three.js, única arquivo atribuído)

Work Log:
- Criado `src/components/museum/virtual-tour.tsx` ('use client', ~1010 linhas, TS estrito, zero `any`): seção `#tour` full-bleed `bg-stone-950` com header (overline VISITA IMERSIVA, h2 font-display "Tour Virtual 3D", parágrafo pt-BR) + viewer 16/10 → 21/9 + 3 cards de sala (thumb panorama + "Entrar na sala").
- Engine three.js criado UMA vez em useEffect (deps [pushNotice]); `await import("three")` dinâmico (SSR-safe). Renderer: antialias, pixelRatio ≤2, SRGBColorSpace; SphereGeometry(500,64,40).scale(-1,1,1) + MeshBasicMaterial (cor inicial 0x1c1917 até a 1ª textura; branco ao mapear); PerspectiveCamera(75, w/h, 1, 1100) na origem.
- Loop rAF clássico: phi=degToRad(90-lat), theta=degToRad(lon), target=(sinφcosθ, cosφ, sinφsinθ), camera.lookAt — lon/lat iniciais 0/0, sem offsets. Drag: pointer events com setPointerCapture, `lon -= dx*0.18*(fov/75)` / `lat += dy*0.18*(fov/75)` (clamp ±85), inércia na soltura com decay 0.93/frame e velocidade suavizada por dt; clique suprimido 150ms após arrasto >4px.
- Zoom: wheel não-passivo no canvas (fov clamp 35..95, deltaY*0.05, preventDefault) + botões 44px "Aproximar"/"Afastar" (±10). Recentralizar: tween 600ms easeOutCubic para lon≡0 (múltiplo de 360 mais próximo), lat=0, fov=75. Fullscreen: requestFullscreen + listener fullscreenchange (ResizeObserver cuida do resize; classes trocam para h-screen w-screen).
- Canvas CRIADO PELO ENGINE e anexado a um host div (classes exigidas absolute inset-0 block h-full w-full, touch-action none, role="img", aria-label atualizado por sala) — evita contexto WebGL perdido em reinit (HMR/StrictMode); `reactStrictMode: false` confirmado no next.config. Fallback "Seu navegador não suporta WebGL" via try/catch.
- Troca de sala (API imperativa `engineRef.current.loadRoom(room)`): fade overlay 280ms → TextureLoader.loadAsync → swap material.map + needsUpdate + dispose da textura antiga → reset lon/lat/fov → fade-in; token de corrida (loadToken) contra teleporte superseded; overlay de loading (LoaderCircle spin + "Carregando sala…"); toast central "VOCÊ ESTÁ EM {sala}" (framer-motion, 1.7s); erro de textura restaura sala atual + notice.
- Hotspots como overlay HTML (sem raycast): projeção por frame com Vector3.project(camera) pós-render, HOTSPOT_RADIUS=460, visibilidade v.z<1 && NDC ±1.05, x/y em px do wrapper, scale=clamp(1.6−v.z*0.5, 0.8, 1.15); setState só quando muda (signature id:x:y:scale arredondados → zero re-render parado; durante drag ≤5 nós em subárvore memoizada `HotspotLayer`). Teleport: 48px âmbar + Footprints + anel pulsante (motion, 2.2s) + chip de label; info: 44px + Info + chip; onClick → goToRoom / useMuseumStore.openArtworkDialog(artworkSlug); pointerdown no hotspot também inicia pan (arrastar sobre hotspot gira a vista).
- Pills de sala (aria-pressed, ativa bg-amber-500), chip de sala atual bottom-left, hint "Arraste para olhar em volta · role para dar zoom" (some após 1º pointerdown), teclado no wrapper (setas pan, +/- zoom), room cards com scrollIntoView + teleporte.
- Cleanup completo: cancelAnimationFrame, RO.disconnect, todos listeners removidos, dispose material/textura/geometry, renderer.dispose() + forceContextLoss (try/catch), canvas.remove(); timers limpos.
- Verificação: `bunx tsc --noEmit` → 0 erros no meu arquivo (erros restantes são de outros arquivos em progresso: examples/, skills/, layout.tsx, audio-guide-section.tsx). `bun run lint` → 0 problemas no meu arquivo (3 erros restantes são do audio-guide-section.tsx de outro agente). GET /api/rooms 200 confirmado (3 salas, hotspots conforme contrato).

Stage Summary:
- Tour virtual 3D completo e autocontido em 1 arquivo: engine imperativo (refs, sem recriação em re-render), hotspots projetados via NDC, teleporte com fade, zoom/recentralizar/fullscreen, a11y (aria-labels, aria-pressed, role=img, teclado), responsivo 16/10→21/9, tema museu escuro + âmbar, pt-BR. Integração: page.tsx deve renderizar `<VirtualTour />` (default ou named export de `@/components/museum/virtual-tour`); nenhum prop necessário. Panoramas carregados por URL; ausência/404 tratada com notice + fallback escuro. Nota: canvas é criado pelo engine (não JSX) para robustez de contexto WebGL — DOM final idêntico ao especificado.

---
Task ID: 4-d
Agent: frontend-styling-expert
Task: Audio guide section (src/components/museum/audio-guide-section.tsx) — audioguia com anéis de progresso circulares, seek por ângulo, auto-advance, integração com store e Media Session.

Work Log:
- Criado src/components/museum/audio-guide-section.tsx ('use client', ~1120 linhas): seção `id="audioguia"` py-20/py-24 bg-background, header AUDIOTOUR + "Audioguia" (font-display) + badge EN "Narração em inglês · leitura em português", grid lg:[5fr_7fr] (player à esquerda, lista à direita; mobile empilhado player primeiro).
- Arquitetura de áudio: UM único `<audio preload="metadata">` (ref) renderizado no componente; src gerenciado imperativamente em efeito sobre activeTrack (comparação via new URL(...).href para evitar reloads); playIntentRef controla autoplay pós-troca; pendingProgressRef restaura posição lembrada após loadedmetadata.
- Ring grande (SVG 224, r=96, stroke-[6] amber-600, dashoffset = C*(1-progress), transição 250ms linear, rotate(-90) = início 12h): anel externo decorativo stroke-border, groove stroke-muted; thumb w-28 circular da obra (ring-4 ring-card) ou círculo dourado com Headphones (faixa boas-vindas); halo tracejado amber-500/40 girando (framer-motion rotate 360, 14s) apenas ao reproduzir; botão play/pause 56px amber-600 sobrepondo a base do anel (AnimatePresence para troca de ícone).
- Seek por clique no anel (assinatura): atan2 em torno do centro, normalizado (angle + pi/2) % 2pi → fração da duração; e.detail === 0 ignorado (clique via teclado); teclado: ArrowLeft/Right ±10s, Home/End (aria-label "Ajustar posição da audição").
- Controles (flex-wrap justify-center, todos ≥44px): -10s (RotateCcw), play/pause, +10s (FastForward), velocidade 1× → 1.25× → 1.5× (playbackRate + defaultPlaybackRate reaplicados após load), volume (VolumeX/Volume1/Volume2 + Slider w-24 shadcn em audio.volume/muted).
- Transcrição: Collapsible "Transcrição · leia enquanto ouve" (BookOpen, chevron gira via group-data-[state=open]); PT primeiro (text-sm text-foreground) + EN em bloco muted italic border-l-2 amber-600/40 pl-4; chips PT/EN.
- Lista de faixas: header "Faixas" + Badge com contagem + equalizer animado (4 barras scaleY keyframes, amber-600) quando tocando; container role="list" max-h-[520px] overflow-y-auto museum-scroll pr-2; linhas = button role implicit em wrapper role="listitem" (motion.div com stagger via variants).
- Linha: 56px com mini anel de progresso (r=26, stroke 3) AO REDOR da miniatura da obra (w-11 rounded-full) — progresso ao vivo da faixa ativa / lembrado nas demais (progressMap: Record<slug, 0..1> atualizado em timeupdate); ícone central Play/Pause/Check (concluído ≥0.999, reseta ao reprimir); título line-clamp-2, "artista · movimento" (ou narrador), duração mono "—" até conhecida + chip EN (AlertCircle destructive se erro); linha ativa border-amber-600/60 bg-amber-50/50 ring + indicador layoutId animado (framer-motion) — variantes dark tokens.
- Durações: sondagem sequencial/lazy de metadados (new Audio + preload="metadata", timeout 15s, probedRef evita duplicar) preenchendo durationMap antes de qualquer play.
- Auto-advance: onEnded marca progresso 1, chama goToTrack(+1) (seleção+autoplay); última faixa → para (todos os anéis completos com Check). Erro de áudio → toast destructive "Não foi possível carregar o áudio. Tente novamente." + AlertCircle na linha.
- Store: efeito observa audioRequestSlug (dialog "Ouvir audioguia") → scroll suave até a seção + reutiliza o caminho de seleção da linha via setTimeout(0) (mantém setState apenas em handlers de evento) + clearAudioRequest().
- Media Session API (guardado com "mediaSession" in navigator): MediaMetadata (título/artista/artwork 512) + handlers play/pause/seekbackward/seekforward/previoustrack/nexttrack/seekto via ref de closures frescas.
- Acessibilidade: região sr-only aria-live="polite" ("Reproduzindo: {título}"/"Pausado: {título}"), botões iconográficos rotulados, ring focável com setas, aria-current na linha ativa, role list/listitem.
- Estados: skeleton (Card + linhas) durante loading; "Nenhuma faixa disponível no momento." se vazio; auto-seleção da faixa 1 SEM autoplay (activeSlug derivado de selectedSlug ?? first) com dica "Escolha uma faixa para começar".
- Conformidade lint: reestruturado para a regra react-hooks/set-state-in-effect do ESLint 16 (zero setState síncrono em efeitos: resets de clock movidos para onLoadStart do <audio>; auto-seleção virou estado derivado; requisição da store via callback assíncrono). Nenhum `any`, imports todos usados.
- Verificado: `bunx tsc --noEmit` sem erros no meu arquivo (erros restantes são de outros arquivos/exemplos pré-existentes); `bunx eslint src/components/museum/audio-guide-section.tsx` limpo; `bun run lint` do projeto passa; GET /api/audio-guides retorna 7 faixas (boas-vindas sem obra + 6 com obra) — contrato confirmado; dev server :3000 saudável (200).

Stage Summary:
- Audioguia completo em um único arquivo: player com anel de progresso clicável (seek por ângulo), lista com mini-anéis por faixa e progresso lembrado, auto-advance, velocidade/volume, transcrição PT+EN, toasts de erro, integração com zustand (audioRequestSlug) e Media Session. Pronto para integração na home pelo agente responsável (import { AudioGuideSection } de "@/components/museum/audio-guide-section").

---
Task ID: 4-a
Agent: frontend-styling-expert
Task: Hero cross-fade com spotlight (lanterna), lupa 4× follow-cursor, grid da coleção com filtros/likes e dialog visualizador de obra

Work Log:
- Criados 4 arquivos 'use client' em src/components/museum/: hero-spotlight.tsx, magnifier.tsx, collection-section.tsx, artwork-dialog.tsx. Nenhum arquivo existente foi modificado.
- hero-spotlight (#inicio): h-[92svh] min-h-[560px] bg-stone-950 text-stone-50; slides = artworks.filter(featured).slice(0,6); camadas <motion.img> absolutas com cross-fade 1.6s (easeInOut) + Ken-Burns scale 1.06→1.12 em 9s linear; useReducedMotion desativa zoom (estático 1.06) e encurta fade (0.3s); auto-advance 6500ms — interval recriado via dep [index] (reset em navegação manual) e tick ignora document.hidden (pausa); primeiro img loading="eager", demais lazy.
- Spotlight: 2 overlays pointer-events-none com radial-gradient(circle 340px at var(--mx,50%) var(--my,45%)) — feixe quente rgba(255,236,197,0.12)/transparent 60% + escurecimento transparent→rgba(12,10,9,0.62)/72%; vars de CSS setadas na section via onPointerMove (%); loop rAF Lissajous (x=50+32·sin(t·0.00035), y=42+18·sin(t·0.00021)) cancelado permanentemente no 1º pointermove real (pointerType!=="touch" — touch mantém o sweep); prefers-reduced-motion também desliga o sweep (fallbacks CSS 50%/45%).
- Lanterna: ícone "Lantern" NÃO existe no lucide-react 0.525 → usado Flashlight/FlashlightOff (semântica correta de "lanterna"). Botão 44px top-right z-20, aria-pressed={lanternOn} (default ON = sala escura), desativa a camada de escurecimento (opacity-0, transition 500ms).
- Hero extras: CTAs h-11 (44px) âncoras #colecao (amber) e #tour (outline stone); chips de stats REAIS do /api/stats com pontos dourados (15 obras-primas · 12 movimentos · 3 salas 3D · 7 faixas de audioguia); caption bottom-left com AnimatePresence mode="wait" (fade/slide 0.4s); controles bottom-right prev/next 44px + dots (ativo w-6 bg-amber-400, inativo w-2 bg-stone-600, aria-label "Ver obra n de N: título"); scroll hint 44px central com ChevronDown animate-bounce + sr-only; gradiente inferior h-40 bg-gradient-to-t from-stone-950/90; Skeleton bg-stone-900 full-bleed enquanto artworks carregam; índice seguro derivado safeIndex = index % slides.length (zero setState em effects).
- magnifier: lupa circular 176px (size-44) border-2 amber-500/80 + ring-4 stone; ZOOM=4; div interna = imagem inteira em naturalWidth·4 × naturalHeight·4 com background-position = 88 − fx·naturalW·4 (fórmula da spec generalizada para frações 0..1 — matematicamente correta em qualquer tamanho exibido, incl. images 1920px reduzidas); container w-fit max-w-full envolve EXATAMENTE o <img> (auto-contenção de replaced element via max-w/max-h, sem letterbox) → percentuais da lupa sempre mapeiam na imagem visível; crosshair amber (2 linhas 1px) + badge "4×" bg-stone-950/80 text-amber-400 no topo da lente; cursor-none durante hover; matchMedia("(pointer: fine)") via useSyncExternalStore (SSR-safe, reage a mudanças de ponteiro); touch → sem lupa + <MagnifierHint/> interno; teclado: tabIndex 0, role="application", aria-label "Ampliação 4 vezes da obra {alt}", setas movem 24px com clamp e lente visível (foco centra a lente).
- Magnifier extras (documentados como extensão): props imgClassName (constraint max-h no dialog) e hintClassName (hint legível em painel escuro); wrapper <MagnifierInner key={src}> reseta estado na troca de obra sem setState-in-effect; ref callback (useCallback) cobre imagem já decodificada em cache (img.complete).
- collection-section (#colecao): py-20/24 bg-background; header O ACERVO / A Coleção (font-display 4xl/5xl) + parágrafo muted; chips de movimento derivados da lista em ordem da API ("Todos" com dot âmbar; ativo = style backgroundColor movement.color + texto branco; inativo bg-card border; min-h-11 rounded-full, overflow-x-auto no-scrollbar); contagem "{n} de {total} obras" (aria-live) acima do grid à direita; grid 1/2/3 colunas gap-6/8; cards motion.article role=button tabIndex Enter/Space aria-label "Ver obra {title}" → openArtworkDialog(slug); entrance opacity-0 y-24 stagger index·0.05 viewport once margin -48px; figure aspect-[4/5] rounded-xl ring-1 ring-black/5 hover:scale-[1.04] 700ms; badge movimento (color+'E6' backdrop-blur uppercase); botão like 44px circular bg-stone-950/45 com heart preenchido amber quando curtido (e.stopPropagation).
- Likes: useMutation POST /api/artworks/{slug}/like com onMutate otimista (cancelQueries + snapshot + setQueryData qk.artworks), rollback + toast destructive no erro, invalidate qk.artworks no onSettled. API só incrementa (não há unlike) → 1 curtida/obra/sessão, botão disabled após curtir; liked slugs em estado local POR COMPONENTE (grid e dialog não compartilham; store global é read-only para mim).
- artwork-dialog: renderizado 1× no nível app, lê dialogSlug do zustand; useQuery qk.artwork(slug) enabled=!!dialogSlug com fetcher local fetchArtworkDetail (ArtworkDetail inline = ArtworkDTO & { audioGuide }); DialogContent dark bg-stone-950 border-stone-800 max-w-6xl w-[95vw] grid md:grid-cols-[1.35fr_1fr] gap-0 p-0 max-h-[92vh]; painel esquerdo = sala escura com Magnifier (max-h-[38vh] md:max-h-[72vh]) + MagnifierHint; painel direito museum-scroll (reset scrollTop via ref em [dialogSlug, artwork?.id]) com chip de movimento, DialogTitle font-display 3xl/4xl, artista·ano italic amber-300/90, descrição, dl Técnica/Dimensões/Localização (dt uppercase 10px stone-500), stats Eye "visitas" · Heart "curtidas", botões Curtir (outline stone, otimista) e "Ouvir audioguia" (amber, Headphones → requestAudio(audioGuide.slug) + closeArtworkDialog + scrollIntoView #audioguia); mobile: o dialog inteiro faz scroll (overflow-y-auto md:overflow-hidden) pois 72vh+85vh estourariam o viewport em coluna única.
- Dialog invalida SOMENTE qk.artworks no onSettled — refetch do detail inflaria o contador de visitas (GET conta visita).
- Refatorações p/ ESLint react-hooks v6 (set-state-in-effect): index-reset → safeIndex derivado no render; finePointer → useSyncExternalStore; reset por troca de src → remount por key.
- Verificação: `bunx tsc --noEmit` → 0 erros nos 4 arquivos (restam layout.tsx de outro agente + examples/skills fora de escopo). `bun run lint` → exit 0 (projeto limpo). Bun Transpiler: parse OK nos 4. dev.log sem erros fatais (server saudável, hot reload ativo). APIs testadas: /api/artworks (15 obras, featured flags ok), /api/stats (15/12/7/3).

Stage Summary:
- 4 componentes prontos e verificados (tsc + eslint + parse TSX). Integração (page assembler): renderizar <HeroSpotlight /> (topo, #inicio), <CollectionSection /> (#colecao) e <ArtworkDialog /> UMA vez no nível da página (após as seções); nenhum prop necessário. O dialog abre via useMuseumStore.openArtworkDialog(slug) (grid + hotspots do tour), ESC/X fecha; "Ouvir audioguia" seta audioRequestSlug e rola para #audioguia (seção do agente 4-d — convención: slug da faixa = slug da obra quando hasAudio). Desvios da spec (documentados): ícone Flashlight/FlashlightOff em vez de Lantern (inexistente no lucide-react 0.525); likes sem toggle-off (API só incrementa; 1 curtida/sessão/obra, botão disabled); estado de curtidas local por componente (não compartilhado grid↔dialog); Magnifier aceita imgClassName/hintClassName extras e usa container w-fit (spec pedia block w-full) para mapeamento perfeito da lente com imagem constrainada por max-height; dialog scrolla como um todo no mobile; CTA "Tour virtual 3D" aponta para #tour (seção a criar pelo agente do tour).

---
Task ID: 4-b
Agent: frontend-styling-expert
Task: Build genre timeline section (src/components/museum/timeline-section.tsx) — "Linha do Tempo dos Movimentos" (seção #linha-do-tempo, pt-BR, tema museu).

Work Log:
- Criado src/components/museum/timeline-section.tsx ('use client') — único arquivo alterado/criado. Export nomeado `TimelineSection` + default.
- Header: overline "CRONOLOGIA" (tracking-[0.25em] amber-700/80), h2 font-display "Cinco Séculos em Uma Parede", parágrafo muted; hint chip (MoveHorizontal + "Arraste ou role para explorar", oculto < md) e botões prev/next redondos 44px (ChevronLeft/Right, aria-labels pt-BR, disabled nos extremos).
- Dados: useQuery(qk.movements, fetchMovements). Loading = 5 Skeletons (h-64, w-[300px] md:w-[340px]); erro = mensagem + botão "Tentar novamente" (refetch).
- Trilho cronológico contínuo na fileira de cards (absolute, inset-x-6, topo): linha base 2px bg-border + segmentos coloridos por movimento com left/width = pct(start)/pct(end) sobre a faixa global (mín startYear dos dados; máx endYear arredondado p/ cima, clamp 2000 → 1400–2000), ticks a cada 50 anos (labels font-mono text-[10px] + marquinhas) e dots de início de cada movimento. Marcações decorativas (aria-hidden).
- Cards (motion.article, aria-label={name}, decorativos/não clicáveis): imagem next/image h-36 object-cover com lavagem mix-blend-multiply (color+'26') e fallback ícone Palette quando imageUrl null; chip de era "{start}–{end}" (color + borderColor color+'66'); nome font-display com dot da cor; descrição line-clamp-4; mini barra de vigência (trilha 1400→2000, segmento na cor) + "≈ N anos de vigência". Entrada whileInView sutil (opacity/y, once, respeita prefers-reduced-motion).
- Drag-to-scroll: pointerdown → setPointerCapture; threshold 6px p/ ativar; scrollLeft -= dx no pointermove (preventDefault p/ mouse); supressão de click pós-arraste via onClickCapture; data-dragging="true" durante o arraste; touch-pan-y (toque horizontal arrasta o trilho, vertical rola a página normalmente); inércia pós-soltura (decay 0.94/frame) + assentamento exponencial (rAF) no card mais próximo.
- Wheel-to-horizontal: listener não-passivo no container — se |deltaY| > |deltaX| e ainda há rolagem na direção, preventDefault + scrollLeft += deltaY (deltaMode "line" ×16 p/ Firefox); rolagem horizontal nativa (trackpad deltaX) preservada; ao fim da página, deixa a página rolar; após 160ms de inatividade assenta no card mais próximo.
- Teclado: container tabIndex={0} role="region" aria-label="Linha do tempo dos movimentos artísticos"; ArrowLeft/Right/Up/Down avançam ~1 card (âncora de snap ≈360px), Home/End nos extremos, todos com preventDefault.
- Snap: repouso = snap-x snap-proximity + scroll-px-6; durante drag/roda/animação alterna para snap-none (classList imediato + estado React) para o snap não brigar com a interação; snap devolvido apenas sobre ponto exato de encaixe (evita salto do re-snap do navegador). Motor de animação próprio (glide/settle via rAF) cancelável por qualquer nova interação.
- Barra de progresso (fundo do container): role="scrollbar" (aria-controls/valuemin/valuemax/valuenow), pista h-1.5 bg-border clicável/arrastável (seek proporcional com pointer capture), thumb w-16 gradiente from-amber-700 to-amber-500 posicionado por progresso, label "{p}%" tabular-nums à direita.
- Edge fades: mask-image/-webkit-mask-image (24px) no scroller; .no-scrollbar; overscroll-x-contain; focus-visible ring dourado (ring/50). Sem azul/índigo; acentos amber.
- Verificações: `bunx tsc --noEmit` — 0 erros neste arquivo (erros restantes do projeto vêm de examples/, skills/ e src/app/layout.tsx de outros agentes); `bun run lint` exit 0; smoke tests SSR via renderToString confirmaram header/skeletons/cards/rail/segmentos/chip de era/ARIA na saída HTML (pending e com dados mockados).

Stage Summary:
- Seção de linha do tempo completa e autocontida em 1 arquivo (~760 linhas), pronta para integração. Nota p/ integrador: requer QueryClientProvider (usar <Providers> do providers.tsx) como ancestral — montar `<TimelineSection />` no page.tsx entre o hero e o tour 3D; interações (drag/roda/teclado/progresso/snap) não dependem de contexto externo.

---
Task ID: 5
Agent: full-stack-developer (assembly)
Task: Final page assembly — site-header.tsx, site-footer.tsx e src/app/page.tsx (montagem da home do Musæum)

Work Log:
- Audit de exports (todos NOMEADOS, confirmados por leitura dos arquivos): HeroSpotlight, CollectionSection, TimelineSection, VirtualTour, AudioGuideSection, ArtworkDialog, Providers, RegisterSW; useToast de "@/hooks/use-toast" (retorna { toast, ... }); Sheet/SheetTrigger/SheetContent(side prop)/SheetHeader/SheetTitle/SheetDescription de "@/components/ui/sheet". Toaster já renderizado no layout.tsx (toasts funcionam sem alterá-lo).
- Criado src/components/museum/site-header.tsx ('use client'): header sticky top-0 z-50 com border-border/60, bg-background/80 + backdrop-blur-md (supports-[backdrop-filter]:bg-background/60); inner mx-auto h-16 max-w-6xl justify-between gap-4 px-4 md:px-6; brand = âncora #inicio (aria-label "Musæum — voltar ao início") com SVG inline de templo clássico (frontão + arquitrave + 3 colunas + estilóbata/base, stroke 1.5, h-7 w-7 text-amber-600) + span font-display "MUSÆUM" (text-base sm:text-lg).
- Nav desktop (hidden md:flex): Coleção/Linha do Tempo/Tour 3D/Audioguia → #colecao, #linha-do-tempo, #tour, #audioguia com aria-labels descritivos e classes especificadas (rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-muted hover:text-foreground).
- Cluster direito: (1) botão de instalação PWA — listener "beforeinstallprompt" (preventDefault + evento em state via tipo local InstallPromptEvent, sem colidir com o global do lib.dom); quando presente, Button size sm variant outline com Download + "Instalar app" (label hidden sm:inline; h-11 px-4 p/ alvo de 44px); onClick → prompt() → await userChoice → aceito: toast default "Musæum foi instalado no seu dispositivo." (sem emoji); state zerado no finally; listener "appinstalled" também limpa. (2) Theme toggle next-themes: guard de montagem via useSyncExternalStore (isHydrated canônico — evita a regra react-hooks/set-state-in-effect do ESLint 16, ativa neste projeto) + suppressHydrationWarning; Button ghost size-11 (44px) com Moon (claro) / Sun (escuro), aria-label "Alternar entre tema claro e escuro". (3) Menu mobile (md:hidden): Sheet controlado (open/onOpenChange) com SheetTrigger asChild Button ghost size-11 Menu (aria-label "Abrir menu"); SheetContent side="right" className="w-72" com SheetHeader + SheetTitle "Musæum" (font-display) + SheetDescription sr-only (evita warning Radix), nav com os 4 links (block px-2 py-3 text-base, onClick fecha o sheet), botão Instalar app h-11 w-full quando disponível (fecha o sheet ao clicar) e rodapé "PWA · funciona offline" (mt-auto).
- Efeito de montagem no header: document.documentElement.style.scrollBehavior = "smooth" + scrollPaddingTop = "80px" (offset do header sticky nos anchors) — sem tocar em globals.css.
- Criado src/components/museum/site-footer.tsx (SERVER component, sem 'use client'): footer mt-auto bg-stone-950 text-stone-300 (regra sticky-footer: wrapper da página é min-h-screen flex flex-col); grid max-w-6xl md:grid-cols-3 com bloco de marca (SVG h-8 w-8 text-amber-500 + MUSÆUM font-display text-xl text-stone-50 + descrição + chips "PWA · funciona offline" e "Audioguia EN/PT"), bloco Explorar (h3 uppercase tracking-[0.2em] + 4 links block py-1 hover:text-amber-400 + "Voltar ao topo") e bloco Créditos (texto IA/domínio público); barra inferior border-t border-stone-800/60 com "© {new Date().getFullYear()} Musæum — Museu Virtual de História da Arte" e "Construído com Next.js · Tailwind CSS · three.js" (col → sm:flex-row justify-between).
- Reescrito src/app/page.tsx (SERVER component, substituído por completo): Providers > RegisterSW + div flex min-h-screen flex-col bg-background (SiteHeader, main flex-1 com HeroSpotlight/CollectionSection/TimelineSection/VirtualTour/AudioGuideSection, SiteFooter mt-auto) + ArtworkDialog exatamente 1× fora do wrapper flex, dentro de Providers.
- Verificação: `bunx tsc --noEmit` → 0 erros nos meus 3 arquivos (restam apenas examples/, skills/ e src/app/layout.tsx `Italic` de outros agentes — fora do meu escopo; página renderiza normalmente). `bun run lint` → exit 0 (projeto inteiro). curl / → HTTP 200; grep confirma MUSÆUM 3×, Musæum 16×, audioguia 17×, linha-do-tempo 7× e os ids #inicio/#colecao/#linha-do-tempo/#tour/#audioguia presentes 1× cada; estrutura header → main(5 seções) → footer na ordem correta. dev.log: sem erros de compilação/runtime.
- Observações (não causadas pela montagem, reportadas p/ os responsáveis): public/panoramas (0 arquivos), public/audio (0) e public/icons (0) estão vazios — dev.log registra 404 em /audio/*.mp3 e /panoramas/*.jpg (o layout também referencia /icons/icon-192.png; manifest referencia icon-192/512). public/artworks tem 15 imagens OK. As tarefas de geração de assets (panoramas 360, TTS, ícones) aparentemente não foram concluídas pelos agentes anteriores — fora do escopo do Task 5 (restrição: modificar apenas os 3 arquivos da montagem).

Stage Summary:
- Home do Musæum montada e verificada: header sticky com marca/navegação/instalação PWA/tema/menu mobile, 5 seções existentes na ordem correta (hero → coleção → linha do tempo → tour 3D → audioguia), rodapé escuro responsivo com mt-auto (sticky-footer) e ArtworkDialog 1× no nível da página dentro de Providers. tsc/lint limpos para os 3 arquivos; GET / 200 com todas as seções renderizadas. Restam apenas os assets de panoramas/áudio/ícones (tarefas de outros agentes) para a experiência completa.

---
Task ID: 2-b
Agent: general-purpose (images)
Task: Panoramas 360 + ícones PWA + fix layout.tsx (Italic)

Work Log:
- Corrigido src/app/layout.tsx: removido SOMENTE o import não usado `Italic` de "next/font/google" (era o último erro de tsc em src/). Nada mais alterado no arquivo.
- `bash scripts/gen-images.sh`: os 4 assets já existiam de execução anterior (panoramas renascimento-hall / impressionismo-gallery / moderna-wing + icon-master.png), então o script pulou todos ("= exists"); nenhum retry/API necessário.
- Dimensões validadas via sharp: 3 panoramas 2048x1024 JPEG (equiretangular 2:1, prontos p/ three.js) e icon-master 1024x1024.
- VLM (z-ai vision, /tmp/vlm-p1..3.json) confirmou interiores de museu/galeria nos 3 panoramas: p1 "grand museum gallery, checkered marble floor, green walls, gold-framed classical portraits, coffered ceiling"; p2 "spacious art gallery, sage green walls, herringbone wood floor, skylight, gold-framed landscapes"; p3 "modern art gallery, curved white walls, concrete floors, abstract paintings, track lighting". Nenhuma regeneração necessária.
- Derivados do ícone via sharp: icon-512.png (512²), icon-192.png (192²), apple-touch-icon.png (180²) — PNGs reais, todos >30KB (40–283KB).
- icon-master.png chegou do CLI z-ai com bytes JPEG sob extensão .png (confirmado via `file`); reencodado in-place para PNG verdadeiro com sharp (pixels inalterados, 1024x1024, 818KB).
- `bunx tsc --noEmit`: 0 erros em src/ (erro `Italic` do layout.tsx resolvido); restam apenas exemplos de examples/ e skills/ (pré-existentes, fora de escopo, ignorados conforme instrução).

Stage Summary:
- Pipeline de imagens completo: 3 panoramas 2048x1024 validados por dimensão + VLM (interiores de museu), ícone master 1024x1024 (PNG real) e derivados 512/192/180 gerados; layout.tsx corrigido → tsc limpo para src/. Os 404 de /panoramas/*.jpg e /icons/* reportados pelo Task 5 estão resolvidos (resta apenas o áudio TTS de outro agente).

---
Task ID: 2-c
Agent: general-purpose (audio)
Task: Generate 7 TTS narration tracks (EN, voice "jam", speed 0.9) → public/audio/

Work Log:
- `bash scripts/gen-audio.sh`: 4 faixas já existiam de execução anterior (boas-vindas, a-noite-estrelada, mona-lisa, o-beijo — script pulou via "exists"); o-grito e moca-com-brinco-de-perola geradas na 1ª tentativa após os 429s iniciais.
- a-grande-onda-de-kanagawa falhou as 4 tentativas do script com HTTP 429 (rate limit). Conforme protocolo, aguardou 45s e reexecutou o comando único `z-ai tts` → sucesso na 1ª retry manual; WAV transcódado para MP3 (ffmpeg libmp3lame -q:a 3), igual ao pipeline do script.
- Validação: 7/7 arquivos em public/audio/, todos 243–299KB (>60KB ✓).
- Durações via ffprobe: boas-vindas 33,96s · moca-com-brinco-de-perola 35,42s · a-grande-onda-de-kanagawa 38,88s · o-beijo 39,77s · mona-lisa 41,23s · a-noite-estrelada 42,05s · o-grito 43,61s.
- ASR spot-check (boas-vindas): CLI z-ai asr rejeita MP3 (400 "only WAV and WebM are supported") e limita duração a 0–30s (400 code 1214). Workaround: ffmpeg extraiu os primeiros 28s → WAV 16kHz mono → transcrição OK. Resultado: "Welcome to Misei, your virtual museum of art history. Over the next few rooms, you will travel through six centuries of human creativity from the blossoming of the Renaissance to t..." — bate com o roteiro ("Misei" = renderização fonética de "Musæum"). Fala inglesa inteligível confirmada.

Stage Summary:
- Pipeline de áudio completo: 7 narrações TTS (voz "jam", speed 0.9, inglês de docente) em public/audio/, todas >240KB e 34–44s, inteligibilidade comprovada via ASR. Os 404 de /audio/*.mp3 reportados pelo Task 5 estão resolvidos. Nenhum arquivo de código alterado; nota para futuros usos: `z-ai asr` exige WAV/WebM com até 30s.

---
Task ID: 6
Agent: main (Z.ai Code)
Task: Verificação final E2E com agent-browser — tour virtual (vE), layout mobile/PWA (vH) e correção do bug de navegação do Sheet mobile

Work Log:
- Retomada da sessão: dev server saudável na :3000 (todas as APIs 200); leitura do worklog (Tasks 1, 2-a..2-c, 4-a..4-d, 5 concluídas; assets artworks 15/panoramas 3/audio 7/icons OK).
- vE (tour virtual) re-verificado por agent-browser: canvas WebGL 1232x528 presente, 3 pills de sala; drag sintético (12 moves de 12px) gira a vista e revela hotspot de teleporte ("Ir para a Ala Contemporânea", x=449); clique no teleporte → sala trocada (pill ativa "Ala Contemporânea", hotspots de info da sala visíveis: "O Beijo · Klimt", "O Grito · Munch"); clique em info hotspot → dialog da obra "O Grito" abre; Escape fecha. "Recentralizar visão" restaura hotspots frontais (Vênus x=455, Mona Lisa x=894). Zero erros de console/página.
- vH (PWA): manifest.webmanifest, sw.js, icon-192/512, apple-touch-icon, panorama renascimento-hall.jpg e audio mona-lisa.mp3 → todos HTTP 200.
- vH (mobile 375x812): header sticky com nav desktop oculta + hamburger visível; Sheet abre com 4 links; footer no fundo exato do viewport (bottom=812, sem gap/sobreposição).
- BUG ENCONTRADO E CORRIGIDO (src/components/museum/site-header.tsx): links de navegação do Sheet mobile usavam âncora padrão; o release do scroll-lock do body pelo Radix cancelava a smooth scroll em curso → página travava no meio do caminho (scrollY 1338/780 em vez de ~8586; reproduzido 2x; âncora desktop sem sheet funcionava perfeitamente, comprovando causa). Fix: handleSheetNav — preventDefault + setMenuOpen(false) + setTimeout(420ms) após a animação de saída do Sheet → target.scrollIntoView({behavior:"smooth"}) + history.replaceState. Re- verificado 2x com polling: scroll anima 0→5177→8586 e assenta com timelineTop=80 (respeitando scrollPaddingTop do header); hash correto; sheet fechado. tsc (0 erros em site-header) + `bun run lint` (exit 0) limpos.
- vH (visual): screenshots mobile da coleção, tour, audioguia e footer validados via VLM (z-ai vision) — "no apparent layout breakage", elementos contidos, imagens OK, texto legível.
- Final: reload desktop 1440x900 → 5 seções presentes (#inicio/#colecao/#linha-do-tempo/#tour/#audioguia), zero erros de página/console; dev.log sem error/failed/⨯.
- Screenshots novos: qa/screenshots/vE-tour-recheck.png, vE-tour-after-drag.png, vE-tour-teleported-contemporanea.png, vH-mobile-top.png, vH-mobile-sheet.png, vH-mobile-timeline-fixed.png, vH-mobile-footer.png, vH-mobile-collection.png, vH-mobile-tour.png, vH-mobile-audioguide.png, vH-desktop-final.png.

Stage Summary:
- Plataforma Musæum 100% verificada end-to-end em desktop e mobile: os 5 recursos pedidos (hero cross-fade com spotlight, lupa 4x, linha do tempo horizontal, tour 3D drag-to-look com hotspots de teleporte, audioguia com anéis circulares) funcionam no browser; PWA completa (manifest+SW+ícones 200); layout responsivo sem quebras; rodapé sticky correto. Um bug real de UX mobile (navegação do Sheet cancelando o smooth scroll) foi encontrado, corrigido e re-verificado. Projeto pronto para entrega.
