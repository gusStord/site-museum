#!/usr/bin/env bun
// Generate a 360° equirectangular panorama via z-ai-web-dev-sdk directly.
// Rationale: the z-ai CLI hardcodes a size whitelist that excludes 2048x1024,
// but the backend accepts it (both dims 512-2880, multiples of 32, <= 2^22 px).
// The API returns PNG base64; we re-encode to JPEG with sharp.
// Usage: bun scripts/gen-panorama.mjs "<prompt>" <output.jpg> [size]
import sharp from "sharp";

const [, , prompt, output, sizeArg] = process.argv;
const size = sizeArg || "2048x1024";
if (!prompt || !output) {
  console.error("usage: bun scripts/gen-panorama.mjs <prompt> <output> [size]");
  process.exit(1);
}

const SDK_PATHS = [
  "/home/z/.bun/install/global/node_modules/z-ai-web-dev-sdk/dist/index.js",
  "/usr/lib/node_modules/z-ai-web-dev-sdk/dist/index.js",
  "/usr/local/lib/node_modules/z-ai-web-dev-sdk/dist/index.js",
];

async function getZAI() {
  for (const p of SDK_PATHS) {
    try {
      const mod = await import(p);
      return mod.default;
    } catch {
      /* try next */
    }
  }
  const { default: ZAI } = await import("z-ai-web-dev-sdk");
  return ZAI;
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const ZAI = await getZAI();
const client = await ZAI.create();

for (let attempt = 1; attempt <= 4; attempt++) {
  try {
    process.stdout.write(`+ attempt ${attempt}: ${output} (${size})\n`);
    const res = await client.images.generations.create({ prompt, size });
    const b64 = res?.data?.[0]?.base64;
    if (!b64) throw new Error("API returned no image data");
    const buf = Buffer.from(b64, "base64");
    if (buf.length < 1024) throw new Error("image buffer too small");
    await sharp(buf).jpeg({ quality: 90, chromaSubsampling: "4:4:4" }).toFile(output);
    const meta = await sharp(output).metadata();
    console.log(`= saved ${output} (${meta.width}x${meta.height}, ${(await sharp(output).stats()).channels.length}ch ok)`);
    process.exit(0);
  } catch (err) {
    console.error(`  failed (attempt ${attempt}): ${String(err?.message || err).slice(0, 300)}`);
    if (attempt < 4) await sleep(25000);
  }
}
console.error(`X giving up on ${output}`);
process.exit(1);
