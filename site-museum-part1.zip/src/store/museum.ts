"use client";

import { create } from "zustand";

/**
 * Global museum store — cross-section communication:
 * - Artwork dialog can be opened from the collection grid AND from the
 *   virtual-tour info hotspots.
 * - Audio guide can be requested from the artwork dialog ("Ouvir audioguia").
 */
type MuseumStore = {
  dialogSlug: string | null;
  openArtworkDialog: (slug: string) => void;
  closeArtworkDialog: () => void;

  audioRequestSlug: string | null;
  requestAudio: (slug: string) => void;
  clearAudioRequest: () => void;
};

export const useMuseumStore = create<MuseumStore>((set) => ({
  dialogSlug: null,
  openArtworkDialog: (slug) => set({ dialogSlug: slug }),
  closeArtworkDialog: () => set({ dialogSlug: null }),

  audioRequestSlug: null,
  requestAudio: (slug) => set({ audioRequestSlug: slug }),
  clearAudioRequest: () => set({ audioRequestSlug: null }),
}));
