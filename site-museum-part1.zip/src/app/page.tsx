import { Providers } from "@/components/museum/providers";
import { RegisterSW } from "@/components/pwa/register-sw";
import { SiteHeader } from "@/components/museum/site-header";
import { HeroSpotlight } from "@/components/museum/hero-spotlight";
import { CollectionSection } from "@/components/museum/collection-section";
import { TimelineSection } from "@/components/museum/timeline-section";
import { VirtualTour } from "@/components/museum/virtual-tour";
import { AudioGuideSection } from "@/components/museum/audio-guide-section";
import { ArtworkDialog } from "@/components/museum/artwork-dialog";
import { SiteFooter } from "@/components/museum/site-footer";

export default function Home() {
  return (
    <Providers>
      <RegisterSW />
      <div className="flex min-h-screen flex-col bg-background text-foreground">
        <SiteHeader />
        <main className="flex-1">
          <HeroSpotlight />
          <CollectionSection />
          <TimelineSection />
          <VirtualTour />
          <AudioGuideSection />
        </main>
        <SiteFooter />
      </div>
      <ArtworkDialog />
    </Providers>
  );
}
