import { NextResponse } from "next/server";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET() {
  const movements = await db.movement.findMany({
    orderBy: { order: "asc" },
    select: {
      id: true,
      slug: true,
      name: true,
      startYear: true,
      endYear: true,
      description: true,
      color: true,
      imageUrl: true,
      order: true,
    },
  });
  return NextResponse.json({ movements });
}
