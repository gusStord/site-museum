import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import type { HotspotDTO } from "@/lib/museum";

export const dynamic = "force-dynamic";

export async function GET() {
  const rooms = await db.tourRoom.findMany({ orderBy: { order: "asc" } });
  return NextResponse.json({
    rooms: rooms.map((r) => ({
      id: r.id,
      slug: r.slug,
      name: r.name,
      description: r.description,
      panoramaUrl: r.panoramaUrl,
      order: r.order,
      hotspots: JSON.parse(r.hotspots) as HotspotDTO[],
    })),
  });
}
