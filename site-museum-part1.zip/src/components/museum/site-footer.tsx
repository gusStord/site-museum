/**
 * Musæum — Site footer
 *
 * Server component (no client JS). Dark stone footer with brand block,
 * section navigation, credits and a bottom bar. `mt-auto` keeps it
 * pinned to the bottom of the viewport on short pages (the page wrapper
 * is `min-h-screen flex flex-col`).
 */

const FOOTER_LINKS = [
  { href: "#colecao", label: "Coleção" },
  { href: "#linha-do-tempo", label: "Linha do Tempo" },
  { href: "#tour", label: "Tour 3D" },
  { href: "#audioguia", label: "Audioguia" },
] as const;

/** Classical temple line-art mark (pediment, architrave, columns, base). */
function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      <path d="M12 2.5 3 8h18Z" />
      <path d="M5 10.5h14" />
      <path d="M7.5 10.5v6.5" />
      <path d="M12 10.5v6.5" />
      <path d="M16.5 10.5v6.5" />
      <path d="M5 17h14" />
      <path d="M3.5 19.5h17" />
    </svg>
  );
}

export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="mt-auto bg-stone-950 text-stone-300">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 md:grid-cols-3 md:px-6">
        {/* Brand */}
        <div>
          <a
            href="#inicio"
            aria-label="Musæum — voltar ao início"
            className="flex items-center gap-3"
          >
            <LogoMark className="h-8 w-8 text-amber-500" />
            <span className="font-display text-xl text-stone-50">MUSÆUM</span>
          </a>
          <p className="mt-4 max-w-xs text-sm text-stone-400">
            Seis séculos de arte em um só lugar. Uma plataforma educacional
            sobre a história da arte.
          </p>
          <div className="mt-4 flex flex-wrap gap-2">
            <span className="rounded-full border border-stone-800 px-2.5 py-1 text-[11px] text-stone-400">
              PWA · funciona offline
            </span>
            <span className="rounded-full border border-stone-800 px-2.5 py-1 text-[11px] text-stone-400">
              Audioguia EN/PT
            </span>
          </div>
        </div>

        {/* Explorar */}
        <nav aria-label="Explorar o museu">
          <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-stone-500">
            Explorar
          </h3>
          <ul className="mt-4">
            {FOOTER_LINKS.map((link) => (
              <li key={link.href}>
                <a
                  href={link.href}
                  className="block py-1 text-sm text-stone-300 transition-colors hover:text-amber-400"
                >
                  {link.label}
                </a>
              </li>
            ))}
            <li>
              <a
                href="#inicio"
                className="block py-1 text-sm text-stone-300 transition-colors hover:text-amber-400"
              >
                Voltar ao topo
              </a>
            </li>
          </ul>
        </nav>

        {/* Créditos */}
        <div>
          <h3 className="text-xs font-semibold uppercase tracking-[0.2em] text-stone-500">
            Créditos
          </h3>
          <p className="mt-4 text-xs leading-relaxed text-stone-400">
            Obras-primas de domínio público via Wikimedia Commons e acervos
            públicos. Narração do audioguia gerada por IA. Panoramas 360°
            gerados por IA. Projeto educacional sem fins comerciais.
          </p>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-stone-800/60">
        <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-5 text-xs text-stone-500 sm:flex-row sm:items-center sm:justify-between md:px-6">
          <p>
            © {year} Musæum — Museu Virtual de História da Arte
          </p>
          <p>Construído com Next.js · Tailwind CSS · three.js</p>
        </div>
      </div>
    </footer>
  );
}
