"use client";

/**
 * Musæum — Site header
 *
 * Sticky museum header with brand mark (classical temple), desktop nav,
 * PWA install button (only when installable), theme toggle and a mobile
 * navigation Sheet. Also applies `scroll-behavior: smooth` and a sticky
 * scroll offset to the document root so anchor jumps don't hide under
 * the header.
 */

import { useCallback, useEffect, useState, useSyncExternalStore } from "react";
import { useTheme } from "next-themes";
import { Download, Menu, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";

/* ------------------------------------------------------------------ */
/* Types & constants                                                   */
/* ------------------------------------------------------------------ */

/**
 * Minimal shape of the `beforeinstallprompt` event (not in every DOM lib).
 * Declared locally under a distinct name to avoid clashing with the
 * global `BeforeInstallPromptEvent` declaration when present.
 */
type InstallPromptEvent = Event & {
  readonly userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
  prompt(): Promise<void>;
};

const NAV_LINKS = [
  { href: "#colecao", label: "Coleção", ariaLabel: "Ir para a Coleção" },
  {
    href: "#linha-do-tempo",
    label: "Linha do Tempo",
    ariaLabel: "Ver a Linha do Tempo dos movimentos",
  },
  { href: "#tour", label: "Tour 3D", ariaLabel: "Explorar o Tour Virtual 3D" },
  { href: "#audioguia", label: "Audioguia", ariaLabel: "Ouvir o Audioguia" },
] as const;

/** Sticky header height + breathing room for anchor scrolling. */
const SCROLL_PADDING_TOP = "80px";

/**
 * Radix keeps a body scroll lock while the Sheet is open; releasing that
 * lock cancels any in-flight smooth scroll. A plain anchor jump fired from
 * the sheet therefore stalls partway. We close the sheet first and scroll
 * only after its exit animation has finished and the lock is gone.
 */
const SHEET_EXIT_MS = 420;

/* ------------------------------------------------------------------ */
/* Hooks & small parts                                                 */
/* ------------------------------------------------------------------ */

const emptySubscribe = () => () => {};

/**
 * Hydration-safe "mounted" guard — `true` only on the client after
 * hydration. Uses `useSyncExternalStore` (no setState-in-effect).
 */
function useMounted(): boolean {
  return useSyncExternalStore(
    emptySubscribe,
    () => true,
    () => false
  );
}

/** Classical temple line-art mark (pediment, architrave, columns, base). */
function LogoMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.5}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      {/* Pediment */}
      <path d="M12 2.5 3 8h18Z" />
      {/* Architrave */}
      <path d="M5 10.5h14" />
      {/* Columns */}
      <path d="M7.5 10.5v6.5" />
      <path d="M12 10.5v6.5" />
      <path d="M16.5 10.5v6.5" />
      {/* Stylobate + base */}
      <path d="M5 17h14" />
      <path d="M3.5 19.5h17" />
    </svg>
  );
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

export function SiteHeader() {
  const { toast } = useToast();
  const { resolvedTheme, setTheme } = useTheme();
  const mounted = useMounted();

  const [deferredPrompt, setDeferredPrompt] =
    useState<InstallPromptEvent | null>(null);
  const [menuOpen, setMenuOpen] = useState(false);

  /* Smooth anchor scrolling + offset for the sticky header. */
  useEffect(() => {
    const root = document.documentElement;
    root.style.scrollBehavior = "smooth";
    root.style.scrollPaddingTop = SCROLL_PADDING_TOP;
  }, []);

  /* PWA installability. */
  useEffect(() => {
    const onBeforeInstallPrompt = (event: Event) => {
      event.preventDefault();
      setDeferredPrompt(event as InstallPromptEvent);
    };
    const onAppInstalled = () => setDeferredPrompt(null);
    window.addEventListener("beforeinstallprompt", onBeforeInstallPrompt);
    window.addEventListener("appinstalled", onAppInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onBeforeInstallPrompt);
      window.removeEventListener("appinstalled", onAppInstalled);
    };
  }, []);

  const handleInstall = useCallback(async () => {
    const deferred = deferredPrompt;
    if (!deferred) return;
    try {
      await deferred.prompt();
      const { outcome } = await deferred.userChoice;
      if (outcome === "accepted") {
        toast({
          title: "Musæum foi instalado no seu dispositivo.",
          variant: "default",
        });
      }
    } finally {
      setDeferredPrompt(null);
    }
  }, [deferredPrompt, toast]);

  const toggleTheme = useCallback(() => {
    setTheme(resolvedTheme === "dark" ? "light" : "dark");
  }, [resolvedTheme, setTheme]);

  /* Close the sheet, then scroll once the Radix scroll lock is released. */
  const handleSheetNav = useCallback(
    (event: React.MouseEvent<HTMLAnchorElement>, href: string) => {
      event.preventDefault();
      setMenuOpen(false);
      window.setTimeout(() => {
        const target = document.querySelector<HTMLElement>(href);
        if (target) {
          target.scrollIntoView({ behavior: "smooth", block: "start" });
          window.history.replaceState(null, "", href);
        }
      }, SHEET_EXIT_MS);
    },
    []
  );

  const isDark = mounted && resolvedTheme === "dark";

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/60 bg-background/80 backdrop-blur-md supports-[backdrop-filter]:bg-background/60">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 md:px-6">
        {/* Brand */}
        <a
          href="#inicio"
          aria-label="Musæum — voltar ao início"
          className="flex items-center gap-2.5"
        >
          <LogoMark className="h-7 w-7 text-amber-600" />
          <span className="font-display text-base font-semibold tracking-wide sm:text-lg">
            MUSÆUM
          </span>
        </a>

        {/* Desktop nav */}
        <nav
          aria-label="Navegação principal"
          className="hidden items-center gap-1 md:flex"
        >
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              aria-label={link.ariaLabel}
              className="rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Right cluster */}
        <div className="flex items-center gap-2">
          {deferredPrompt ? (
            <Button
              size="sm"
              variant="outline"
              className="h-11 gap-2 px-4"
              onClick={handleInstall}
              aria-label="Instalar o aplicativo Musæum"
            >
              <Download className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">Instalar app</span>
            </Button>
          ) : null}

          <Button
            type="button"
            variant="ghost"
            size="icon"
            className="size-11"
            suppressHydrationWarning
            aria-label="Alternar entre tema claro e escuro"
            onClick={toggleTheme}
          >
            {isDark ? (
              <Sun className="size-5" aria-hidden="true" />
            ) : (
              <Moon className="size-5" aria-hidden="true" />
            )}
          </Button>

          {/* Mobile menu */}
          <div className="md:hidden">
            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="size-11"
                  aria-label="Abrir menu"
                >
                  <Menu className="size-5" aria-hidden="true" />
                </Button>
              </SheetTrigger>
              <SheetContent
                side="right"
                className="w-72 overflow-y-auto"
                aria-describedby={undefined}
              >
                <SheetHeader>
                  <SheetTitle className="font-display text-lg">
                    Musæum
                  </SheetTitle>
                  <SheetDescription className="sr-only">
                    Menu de navegação principal do museu
                  </SheetDescription>
                </SheetHeader>

                <nav
                  aria-label="Navegação principal"
                  className="flex flex-col gap-1 px-4"
                >
                  {NAV_LINKS.map((link) => (
                    <a
                      key={link.href}
                      href={link.href}
                      aria-label={link.ariaLabel}
                      onClick={(event) => handleSheetNav(event, link.href)}
                      className="block rounded-md px-2 py-3 text-base font-medium text-foreground/90 transition-colors hover:bg-muted hover:text-foreground"
                    >
                      {link.label}
                    </a>
                  ))}
                </nav>

                {deferredPrompt ? (
                  <div className="px-4">
                    <Button
                      size="lg"
                      variant="outline"
                      className="h-11 w-full gap-2"
                      onClick={() => {
                        setMenuOpen(false);
                        void handleInstall();
                      }}
                    >
                      <Download className="size-4" aria-hidden="true" />
                      Instalar app
                    </Button>
                  </div>
                ) : null}

                <p className="mt-auto px-4 pb-6 text-xs text-muted-foreground">
                  PWA · funciona offline
                </p>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}
